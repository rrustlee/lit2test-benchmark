# Lit2Test Human Acceptance Package — 正式包 / Formal package

英文原文为准，中文翻译仅供参考。如果英文和中文不一致，请按英文原文判断。

Lit2Test 评估的是：模型是否能基于近期真实论文邻域，提出 grounded、feasible、falsifiable 的最小下一步研究实验。请不要主动搜索外部资料；所有判断默认基于包内给出的摘要级材料和答案文本。若 Task 1 的摘要片段被截断，可以使用 reading 中已提供的 OpenReview 链接，只查看 abstract，不要打开论文 PDF、正文或附录。

## Workflow / 工作流

1. 先阅读本 `OVERVIEW.md`。
2. 对每个 subtask，阅读该文件夹内的 `README.md`。
3. 在 `reading.md` 中阅读 case 材料。
4. 在同一文件夹的 `annotation.csv` 中填写结构化判断。
5. 两个任务都填完后，在本目录运行 `python3 validate_annotations.py`。
6. 只有看到最后一行 `RESULT: PASS` 才提交；如果是 `FAIL`，按上面的 `ERROR` 逐条修正后重新运行。
7. CSV 不包含审稿人身份；回收后会在文件名层面区分 reviewer。

## 提交前自检（必须做）

`validate_annotations.py` 只检查表格有没有漏填、取值是否合法，不会替你判断论文或答案。它会检查：

- Task 1 的必填字段、`0-2` 分数、`keep/revise/drop` 等选项，以及正数的 `time_minutes`；
- Task 2 的 `winner`、`A/B/TIE` 行的所有 `1-3` 分数、`TIE/INVALID` 的理由、loser weakness，以及正数的 `time_minutes`；`INVALID` 行无法评分时可把分数留空；
- `winner` 不能留空。两个答案差不多时填 `TIE`，无法正常比较时填 `INVALID`。

运行方式（在本 `OVERVIEW.md` 所在目录打开终端）：

```bash
python3 validate_annotations.py
```

脚本只使用 Python 3 自带功能，不需要安装任何额外 package。macOS/Linux 使用 `python3`；Windows 使用 `py validate_annotations.py`。如果电脑提示找不到 Python，请从 https://www.python.org/downloads/ 安装 Python 3 后再运行；Windows 安装时勾选 “Add Python to PATH”。不要自行安装其他依赖。

不要把空白、`N/A`、`-` 当作“暂时不确定”。如果确实无法判断，请按 README 的规则填写 `TIE`/`INVALID` 和理由。

## Subtasks / 子任务

| Subtask | What to do | Cases | Expected time per case | Hard cap per case | Expected total |
|---|---|---:|---:|---:|---:|
| `task_01_neighborhood_quality` | Judge whether a 4-paper abstract-level neighborhood is coherent, grounded, and answerable. | 20 | 5-8 min | 10 min | 20 cases = about 2-3 hours |
| `task_02_human_calibration` | Compare Answer A vs Answer B, choose winner/tie/invalid, score dimensions, and select weakness labels. | 94 | about 5 min | 10 min | 94 cases = about 470 min, roughly 8 hours |

如果单个 case 达到 hard cap 仍不确定，不要继续深挖。请降低 `confidence`、必要时选 `TIE` 或 `INVALID`，并在 `notes_zh` 里写一句原因。

## Important boundaries / 判断边界

- `task_01` 只评价输入论文邻域质量；不评价模型答案，也不评价 Gemini judge。
- `task_02` 只评价两个匿名答案哪个更适合作为下一步研究实验；不要猜模型身份。
- 请不要打开全文。若必须看全文才敢判断，在相应字段标记不确定。
- 正式标注建议按 45-60 分钟为一个工作块，中间休息。
