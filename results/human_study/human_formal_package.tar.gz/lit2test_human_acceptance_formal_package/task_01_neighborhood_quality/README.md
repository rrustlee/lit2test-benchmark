# Task 01 — Abstract-level Neighborhood Quality Audit

英文原文为准，中文翻译仅供参考。请只基于给出的摘要级材料判断，不要打开全文。

## 填完后先自检（必须做）

完成本任务和 Task 2 后，回到包根目录运行：

`python3 validate_annotations.py`

看到 `RESULT: PASS` 才提交。它只检查漏填和格式，不判断你的科学判断是否正确。

## Goal / 目的

判断一个 4-paper neighborhood 是否足够 coherent、grounded、answerable，能否作为 Lit2Test 的研究构想输入。这里不评价模型输出，也不判断论文技术正确性。

## 先分清这三个字段

这三个字段不是一回事：

- `paper_relatedness`：这 4 篇论文是不是在讨论同一个小方向、共同机制或同一种失败现象？
- `open_problem_grounding`：从这些论文的摘要和 reviewer limitation 中，能不能找到一个共同的限制、张力或评估缺口，值得做下一步实验？
- `answerability`：只看 reading 里的材料，能不能进一步写出具体的 dataset/task、baseline、metric 和 falsifier？

这里的 `Open problem` 只是 benchmark 给模型的任务要求，不是一个已经写好的具体科学问题。你不需要寻找一个隐藏的 open problem，也不要评价 prompt 这句话写得好不好。你只需要判断：这 4 篇论文提供的信息，能不能共同支持一个具体的下一步实验。

以练习包中的 `t1_practice_001` 的 4 篇 SAE 论文为例：

- 一篇说经验验证不足；
- 一篇说没有报告多次运行的变异性；
- 一篇讨论学到的特征是否真的对应输入；
- 一篇质疑 SAE 是否找到了稳定、统一的特征单元。

它们虽然不完全相同，但都在追问“SAE 学到的特征是否可靠、评估是否充分”。因此，`paper_relatedness` 和 `open_problem_grounding` 可以较高；如果摘要材料足够完整，`answerability` 也可以较高。

反过来，如果 4 篇论文只是都属于“鲁棒性”这个大领域，但没有共同机制或共同实验缺口，其中一篇还是视觉重编程，其他几篇是神经网络对抗训练，那么 `paper_relatedness` 和 `open_problem_grounding` 都应降低，`overall_keep` 可能是 `revise`。

## Fields to fill / 需要填写的字段

- `paper_relatedness`：4 篇论文是否围绕同一局部研究问题或技术张力。
  - `0`: 明显不相关，像随机拼接。
  - `1`: 有部分相关性，但至少一篇明显偏离或共同问题较松。
  - `2`: 明确相关，能看出共同主题、方法或失败模式。
- `open_problem_grounding`：open problem 是否由这些论文自然支撑。
  - `0`: 4 篇论文没有共同的可检验缺口，任务只能靠泛泛的领域知识完成。
  - `1`: 能找到部分论文支持的缺口，但关联较弱，或需要较多外部知识才能补全。
  - `2`: 至少两篇论文明确提供互补的限制、机制张力或评估缺口，足以支持一个具体的下一步实验。
- `answerability`：仅凭摘要级材料，是否能提出一个最小、可证伪的下一步实验。
  - 可以快速检查四点：实验对象/task、baseline/control、主要 metric、falsifier。
  - `0`: 关键信息不足，基本无法提出具体实验。
  - `1`: 可以大致想到实验，但缺少多项关键信息，或需要较多外部知识/全文。
  - `2`: 仅凭材料就能基本确定对象、对照、指标和失败判定。
- `outlier_paper_count`：明显离群论文数量，填 `0`-`4`。
- `outlier_paper_indices`：若有离群论文，填 paper index，如 `2` 或 `1;4`；没有则留空。
- `overall_keep`：整体是否保留。
  - `keep`: 可直接作为 benchmark item。
  - `revise`: 有可修问题，如删换 1 篇论文或改 open problem。
  - `drop`: 整体不适合作为 item。
- `needs_full_text_to_judge`：是否必须看全文才能判断。
  - `no`: 摘要级材料足够。
  - `maybe`: 有些不确定，但仍可给出当前判断。
  - `yes`: 关键判断无法仅凭摘要完成。
- `confidence`: `low` / `medium` / `high`。
- `difficulty_for_annotator`: `easy` / `medium` / `hard`。
- `time_minutes`: 实际用时，数字即可。
- `notes_zh`: 简短中文备注。

当 `confidence=low`、`needs_full_text_to_judge` 不是 `no`，或 `overall_keep` 不是 `keep` 时，请在 `notes_zh` 写一句原因。

## 如果材料不够，怎么处理

| 问题来源 | 处理 |
|---|---|
| 摘要材料不足，关键判断无法完成 | 将 `needs_full_text_to_judge` 填为 `yes`，降低 `answerability`，并在备注中说明 |
| 摘要有些不足，但仍能给出当前判断 | 将 `needs_full_text_to_judge` 填为 `maybe`，并在备注中说明 |

这里的“需要全文”是指无法仅凭包内摘要完成关键判断。不要打开论文 PDF；如果只是想核对被截断的 abstract，可以使用 reading 中的 OpenReview 链接。

## Compact examples / 简短例子

- 若四篇都围绕 long-context KV cache 压缩，但一篇只讲完全无关的视觉分类，可给 `paper_relatedness=1`，并把该论文标为 outlier。
- 若 open problem 明确要求“在固定显存下检验压缩是否保留 retrieval accuracy”，且摘要都讨论 memory/accuracy trade-off，可给 `open_problem_grounding=2`。
- 若材料只给很泛的“improve AI systems”，无法形成具体 baseline/metric/falsifier，可给 `answerability=0` 或 `1`。
