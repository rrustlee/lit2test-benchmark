# Task 01 Reading Materials

英文原文为准，中文翻译仅供参考。请不要打开全文。

## t1_formal_001

- Batch: `expansion40`
- Context ID: `smallari_expansion40_005_memorization_deep_generalization_necessary_funda__v02_expansion40`
- Area: `alignment, safety, fairness, and privacy`
- Top terms: `memorization, deep, generalization, necessary, fundamentals`
- Mean pairwise cosine: `0.0783`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh expansion neighborhood around alignment, safety, fairness, and privacy: memorization, deep, generalization, necessary, fundamentals. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It is intended to test whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕对齐、安全、公平和隐私形成了一个新鲜的扩展邻域 (expansion neighborhood)：记忆、深度、泛化、必要、基础。该上下文基于论文标题、摘要和审稿人的局限性信号。其旨在测试模型是否能从紧密的局部文献集群 (literature cluster) 中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this expansion neighborhood around alignment, safety, fairness, and privacy: memorization, deep, generalization, necessary, fundamentals, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合了围绕对齐、安全、公平和隐私的这个扩展邻域：记忆、深度、泛化、必要、基础，针对在提供的审稿意见和摘要中可见的局限性或评估差距 (evaluation gap)。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；<=8 A100 GPU-days 用于最小化验证；无专有模型权重；无未来论文的答案密钥 (answer keys)；包括一个来自所提供论文的基线 (baseline) 以及一个故障模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的、可证伪的 (falsifiable) 下一步测试，而不是一个广泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `u9Z6gL5MlL`
- URL: https://openreview.net/forum?id=u9Z6gL5MlL
- Title / 标题:
  - EN:
    > Back to Fundamentals: Re-Examining Memorization in Deep Learning Models
  - ZH:
    > 回到基础：重新审视深度学习模型中的记忆 (Memorization)
- Abstract / 摘要:
  - EN:
    > In supervised training, memorization is the ability of deep learning models to assign arbitrary ground truth labels to inputs in the dataset. Due to the computa- tional difficulty of identifying existing memorized points, researchers often induce artificial memorization i.e, force the model to memorize the newly introduced points (via Noisy Label or Noisy Input). However, in this work, we show that this artificial proxy exhibits fundamentally different characteristics than the mem- orization real points (or natural memorization). To demonstrate this deviation, we re-examine two key findings derived from artificial memorization and com- pare them against natural memorization i.e., over-parametrization and increased training time increases memorization. We show that both these factors have the opposite effect i.e., they reduce natural memorization. Additionally, we find that memorization and train-test gap are strongly correlated (Pearson score 0.99). As a result, memorization is not necessary for generalization. Since real world models suffer from natural memorization (instead of the artificial one) our findings sug- gest the research community should focus on natural memorization, instead of the artificial proxy.
  - ZH:
    > 在监督训练 (supervised training) 中，记忆 (memorization) 是深度学习模型将任意真实标签 (ground truth labels) 分配给数据集中输入的能力。由于在计算上难以识别现有的已记忆点，研究人员通常会诱导人工记忆 (artificial memorization)，即迫使模型记忆新引入的数据点（通过 Noisy Label 或 Noisy Input）。然而，在这项工作中，我们表明这种人工代理表现出与真实点的记忆（或自然记忆，natural memorization）根本不同的特征。为了证明这种偏差，我们重新审视了源自人工记忆的两个关键发现，并将它们与自然记忆进行比较，即过度参数化 (over-parametrization) 和增加的训练时间会增加记忆。我们表明，这两个因素都具有相反的效果，即它们会减少自然记忆。此外，我们发现记忆与训练-测试差距 (train-test gap) 强相关（Pearson score 0.99）。因此，记忆对于泛化 (generalization) 不是必需的。由于现实世界的模型遭受的是自然记忆（而不是人工的），我们的发现表明研究界应该关注自然记忆，而不是人工代理。
- Key contribution / 关键贡献:
  - EN:
    > The paper focuses on memorization in supervised classification models.
  - ZH:
    > 该论文重点关注监督分类模型中的记忆。
- Limitation / 局限:
  - EN:
    > The abstract start by stating that memorization is the ability of "deep learning models to assign ground truth labels to inputs".
  - ZH:
    > 摘要开篇指出，记忆是“深度学习模型将真实标签分配给输入”的能力。
- Important result / 重要结果:
  - EN:
    > However, in this work, we show that this artificial proxy exhibits fundamentally different characteristics than the mem- orization real points (or natural memorization).
  - ZH:
    > 然而，在这项工作中，我们表明这种人工代理表现出与真实点的记忆（或自然记忆）根本不同的特征。

#### Paper 2

- Paper ID: `GbEmJmnQCz`
- URL: https://openreview.net/forum?id=GbEmJmnQCz
- Title / 标题:
  - EN:
    > Is Memorization Actually Necessary for Generalization?
  - ZH:
    > 记忆（memorization）对于泛化（generalization）真的有必要吗？
- Abstract / 摘要:
  - EN:
    > Memorization is the ability of deep models to associate training data with seemingly random labels. Even though memorization may not align with a model's ability to generalize, recent work by~\citet{feldman2020longtail} has demonstrated that memorization is in fact \textit{necessary} for generalization. However, upon closer inspection, we find that their methodology has three limitations. First, the definition of memorization is imprecise, leading to contradictory results. Second, their proposed algorithm used for \textit{approximating} the leave-one-out test (the gold standard for calculating memorization scores) suffers from a high approximation error. Three, the authors induce a distribution shift when calculating marginal utility, leading to flawed results. Having accounted for these errors, we re-evaluate the role of memorization on generalization. To do so, we track how memorization changes at different levels of generalization (test accuracy). We control model generalization by training 19 different combinations of models, datasets, and training optimizations. We find that memorization and generalization are \textit{strongly} negatively correlated (Pearson -0.997): As one decreases, the other increases. This shows that memorization is not necessary for generalization, as otherwise, the correlation would have been positive. In light of these findings, future researcher...
  - ZH:
    > 记忆是深度模型将训练数据与看似随机的标签联系起来的能力。尽管记忆可能与模型的泛化能力不一致，但~\citet{feldman2020longtail} 最近的工作已经证明，记忆实际上对泛化是\textit{必要的}。然而，仔细检查后，我们发现他们的方法论有三个局限性。首先，记忆的定义不精确，导致了矛盾的结果。其次，他们提出的用于\textit{近似}留一法测试（leave-one-out test，计算记忆分数的黄金标准）的算法存在很高的近似误差。第三，作者在计算边际效用（marginal utility）时引发了分布偏移（distribution shift），导致了有缺陷的结果。考虑到这些错误，我们重新评估了记忆在泛化中的作用。为此，我们跟踪了记忆在不同泛化水平（测试准确率）下是如何变化的。我们通过训练19种不同的模型、数据集和训练优化的组合来控制模型泛化。我们发现记忆和泛化呈\textit{强烈}负相关（Pearson -0.997）：当一个减少时，另一个就会增加。这表明记忆对泛化并非必要，因为否则相关性就会是正的。鉴于这些发现，未来的研究人员...
- Key contribution / 关键贡献:
  - EN:
    > This manuscript reconsiders and critiques the key claim of Feldman and Zhang (2020), hereafter F&Z.
  - ZH:
    > 本手稿重新考虑并批评了Feldman和Zhang（2020）（以下简称F&Z）的关键主张。
- Limitation / 局限:
  - EN:
    > Some claims and conclusions made by the authors either require additional support or are overly strong.
  - ZH:
    > 作者提出的一些主张和结论要么需要额外的支持，要么过于强烈。
- Important result / 重要结果:
  - EN:
    > Even though memorization may not align with a model's ability to generalize, recent work by~\citet{feldman2020longtail} has demonstrated that memorization is in fact \textit{necessary} for generalization.
  - ZH:
    > 尽管记忆可能与模型的泛化能力不一致，但~\citet{feldman2020longtail} 最近的工作已经证明，记忆实际上对泛化是\textit{必要的}。

#### Paper 3

- Paper ID: `onvN3zsNMI`
- URL: https://openreview.net/forum?id=onvN3zsNMI
- Title / 标题:
  - EN:
    > Preventing Unintended Memorization by Covering with Over-Memorization
  - ZH:
    > 通过过度记忆覆盖来防止意外记忆
- Abstract / 摘要:
  - EN:
    > From the advances of deep learning, the privacy concerns of deep neural networks are in the limelight. A particular concern is privacy of the training data, which is often compromised by the model's inherent memorization capabilities. Suppressing such memorization can enhance privacy but introduces two main challenges: 1) removing a memorized instance from the training dataset will result in the model to memorize another instance instead, and 2) the memorization is essential for improving the generalization error. To address these challenges, we propose an over-memorization method that involves training the model with both the standard training set and a set of redundant, non-sensitive instances. Our method leverages the model's limited memorization capacity to focus on irrelevant data, thereby preventing it from memorizing the training data. Our empirical results demonstrate that this method not only enhances protection against membership inference attacks but also minimizes the loss of utility by effectively redirecting the model's generalization efforts towards non-sensitive instances.
  - ZH:
    > 随着深度学习的发展，深度神经网络的隐私问题备受瞩目。一个特别的担忧是训练数据的隐私，它经常被模型固有的记忆能力所破坏。抑制这种记忆可以增强隐私，但引入了两个主要挑战：1）从训练数据集中移除一个被记忆的实例将导致模型转而记忆另一个实例，以及2）记忆对于改善泛化误差 (generalization error) 是必不可少的。为了应对这些挑战，我们提出了一种过度记忆方法，该方法包括使用标准训练集和一组冗余的非敏感实例来训练模型。我们的方法利用模型有限的记忆容量专注于无关数据，从而防止其记忆训练数据。我们的实证结果表明，该方法不仅增强了对成员推理攻击 (membership inference attacks) 的保护，而且通过有效地将模型的泛化努力重新导向非敏感实例，最小化了效用的损失。
- Key contribution / 关键贡献:
  - EN:
    > This paper designs a new approach to mitigate the privacy-utility trade-off of ML models.
  - ZH:
    > 本文设计了一种新方法来缓解ML模型的隐私-效用权衡 (privacy-utility trade-off)。
- Limitation / 局限:
  - EN:
    > I have two main concerns related to "dataset condensation" [r1]: - The idea of using synthesized dummy datasets to simulate real-world datasets is very similar to the concept of "dataset condensation" (or say "dataset distillation") which first appeared in 2021 [r1].
  - ZH:
    > 我对"数据集浓缩" (dataset condensation) [r1] 有两个主要担忧： - 使用合成的虚拟数据集来模拟真实世界数据集的想法非常类似于2021年首次出现的"数据集浓缩"（或者说"数据集蒸馏" (dataset distillation)）的概念 [r1]。
- Important result / 重要结果:
  - EN:
    > Our empirical results demonstrate that this method not only enhances protection against membership inference attacks but also minimizes the loss of utility by effectively redirecting the model's generalization efforts towards non-sensitive instances.
  - ZH:
    > 我们的实证结果表明，该方法不仅增强了对成员推理攻击的保护，而且通过有效地将模型的泛化努力重新导向非敏感实例，最小化了效用的损失。

#### Paper 4

- Paper ID: `sVs7lV691r`
- URL: https://openreview.net/forum?id=sVs7lV691r
- Title / 标题:
  - EN:
    > Exploring Memorization in Fine-tuned Language Models
  - ZH:
    > 探索微调语言模型中的记忆化
- Abstract / 摘要:
  - EN:
    > Large language models have shown great capabilities in various tasks but also exhibited memorization of training data, thus raising tremendous privacy and copyright concerns. While prior work has studied memorization during pre-training, the exploration of memorization during fine-tuning is rather limited. Compared with pre-training, fine-tuning typically involves sensitive data and diverse objectives, thus may bring unique memorization behaviors and distinct privacy risks. In this work, we conduct the first comprehensive analysis to explore LLM memorization during fine-tuning. Our studies with open-sourced and our own fine-tuned LM models across various tasks indicate that fine-tuned memorization presents a strong disparity among tasks. We provide an understanding on this task disparity via sparse coding theory and unveil a strong correlation between memorization and model attention distribution. By investigating its memorization behavior, multi-task fine-tuning paves a potential strategy to mitigate fine-tuning memorization.
  - ZH:
    > 大型语言模型在各种任务中展现出了强大的能力，但也表现出对训练数据的记忆化（memorization），从而引起了巨大的隐私和版权担忧。虽然先前的工作研究了预训练（pre-training）期间的记忆化，但对微调（fine-tuning）期间记忆化的探索却相当有限。与预训练相比，微调通常涉及敏感数据和多样化的目标，因此可能带来独特的记忆行为和不同的隐私风险。在这项工作中，我们进行了首次全面分析，以探索微调期间的LLM记忆化。我们对跨各种任务的开源和我们自己微调的LM模型的研究表明，微调记忆化在不同任务之间呈现出强烈的差异。我们通过稀疏编码理论（sparse coding theory）提供了对这种任务差异的理解，并揭示了记忆化与模型注意力分布之间的强相关性。通过调查其记忆行为，多任务微调为缓解微调记忆化铺平了潜在的策略。
- Key contribution / 关键贡献:
  - EN:
    > The paper studies memorization in fine-tuned language models.
  - ZH:
    > 该论文研究了微调语言模型中的记忆化。
- Limitation / 局限:
  - EN:
    > I have a couple of questions about the experimental setup and the observations that the authors draw from their results.
  - ZH:
    > 我对实验设置以及作者从其结果中得出的观察有几个问题。
- Important result / 重要结果:
  - EN:
    > Large language models have shown great capabilities in various tasks but also exhibited memorization of training data, thus raising tremendous privacy and copyright concerns.
  - ZH:
    > 大型语言模型在各种任务中展现出了强大的能力，但也表现出对训练数据的记忆化，从而引起了巨大的隐私和版权担忧。

## t1_formal_002

- Batch: `expansion40`
- Context ID: `smallari_expansion40_020_transport_optimal_generative_map_networks__v02_expansion40`
- Area: `diffusion and generative modeling`
- Top terms: `transport, optimal, generative, map, networks`
- Mean pairwise cosine: `0.0866`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh expansion neighborhood around diffusion and generative modeling: transport, optimal, generative, map, networks. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It is intended to test whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文在扩散和生成建模（diffusion and generative modeling）周围形成了一个新的扩展邻域（expansion neighborhood）：传输、最优、生成、映射、网络。该上下文建立在论文标题、摘要和审稿人的局限性信号（reviewer limitation signals）之上。它旨在测试模型是否能从一个紧密的局部文献集群（local literature cluster）中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this expansion neighborhood around diffusion and generative modeling: transport, optimal, generative, map, networks, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合这个围绕扩散和生成建模的扩展邻域：传输、最优、生成、映射、网络，并针对在提供的审稿意见和摘要中可见的局限性或评估空白（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型（open-weight models）；最简验证需 <=8 个 A100 GPU天（GPU-days）；无专有模型权重；无未来论文标准答案（future-paper answer keys）；包含一个来自所提供论文的基线（baseline），以及一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的可证伪的下一步测试，而不是一个宽泛的研究提案（research proposal）。

### Papers / 论文

#### Paper 1

- Paper ID: `jODehvtTDx`
- URL: https://openreview.net/forum?id=jODehvtTDx
- Title / 标题:
  - EN:
    > Analyzing and Improving Optimal-Transport-based Adversarial Networks
  - ZH:
    > 分析和改进基于最优传输的对抗网络
- Abstract / 摘要:
  - EN:
    > Optimal Transport (OT) problem aims to find a transport plan that bridges two distributions while minimizing a given cost function. OT theory has been widely utilized in generative modeling. In the beginning, OT distance has been used as a measure for assessing the distance between data and generated distributions. Recently, OT transport map between data and prior distributions has been utilized as a generative model. These OT-based generative models share a similar adversarial training objective. In this paper, we begin by unifying these OT-based adversarial methods within a single framework. Then, we elucidate the role of each component in training dynamics through a comprehensive analysis of this unified framework. Moreover, we suggest a simple but novel method that improves the previously best-performing OT-based model. Intuitively, our approach conducts a gradual refinement of the generated distribution, progressively aligning it with the data distribution. Our approach achieves a FID score of 2.51 on CIFAR-10 and 5.99 on CelebA-HQ-256, outperforming unified OT-based adversarial approaches.
  - ZH:
    > 最优传输 (Optimal Transport, OT) 问题旨在寻找一个桥接两个分布同时最小化给定代价函数的传输计划。OT理论已广泛应用于生成建模中。最初，OT距离被用作评估数据分布与生成分布之间距离的度量。最近，数据与先验分布之间的OT传输映射被用作生成模型。这些基于OT的生成模型共享相似的对抗训练目标。在本文中，我们首先将这些基于OT的对抗方法统一在一个单一框架内。然后，我们通过对这一统一框架的全面分析，阐明了每个组件在训练动态中的作用。此外，我们提出了一种简单但新颖的方法，改进了以前性能最佳的基于OT的模型。直观地说，我们的方法对生成分布进行逐渐细化，使其逐步与数据分布对齐。我们的方法在CIFAR-10上实现了2.51的FID分数，在CelebA-HQ-256上实现了5.99的FID分数，优于统一的基于OT的对抗方法。
- Key contribution / 关键贡献:
  - EN:
    > OT has been widely explored in generative modeling from diverse perspectives (e.g., OT loss and OT map).
  - ZH:
    > OT已经在生成建模中从不同的视角（例如，OT损失和OT映射）得到了广泛探索。
- Limitation / 局限:
  - EN:
    > It is not easy to understand without expertise in OT.
  - ZH:
    > 如果没有OT方面的专业知识，不容易理解。
- Important result / 重要结果:
  - EN:
    > Optimal Transport (OT) problem aims to find a transport plan that bridges two distributions while minimizing a given cost function.
  - ZH:
    > 最优传输 (Optimal Transport, OT) 问题旨在寻找一个桥接两个分布同时最小化给定代价函数的传输计划。

#### Paper 2

- Paper ID: `CfZPzH7ftt`
- URL: https://openreview.net/forum?id=CfZPzH7ftt
- Title / 标题:
  - EN:
    > Improving Neural Optimal Transport via Displacement Interpolation
  - ZH:
    > 通过位移插值（Displacement Interpolation）改进神经最优传输（Neural Optimal Transport）
- Abstract / 摘要:
  - EN:
    > Optimal Transport (OT) theory investigates the cost-minimizing transport map that moves a source distribution to a target distribution. Recently, several approaches have emerged for learning the optimal transport map for a given cost function using neural networks. We refer to these approaches as the OT Map. OT Map provides a powerful tool for diverse machine learning tasks, such as generative modeling and unpaired image-to-image translation. However, existing methods that utilize max-min optimization often experience training instability and sensitivity to hyperparameters. In this paper, we propose a novel method to improve stability and achieve a better approximation of the OT Map by exploiting displacement interpolation, dubbed Displacement Interpolation Optimal Transport Model (DIOTM). We derive the dual formulation of displacement interpolation at specific time $t$ and prove how these dual problems are related across time. This result allows us to utilize the entire trajectory of displacement interpolation in learning the OT Map. Our method improves the training stability and achieves superior results in estimating optimal transport maps. We demonstrate that DIOTM outperforms existing OT-based models on image-to-image translation tasks.
  - ZH:
    > 最优传输（Optimal Transport, OT）理论研究将源分布移动到目标分布的成本最小化传输映射。最近，出现了几种使用神经网络为给定代价函数学习最优传输映射的方法。我们将这些方法称为 OT Map。OT Map 为多样的机器学习任务（例如生成建模和非成对图像到图像翻译）提供了强大的工具。然而，利用最大-最小优化的现有方法通常会遇到训练不稳定性以及对超参数的敏感性。在本文中，我们提出了一种利用位移插值来提高稳定性并实现 OT Map 更好近似的新方法，称为位移插值最优传输模型（Displacement Interpolation Optimal Transport Model, DIOTM）。我们推导了位移插值在特定时间 $t$ 的对偶形式，并证明了这些对偶问题跨时间是如何关联的。这一结果允许我们在学习 OT Map 时利用位移插值的整个轨迹。我们的方法提高了训练稳定性，并在估计最优传输映射方面取得了卓越的结果。我们证明了 DIOTM 在图像到图像翻译任务上优于现有的基于 OT 的模型。
- Key contribution / 关键贡献:
  - EN:
    > The authors propose a novel method (DIOTM) to solve the optimal transport mapping problem for the quadratic transport cost (Wasserstein-2 OT) with neural networks.
  - ZH:
    > 作者提出了一种新方法（DIOTM），使用神经网络解决二次传输代价（Wasserstein-2 OT）的最优传输映射问题。
- Limitation / 局限:
  - EN:
    > 1) I believe that there might be a theoretical gap in the proposed DI-OTM approach which lies in the restricted parameterization of the t-dependent transport maps.
  - ZH:
    > 1) 我认为所提出的 DI-OTM 方法中可能存在一个理论空白，该空白在于依赖于 t 的传输映射的受限参数化。
- Important result / 重要结果:
  - EN:
    > In this paper, we propose a novel method to improve stability and achieve a better approximation of the OT Map by exploiting displacement interpolation, dubbed Displacement Interpolation Optimal Transport Model (DIOTM).
  - ZH:
    > 在本文中，我们提出了一种利用位移插值来提高稳定性并实现 OT Map 更好近似的新方法，称为位移插值最优传输模型（Displacement Interpolation Optimal Transport Model, DIOTM）。

#### Paper 3

- Paper ID: `gBLEHzKOfF`
- URL: https://openreview.net/forum?id=gBLEHzKOfF
- Title / 标题:
  - EN:
    > Generative Entropic Neural Optimal Transport To Map Within and Across Space
  - ZH:
    > 生成式熵神经最优传输用于空间内部及跨空间的映射
- Abstract / 摘要:
  - EN:
    > Learning measure-to-measure mappings is a crucial task in machine learning, fea- tured prominently in generative modeling. Recent years have witnessed a surge of techniques that draw inspiration from optimal transport (OT) theory. Combined with neural network models, these methods collectively known as Neural OT use optimal transport as an inductive bias: such mappings should be optimal w.r.t. a given cost function, in the sense that they are able to move points in a thrifty way, within (by minimizing displacements) or across spaces (by being isometric). This principle, while intuitive, is often confronted with several practical challenges that require adapting the OT toolbox: cost functions other than the squared-Euclidean cost can be challenging to handle, the deterministic formulation of Monge maps leaves little flexibility, mapping across incomparable spaces raises multiple chal- lenges, while the mass conservation constraint inherent to OT can provide too much credit to outliers. While each of these mismatches between practice and theory has been addressed independently in various works, we propose in this work an elegant framework to unify them, called generative entropic neural op- timal transport (GENOT). GENOT can accommodate any cost function; handles randomness using conditional generative models; can map points across incompa- rable spaces, and can be used as an...
  - ZH:
    > 学习测度到测度的映射（measure-to-measure mappings）是机器学习中的一项关键任务，在生成模型（generative modeling）中尤为突出。近年来涌现了大量从最优传输（optimal transport, OT）理论中汲取灵感的技术。结合神经网络模型，这些统称为神经最优传输（Neural OT）的方法将最优传输作为一种归纳偏置（inductive bias）：这种映射相对于给定的代价函数（cost function）应该是最优的，即它们能够以节约的方式移动点，无论是在空间内部（通过最小化位移）还是跨空间（通过保持等距）。这一原理虽然直观，但常常面临几个需要调整 OT 工具箱的实际挑战：除平方欧几里得代价之外的代价函数可能难以处理，Monge 映射的确定性公式几乎没有灵活性，跨不可比较的空间进行映射会带来多重挑战，而 OT 固有的质量守恒约束（mass conservation constraint）可能会赋予异常值过高的权重。虽然实践与理论之间的每一处不匹配都在各种文献中被独立解决过，但在本工作中，我们提出了一个优雅的框架来统一它们，称为生成式熵神经最优传输（generative entropic neural optimal transport, GENOT）。GENOT 能够适应任何代价函数；使用条件生成模型处理随机性；能够跨不可比较的空间映射点，并且可以用作一个...
- Key contribution / 关键贡献:
  - EN:
    > The authors consider different versions of entropic OT problem statement: unbalanced OT formulation, quadratic OT instead of linear OT, etc.
  - ZH:
    > 作者考虑了不同版本的熵 OT（entropic OT）问题陈述：不平衡的 OT 公式（unbalanced OT formulation）、用二次 OT（quadratic OT）替代线性 OT，等等。
- Limitation / 局限:
  - EN:
    > the authors did not investigate computational limits of the proposed approach: how do comp.
  - ZH:
    > 作者没有调查所提出方法的计算极限：comp. 如何
- Important result / 重要结果:
  - EN:
    > We evaluate our approach through experiments conducted on various synthetic datasets and demonstrate its practicality in single-cell biology.
  - ZH:
    > 我们通过在各种合成数据集上进行的实验来评估我们的方法，并证明了其在单细胞生物学中的实用性。

#### Paper 4

- Paper ID: `62Ff8LDAJZ`
- URL: https://openreview.net/forum?id=62Ff8LDAJZ
- Title / 标题:
  - EN:
    > Not-So-Optimal Transport Flows for 3D Point Cloud Generation
  - ZH:
    > 用于3D点云生成的并非那么最优的传输流
- Abstract / 摘要:
  - EN:
    > Learning generative models of 3D point clouds is one of the fundamental problems in 3D generative learning. One of the key properties of point clouds is their permutation invariance, i.e., changing the order of points in a point cloud does not change the shape they represent. In this paper, we analyze the recently proposed equivariant OT flows that learn permutation invariant generative models for point-based molecular data and we show that these models scale poorly on large point clouds. Also, we observe learning (equivariant) OT flows is generally challenging since straightening flow trajectories makes the learned flow model complex at the beginning of the trajectory. To remedy these, we propose not-so-optimal transport flow models that obtain an approximate OT by an offline OT precomputation, enabling an efficient construction of OT pairs for training. During training, we can additionally construct a hybrid coupling by combining our approximate OT and independent coupling to make the target flow models easier to learn. In an extensive empirical study, we show that our proposed model outperforms prior diffusion- and flow -based approaches on a wide range of unconditional generation and shape completion on the ShapeNet benchmark.
  - ZH:
    > 学习3D点云（3D point clouds）的生成模型（generative models）是3D生成学习中的基本问题之一。点云的关键属性之一是它们的排列不变性（permutation invariance），即，改变点云中点的顺序不会改变它们所表示的形状。在本文中，我们分析了最近提出的等变OT流（equivariant OT flows），它们为基于点的分子数据学习排列不变生成模型，并且我们展示了这些模型在大型点云上的扩展性很差。此外，我们观察到学习（等变）OT流通常具有挑战性，因为拉直流轨迹（straightening flow trajectories）会使学到的流模型在轨迹开始时变得复杂。为了弥补这些，我们提出了并非那么最优的传输流模型（not-so-optimal transport flow models），其通过离线OT预计算获得近似OT，从而能够为训练高效构建OT对。在训练期间，我们还可以通过结合我们的近似OT和独立耦合（independent coupling）来构建混合耦合（hybrid coupling），使目标流模型更容易学习。在广泛的实证研究中，我们展示了我们提出的模型在ShapeNet基准上的广泛无条件生成和形状补全任务中，优于先前的基于扩散和流（diffusion- and flow -based）的方法。
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces an offline superset OT pre-computation method followed by an efficient online subsampling to reduce the complexity of target flow models which is hard to be approximated by the neural networks.
  - ZH:
    > 本文引入了一种离线超集OT预计算（offline superset OT pre-computation）方法，随后进行高效的在线子采样（online subsampling），以降低难以被神经网络近似的目标流模型的复杂性。
- Limitation / 局限:
  - EN:
    > Energy-based models, such as [1][2], are naturally permutation-invariant with respect to the order of point cloud data.
  - ZH:
    > 基于能量的模型（Energy-based models），例如[1][2]，相对于点云数据的顺序，自然具有排列不变性。
- Important result / 重要结果:
  - EN:
    > In this paper, we analyze the recently proposed equivariant OT flows that learn permutation invariant generative models for point-based molecular data and we show that these models scale poorly on large point clouds.
  - ZH:
    > 在本文中，我们分析了最近提出的等变OT流（equivariant OT flows），它们为基于点的分子数据学习排列不变生成模型，并且我们展示了这些模型在大型点云上的扩展性很差。

## t1_formal_003

- Batch: `expansion40`
- Context ID: `smallari_expansion40_025_audio_visual_multimodal_aligned_language_visual__v02_expansion40`
- Area: `multimodal and vision-language learning`
- Top terms: `audio-visual, multimodal, aligned, language, visual`
- Mean pairwise cosine: `0.1137`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh expansion neighborhood around multimodal and vision-language learning: audio-visual, multimodal, aligned, language, visual. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It is intended to test whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文在多模态和视觉-语言学习 (multimodal and vision-language learning) 周围形成了一个新的扩展邻域 (expansion neighborhood)：音视 (audio-visual)、多模态 (multimodal)、对齐 (aligned)、语言 (language)、视觉 (visual)。该上下文基于论文标题、摘要和审稿人的局限性信号 (reviewer limitation signals)。其旨在测试模型是否能从一个紧密的局部文献簇 (tight local literature cluster) 中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this expansion neighborhood around multimodal and vision-language learning: audio-visual, multimodal, aligned, language, visual, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合了围绕多模态和视觉-语言学习的这个扩展邻域：音视、多模态、对齐、语言、视觉，针对在提供的审稿意见和摘要中可见的局限性或评估差距 (evaluation gap)。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型 (open-weight models)；<=8 A100 GPU-days 用于最小验证；无专有模型权重；无未来论文答案密钥 (future-paper answer keys)；包括一个来自所提供论文的基线 (baseline) 以及一个失败模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪的 (falsifiable) 下一步测试，而不是一个宽泛的研究提案 (research proposal)。

### Papers / 论文

#### Paper 1

- Paper ID: `1SYUKPeM12`
- URL: https://openreview.net/forum?id=1SYUKPeM12
- Title / 标题:
  - EN:
    > Aligned Better, Listen Better for Audio-Visual Large Language Models
  - ZH:
    > 更好的对齐，更好的聆听：面向视听大型语言模型
- Abstract / 摘要:
  - EN:
    > Audio is essential for multimodal video understanding. On the one hand, video inherently contains audio, which supplies complementary information to vision. Besides, video large language models (Video-LLMs) can encounter many audio-centric settings. However, existing Video-LLMs and Audio-Visual Large Language Models (AV-LLMs) exhibit deficiencies in exploiting audio information, leading to weak understanding and hallucinations. To solve the issues, we delve into the model architecture and dataset. (1) From the architectural perspective, we propose a fine-grained AV-LLM, namely Dolphin. The concurrent alignment of audio and visual modalities in both temporal and spatial dimensions ensures a comprehensive and accurate understanding of videos. Specifically, we devise an audio-visual multi-scale adapter for multi-scale information aggregation, which achieves spatial alignment. For temporal alignment, we propose audio-visual interleaved merging. (2) From the dataset perspective, we curate an audio-visual caption \& instruction-tuning dataset, called AVU. It comprises 5.2 million diverse, open-ended data tuples (video, audio, question, answer) and introduces a novel data partitioning strategy. Extensive experiments show our model not only achieves remarkable performance in audio-visual understanding, but also mitigates potential hallucinations.
  - ZH:
    > 音频对于多模态视频理解至关重要。一方面，视频本质上包含音频，这为视觉提供了补充信息。此外，视频大型语言模型（Video-LLMs）会遇到许多以音频为中心的设置。然而，现有的Video-LLMs和视听大型语言模型（AV-LLMs）在利用音频信息方面表现出不足，导致理解能力弱和幻觉。为了解决这些问题，我们深入研究了模型架构和数据集。(1) 从架构角度来看，我们提出了一种细粒度的AV-LLM，即Dolphin。音频和视觉模态在时间维度和空间维度上的并发对齐，确保了对视频的全面且准确的理解。具体而言，我们设计了一个用于多尺度信息聚合的视听多尺度适配器，它实现了空间对齐。对于时间对齐，我们提出了视听交错合并。(2) 从数据集的角度来看，我们策划了一个视听字幕 \& 指令微调数据集，称为AVU。它包含520万个多样化、开放式的数据元组（视频，音频，问题，答案），并引入了一种新颖的数据划分策略。广泛的实验表明，我们的模型不仅在视听理解方面取得了显著的性能，而且还缓解了潜在的幻觉。
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces a new audio-visual LLM model called Dolphin and a new audio-visual dataset AVU.
  - ZH:
    > 本文介绍了一个新的名为Dolphin的视听LLM模型和一个新的视听数据集AVU。
- Limitation / 局限:
  - EN:
    > The entire pipeline in the dataset generation is LLM-based.
  - ZH:
    > 数据集生成中的整个流水线都是基于LLM的。
- Important result / 重要结果:
  - EN:
    > Specifically, we devise an audio-visual multi-scale adapter for multi-scale information aggregation, which achieves spatial alignment.
  - ZH:
    > 具体而言，我们设计了一个用于多尺度信息聚合的视听多尺度适配器，它实现了空间对齐。

#### Paper 2

- Paper ID: `gWw0NjTQRg`
- URL: https://openreview.net/forum?id=gWw0NjTQRg
- Title / 标题:
  - EN:
    > AV-PEA: PARAMETER-EFFICIENT ADAPTER FOR AUDIO-VISUAL MULTIMODAL LEARNING
  - ZH:
    > AV-PEA: 用于视听多模态学习的参数高效适配器
- Abstract / 摘要:
  - EN:
    > Fine-tuning has emerged as a widely used transfer learning technique for leveraging pre-trained vision transformers in various downstream tasks. However, its success relies on tuning a significant number of trainable parameters, which could lead to significant costs in terms of both model training and storage. When it comes to audio-visual multimodal learning, the challenge also lies in effectively incorporating both audio and visual cues into the transfer learning process, especially when the original model has been trained with unimodal samples only. This paper introduces a novel audio-visual parameter-efficient adapter (AV-PEA) designed to improve multimodal transfer learning for audio-visual tasks. Through the integration of AV-PEA into a frozen vision transformer, like ViT (Dosovitskiy et al., 2021), the transformer becomes adept at processing audio inputs without prior knowledge of audio pre-training. This also facilitates the exchange of essential audio-visual cues between audio and visual modalities, all while introducing a limited set of trainable parameters into each block of the frozen transformer. The experimental results demonstrate that our AV-PEA consistently achieves superior or comparable performance to state-of-the-art methods in a range of audio-visual tasks, including audio-visual event localization (AVEL), audio-visual question answering (AVQA), audio-vi...
  - ZH:
    > 微调（Fine-tuning）已成为一种广泛使用的迁移学习技术，用于在各种下游任务中利用预训练的视觉Transformer（vision transformers）。然而，其成功依赖于调整大量可训练参数，这可能会在模型训练和存储方面导致显著的成本。当涉及视听多模态学习时，挑战还在于将音频和视觉线索有效地整合到迁移学习过程中，特别是当原始模型仅使用单模态样本进行训练时。本文引入了一种新颖的视听参数高效适配器（audio-visual parameter-efficient adapter, AV-PEA），旨在改善视听任务的多模态迁移学习。通过将AV-PEA集成到冻结的视觉Transformer中，例如ViT (Dosovitskiy et al., 2021)，该Transformer变得擅长处理音频输入，而无需音频预训练的先验知识。这也促进了音频和视觉模态之间必要视听线索的交换，同时在冻结的Transformer的每个块中引入了一组有限的可训练参数。实验结果表明，我们的AV-PEA在一系列视听任务中始终取得优于或可媲美最先进（state-of-the-art）方法的性能，包括视听事件定位（AVEL）、视听问答（AVQA）、audio-vi...
- Key contribution / 关键贡献:
  - EN:
    > This paper proposed an audio-visual parameter-efficient adapter (AV-PEA) designed to improve multimodal transfer learning for audio-visual tasks.
  - ZH:
    > 本文提出了一种视听参数高效适配器（AV-PEA），旨在改善视听任务的多模态迁移学习。
- Limitation / 局限:
  - EN:
    > 1) The novelty is limited.
  - ZH:
    > 1) 新颖性有限。
- Important result / 重要结果:
  - EN:
    > This paper introduces a novel audio-visual parameter-efficient adapter (AV-PEA) designed to improve multimodal transfer learning for audio-visual tasks.
  - ZH:
    > 本文引入了一种新颖的视听参数高效适配器（AV-PEA），旨在改善视听任务的多模态迁移学习。

#### Paper 3

- Paper ID: `HUjFpOgVCK`
- URL: https://openreview.net/forum?id=HUjFpOgVCK
- Title / 标题:
  - EN:
    > ACAV-1M: Data Curation and Benchmarking for Audio-Visual Representation Learning
  - ZH:
    > ACAV-1M：视听表示学习的数据策展（Data Curation）与基准测试
- Abstract / 摘要:
  - EN:
    > The natural alignment of visual and audio information in videos provides a strong learning signal. However, commonly used large-scale video datasets contain audio-visual signals that are not aligned, e.g. background music. This limits the development of robust models that leverage the complementary nature of audio and video data. To address this limitation, we curate ACAV-1M, a new large-scale dataset that contains one million samples sourced from the ACAV-100M dataset. The ACAV-1M dataset is obtained through a pipeline that ensures the audio-visual correspondence and synchronization of samples in the dataset. Our pipeline transforms raw video and audio into text captions, followed by text summarization and an extensive filtering procedure. The filtering is done based on audio-caption alignment, audio-visual instance semantic alignment, and temporal synchronization. Furthermore, we propose an audio-visual learning benchmark that supports a diverse range of downstream tasks. Empirical evaluations demonstrate that models trained on ACAV-1M achieve superior performance compared to using existing datasets across all tasks. Our ACAV-1M dataset and code to reproduce all benchmark results will be made publicly available upon acceptance.
  - ZH:
    > 视频中视觉和音频信息的自然对齐提供了强大的学习信号。然而，常用的大规模视频数据集包含未对齐的视听信号，例如背景音乐。这限制了利用音频和视频数据互补性质的稳健（robust）模型的发展。为了解决这一限制，我们策展（curate）了 ACAV-1M，这是一个新的大规模数据集，包含源自 ACAV-100M 数据集的100万个样本。ACAV-1M 数据集是通过一个确保数据集中样本的视听对应和同步的流水线（pipeline）获得的。我们的流水线将原始视频和音频转换为文本字幕，随后进行文本摘要和广泛的过滤程序。过滤是基于音频-字幕对齐、视听实例语义对齐和时间同步完成的。此外，我们提出了一种支持各种下游任务的视听学习基准（benchmark）。经验评估表明，与使用现有数据集相比，在 ACAV-1M 上训练的模型在所有任务中均取得了优越的性能。我们的 ACAV-1M 数据集和用于重现所有基准测试结果的代码将在被接收后公开发布。
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces ACAV-1M, a large-scale audio-visual dataset containing one million samples with carefully curated data processing pipeline and comprehensive benchmarks for various audio-visual tasks.
  - ZH:
    > 本文介绍了 ACAV-1M，这是一个包含100万个样本的大规模视听数据集，具有精心策展的数据处理流水线和用于各种视听任务的综合基准。
- Limitation / 局限:
  - EN:
    > Data Distribution Issues: - Lack of distribution statistics.
  - ZH:
    > 数据分布问题：- 缺乏分布统计数据。
- Important result / 重要结果:
  - EN:
    > Empirical evaluations demonstrate that models trained on ACAV-1M achieve superior performance compared to using existing datasets across all tasks.
  - ZH:
    > 经验评估表明，与使用现有数据集相比，在 ACAV-1M 上训练的模型在所有任务中均取得了优越的性能。

#### Paper 4

- Paper ID: `FFUmPQM8c5`
- URL: https://openreview.net/forum?id=FFUmPQM8c5
- Title / 标题:
  - EN:
    > AVCAPS: AN AUDIO-VISUAL DATASET WITH MODALITY-SPECIFIC CAPTIONS
  - ZH:
    > AVCAPS：带有特定模态描述的音视频数据集
- Abstract / 摘要:
  - EN:
    > In this paper, we introduce AVCaps, an audio-visual captioning dataset that contains separate textual captions for the audio, visual, and audio-visual contents of video clips. The dataset contains 2061 video clips constituting a total of 28.8 hours. We provide up to 5 captions for the audio, visual, and audio-visual content of each clip, crowdsourced separately. Existing datasets focus on a single modality or do not provide modality-specific captions, limiting the study of how each modality contributes to overall comprehension in multimodal settings. Our dataset addresses this critical gap in multimodal research by offering a resource for studying how audio and visual content are captioned individually, as well as how audio-visual content is captioned in relation to these individual modalities. To counter the bias observed in crowdsourced audio-visual captions, which often emphasize visual over audio content, we generated three audio-visual captions for each clip using our crowdsourced captions by leveraging existing large language models (LLMs). We present multimodal and crossmodal captioning and retrieval experiments to illustrate the effectiveness of modality-specific captions in evaluating model performance. Notably, we show that a model trained on LLM-generated audio-visual captions captures audio information more effectively, achieving 14% higher Sentence-BERT similari...
  - ZH:
    > 在本文中，我们介绍了AVCaps，这是一个音视频描述 (audio-visual captioning) 数据集，它包含对视频片段的音频、视觉和音视频内容的独立文本描述 (textual captions)。该数据集包含2061个视频片段，总计28.8小时。我们为每个片段的音频、视觉和音视频内容提供最多5个描述，这些描述是分别众包 (crowdsourced) 的。现有的数据集专注于单一模态 (modality) 或不提供特定模态的描述，这限制了在多模态 (multimodal) 设置中研究每种模态如何对整体理解做出贡献。我们的数据集通过提供一个资源来研究音频和视觉内容是如何被单独描述的，以及音视频内容是如何结合这些单独模态被描述的，从而填补了多模态研究中的这一关键空白。为了应对在众包音视频描述中观察到的偏见（这些偏见通常强调视觉而非音频内容），我们利用现有的大语言模型 (LLMs)，使用我们的众包描述为每个片段生成了三个音视频描述。我们提出了多模态和跨模态描述与检索实验，以说明特定模态描述在评估模型性能方面的有效性。值得注意的是，我们表明，与在众包音视频描述上训练的模型相比，在LLM生成的音视频描述上训练的模型能更有效地捕捉音频信息，实现了高出14%的 Sentence-BERT 相似...
- Key contribution / 关键贡献:
  - EN:
    > 1.The authors selected 2,176 videos from the VidOR dataset and performed some cleaning on the dataset.
  - ZH:
    > 1.作者从VidOR数据集中选择了2,176个视频，并对该数据集进行了一些清理。
- Limitation / 局限:
  - EN:
    > 1.The selection of evaluation metrics lacks a thorough justification.
  - ZH:
    > 1.评估指标的选择缺乏彻底的论证。
- Important result / 重要结果:
  - EN:
    > Notably, we show that a model trained on LLM-generated audio-visual captions captures audio information more effectively, achieving 14% higher Sentence-BERT similarity on ground truth audio captions compared to a model trained on crowdsourced audio-visual captions.
  - ZH:
    > 值得注意的是，我们表明，与在众包音视频描述上训练的模型相比，在LLM生成的音视频描述上训练的模型能更有效地捕捉音频信息，在真实 (ground truth) 音频描述上实现了高出14%的 Sentence-BERT 相似度。

## t1_formal_004

- Batch: `expansion40`
- Context ID: `smallari_expansion40_026_low_rank_full_rank_llms_fine_tuning_memory__v02_expansion40`
- Area: `alignment, safety, fairness, and privacy`
- Top terms: `low-rank, full-rank, llms, fine-tuning, memory`
- Mean pairwise cosine: `0.1448`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh expansion neighborhood around alignment, safety, fairness, and privacy: low-rank, full-rank, llms, fine-tuning, memory. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It is intended to test whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕对齐 (alignment)、安全 (safety)、公平 (fairness) 和隐私 (privacy) 形成了一个新鲜的扩展邻域 (expansion neighborhood)：低秩 (low-rank)、全秩 (full-rank)、llms、微调 (fine-tuning)、内存 (memory)。该上下文基于论文标题、摘要和审稿人局限性信号 (limitation signals)。它旨在测试模型是否能从一个紧密的局部文献集群 (local literature cluster) 中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this expansion neighborhood around alignment, safety, fairness, and privacy: low-rank, full-rank, llms, fine-tuning, memory, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合这个围绕对齐、安全、公平和隐私的扩展邻域：低秩、全秩、llms、微调、内存，针对在提供的审稿意见和摘要中可见的局限性或评估空白 (evaluation gap)。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公共数据集和开放权重 (open-weight) 模型；用于最小验证的 <=8 A100 GPU-days；无专有模型权重；无未来论文标准答案 (future-paper answer keys)；包括来自所提供论文的一个基线 (baseline) 以及一个失败模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的可证伪 (falsifiable) 下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `LvNROciCne`
- URL: https://openreview.net/forum?id=LvNROciCne
- Title / 标题:
  - EN:
    > AdaRankGrad: Adaptive Gradient Rank and Moments for Memory-Efficient LLMs Training and Fine-Tuning
  - ZH:
    > AdaRankGrad：用于内存高效的 LLMs 训练和微调的自适应梯度秩与矩 (Moments)
- Abstract / 摘要:
  - EN:
    > Training and fine-tuning large language models (LLMs) come with challenges related to memory and computational requirements due to the increasing size of the model weights and the optimizer states. To tackle these challenges, various techniques have been developed, such as low-rank adaptation (LoRA), which involves introducing a parallel trainable low-rank matrix to the fixed pre-trained weights at each layer. However, these methods often fall short compared to the full-rank weight training approach, as they restrict the parameter search to a low-rank subspace. This limitation can disrupt training dynamics and may require a full-rank warm start to mitigate the impact. In this paper, we introduce a new method inspired by a phenomenon we formally prove: as training progresses, the rank of the estimated layer gradients gradually decreases and asymptotically approaches rank one. Leveraging this, our approach involves adaptively reducing the rank of the gradients during Adam optimization steps, using an efficient online-updating low-rank projections rule. We further present a randomized-svd scheme for efficiently finding the projection matrix. Our technique enables full-parameter fine-tuning with adaptive low-rank gradient updates, significantly reducing overall memory requirements during training compared to state-of-the-art methods while improving model performance in both pret...
  - ZH:
    > 由于模型权重和优化器状态的规模不断增加，训练和微调大型语言模型 (LLMs) 面临着与内存和计算需求相关的挑战。为了应对这些挑战，人们开发了各种技术，例如低秩自适应 (LoRA)，该技术涉及在每一层的固定预训练权重中引入一个并行的可训练低秩矩阵。然而，与全秩权重训练方法相比，这些方法通常存在不足，因为它们将参数搜索限制在低秩子空间中。这种限制可能会破坏训练动态，并可能需要全秩的热启动 (warm start) 来减轻其影响。在本文中，我们引入了一种受我们正式证明的现象启发的新方法：随着训练的进行，估计的层梯度的秩逐渐减小，并渐近趋近于秩一 (rank one)。利用这一点，我们的方法包括在使用高效的在线更新低秩投影规则的 Adam 优化步骤中，自适应地降低梯度的秩。我们进一步提出了一种 randomized-svd 方案，用于高效地寻找投影矩阵。我们的技术实现了具有自适应低秩梯度更新的全参数微调，与最先进的方法相比，显著降低了训练期间的总体内存需求，同时在 pret... 两者中提高了模型性能
- Key contribution / 关键贡献:
  - EN:
    > The authors propose AdaRankGrad that learns to adaptively perform low-rank gradient updates in order to reduce the memory requirements needed to train a large language model.
  - ZH:
    > 作者提出了 AdaRankGrad，它学习自适应地执行低秩梯度更新，以减少训练大型语言模型所需的内存需求。
- Limitation / 局限:
  - EN:
    > The results of AdaRankGrad compared to GaLore and LoRA do not seem significant in Table.
  - ZH:
    > 与 GaLore 和 LoRA 相比，AdaRankGrad 的结果在 Table 中似乎并不显著。
- Important result / 重要结果:
  - EN:
    > We further present a randomized-svd scheme for efficiently finding the projection matrix.
  - ZH:
    > 我们进一步提出了一种用于高效寻找投影矩阵的 randomized-svd 方案。

#### Paper 2

- Paper ID: `i0zzO7Hslk`
- URL: https://openreview.net/forum?id=i0zzO7Hslk
- Title / 标题:
  - EN:
    > Parameter and Memory Efficient Pretraining via Low-rank Riemannian Optimization
  - ZH:
    > 通过低秩黎曼优化实现参数和内存高效的预训练
- Abstract / 摘要:
  - EN:
    > Pretraining large language models often requires significant computational resources and memory due to their vast parameter amount. An effective approach to enhance parameter efficiency in both training and inference is to parameterize each full-size weight as the product of two trainable low-rank factors. While low-rank fine-tuning has achieved great success, low-rank pretraining remains challenging as it requires learning extensive knowledge from scratch under the restrictive low-rank parameterization. During standard low-rank pretraining, separately optimizing the low-rank factors introduces redundant information from the full gradient, which hinders the learning process. To achieve efficient yet effective low-rank pretraining, we propose a **Lo**w-rank **R**iemannian **O**ptimizer (**LORO**). At each LORO update step, the low-rank factor pairs are jointly updated to ensure their full-size product moves along the steepest descent direction on the low-rank manifold, without the need to compute any memory-intensive full-size matrices or gradients. Hence, our LORO finds low-rank models that achieve high performance comparable to full-size pretrained models, while significantly reducing memory usage and accelerating both training and inference. A LLaMA 1B model pretrained with LORO achieves a perplexity score of 2\% better than the full-size baseline, with a 54\% reduction in...
  - ZH:
    > 由于其巨大的参数量，预训练大型语言模型通常需要大量的计算资源和内存。在训练和推理中提高参数效率的一种有效方法是将每个全尺寸权重参数化为两个可训练的低秩因子（low-rank factors）的乘积。虽然低秩微调取得了巨大成功，但低秩预训练仍然具有挑战性，因为它要求在限制性的低秩参数化下从头开始学习广泛的知识。在标准低秩预训练期间，分别优化低秩因子会从全梯度中引入冗余信息，这阻碍了学习过程。为了实现高效且有效的低秩预训练，我们提出了一种低秩黎曼优化器（**Lo**w-rank **R**iemannian **O**ptimizer，**LORO**）。在每个 LORO 更新步骤中，联合更新低秩因子对，以确保它们的全尺寸乘积沿着低秩流形（low-rank manifold）上的最速下降方向移动，而无需计算任何内存密集型的全尺寸矩阵或梯度。因此，我们的 LORO 找到了能实现与全尺寸预训练模型相当的高性能的低秩模型，同时显着减少了内存使用并加速了训练和推理。使用 LORO 预训练的 LLaMA 1B 模型实现了比全尺寸基线好 2\% 的困惑度（perplexity）得分，同时在...方面减少了 54\%。
- Key contribution / 关键贡献:
  - EN:
    > The paper focuses on memory-efficient pretraining for decoder-only transformer models, particularly in the pretraining setting.
  - ZH:
    > 该论文重点关注纯解码器（decoder-only）Transformer 模型的内存高效预训练，特别是在预训练设置中。
- Limitation / 局限:
  - EN:
    > The main problem I see with the paper is that the authors do not provide a rigorous analysis supporting their central claim that independent updates of the low-rank factors are inefficient.
  - ZH:
    > 我认为该论文存在的主要问题是，作者没有提供严格的分析来支持他们的中心主张，即低秩因子的独立更新是低效的。
- Important result / 重要结果:
  - EN:
    > While low-rank fine-tuning has achieved great success, low-rank pretraining remains challenging as it requires learning extensive knowledge from scratch under the restrictive low-rank parameterization.
  - ZH:
    > 虽然低秩微调取得了巨大成功，但低秩预训练仍然具有挑战性，因为它要求在限制性的低秩参数化下从头开始学习广泛的知识。

#### Paper 3

- Paper ID: `lR7rqLtsXZ`
- URL: https://openreview.net/forum?id=lR7rqLtsXZ
- Title / 标题:
  - EN:
    > Fira: Can We Achieve Full-rank Training of LLMs Under Low-rank Constraint?
  - ZH:
    > Fira：我们能否在低秩约束下实现 LLMs 的满秩训练？
- Abstract / 摘要:
  - EN:
    > Low-rank training has emerged as a promising approach for reducing memory usage in training Large Language Models (LLMs). Previous methods either rely on decomposing weight matrices (e.g., LoRA), or seek to decompose gradient matrices (e.g., GaLore) to ensure reduced memory consumption. However, both of them constrain the training in a low-rank subspace, thus inevitably leading to sub-optimal performance. This raises a question: whether it is possible to consistently preserve the low-rank constraint for memory efficiency, while achieving full-rank training (i.e., training with full-rank gradients of full-rank weights) to avoid inferior outcomes? In this paper, we propose a new plug-and-play training framework for LLMs called Fira, as the first attempt to achieve this goal. First, we observe an interesting phenomenon during LLM training: the scaling impact of adaptive optimizers (e.g., Adam) on the gradient norm remains similar from low-rank to full-rank training. Based on this observation, we propose a norm-based scaling method, which utilizes the scaling impact of low-rank optimizers as substitutes for that of original full-rank optimizers to enable full-rank training. In this way, we can preserve the low-rank constraint in the optimizer while achieving full-rank training for better performance. Moreover, we find that there are sudden gradient rises during the optimization...
  - ZH:
    > 低秩训练已成为减少训练大型语言模型（LLMs）内存使用的一种有前景的方法。以前的方法要么依赖于分解权重矩阵（例如，LoRA），要么试图分解梯度矩阵（例如，GaLore），以确保减少内存消耗。然而，它们都将训练限制在低秩子空间中，因此不可避免地导致次优性能。这提出了一个问题：是否有可能在始终保持低秩约束以提高内存效率的同时，实现满秩训练（即使用满秩权重的满秩梯度进行训练）以避免劣质结果？在本文中，我们提出了一种名为 Fira 的新的用于 LLMs 的即插即用（plug-and-play）训练框架，作为实现该目标的首次尝试。首先，我们在 LLM 训练过程中观察到一个有趣的现象：自适应优化器（例如，Adam）对梯度范数（gradient norm）的缩放影响从低秩训练到满秩训练保持相似。基于这一观察，我们提出了一种基于范数的缩放方法，该方法利用低秩优化器的缩放影响替代原始满秩优化器的缩放影响，从而实现满秩训练。通过这种方式，我们可以在优化器中保持低秩约束，同时实现满秩训练以获得更好的性能。此外，我们发现在优化过程中存在梯度的突然上升...
- Key contribution / 关键贡献:
  - EN:
    > The paper proposes a memory-efficient training framework called Fira for the pre-training and fine-tuning of large language models (LLMs).
  - ZH:
    > 该论文提出了一种名为 Fira 的内存高效训练框架，用于大型语言模型（LLMs）的预训练和微调。
- Limitation / 局限:
  - EN:
    > Limited theoretical justification.
  - ZH:
    > 有限的理论论证。
- Important result / 重要结果:
  - EN:
    > In this paper, we propose a new plug-and-play training framework for LLMs called Fira, as the first attempt to achieve this goal.
  - ZH:
    > 在本文中，我们提出了一种名为 Fira 的新的用于 LLMs 的即插即用训练框架，作为实现该目标的首次尝试。

#### Paper 4

- Paper ID: `iEUZMISIKj`
- URL: https://openreview.net/forum?id=iEUZMISIKj
- Title / 标题:
  - EN:
    > SwitchLoRA: Switched Low-Rank Adaptation Can Learn Full-Rank Information
  - ZH:
    > SwitchLoRA：切换低秩自适应能够学习全秩信息
- Abstract / 摘要:
  - EN:
    > In the training of large language models, parameter-efficient techniques such as LoRA optimize memory usage and reduce communication overhead during the fine-tuning phase. However, applying such techniques directly during the pre-training phase results in poor performance, primarily because the premature implementation of low-rank training significantly reduces model accuracy. Existing methods like ReLoRA and GaLore have attempted to address this challenge by updating the low-rank subspace. However, they still fall short of achieving the accuracy of full-rank training because they must limit the update frequency to maintain optimizer state consistency, hindering their ability to closely approximate full-rank training behavior. In this paper, we introduce SwitchLoRA, a parameter-efficient training technique that frequently and smoothly replaces the trainable parameters of LoRA adapters with alternative parameters. SwitchLoRA updates the low-rank subspace incrementally, targeting only a few dimensions at a time to minimize the impact on optimizer states. This allows a higher update frequency, thereby enhancing accuracy by enabling the updated parameters to more closely mimic full-rank behavior during the pre-training phase. Our results demonstrate that SwitchLoRA actually surpasses full-rank training, reducing perplexity from 15.23 to 15.01 on the LLaMA 1.3B model while reduci...
  - ZH:
    > 在大型语言模型的训练中，诸如LoRA等参数高效 (parameter-efficient) 技术优化了内存使用并在微调阶段减少了通信开销。然而，在预训练阶段直接应用此类技术会导致性能不佳，主要是因为过早实施低秩训练 (low-rank training) 会显著降低模型准确率。诸如ReLoRA和GaLore等现有方法已试图通过更新低秩子空间 (low-rank subspace) 来应对这一挑战。然而，它们仍然未能达到全秩训练 (full-rank training) 的准确率，因为它们必须限制更新频率以保持优化器状态 (optimizer state) 的一致性，从而阻碍了它们紧密近似全秩训练行为的能力。在本文中，我们引入了SwitchLoRA，这是一种参数高效的训练技术，它频繁且平滑地用替代参数替换LoRA适配器 (adapters) 的可训练参数。SwitchLoRA增量式地更新低秩子空间，一次仅针对少数维度，以最小化对优化器状态的影响。这允许更高的更新频率，从而通过使更新后的参数在预训练阶段更紧密地模仿全秩行为来提高准确率。我们的结果表明，SwitchLoRA实际上超越了全秩训练，在LLaMA 1.3B模型上将困惑度 (perplexity) 从15.23降低至15.01，同时reduci...
- Key contribution / 关键贡献:
  - EN:
    > the authors proposed a method that leverages frequent parameter updates in LoRA (Low-Rank Adaptation) matrices during pre-training.
  - ZH:
    > 作者提出了一种在预训练期间利用LoRA (Low-Rank Adaptation) 矩阵中频繁的参数更新的方法。
- Limitation / 局限:
  - EN:
    > Dynamic parameter adjustment impedes scalability for very large models or environments with limited resources due to additional overhead and computational costs of scaling factors.
  - ZH:
    > 由于缩放因子 (scaling factors) 的额外开销和计算成本，动态参数调整阻碍了极大型模型或资源有限环境的可扩展性 (scalability)。
- Important result / 重要结果:
  - EN:
    > Our results demonstrate that SwitchLoRA actually surpasses full-rank training, reducing perplexity from 15.23 to 15.01 on the LLaMA 1.3B model while reducing communication overhead by 54\% on the LLaMA 1.3B model.
  - ZH:
    > 我们的结果表明，SwitchLoRA实际上超越了全秩训练，在LLaMA 1.3B模型上将困惑度 (perplexity) 从15.23降低至15.01，同时在LLaMA 1.3B模型上将通信开销减少了54\%。

## t1_formal_005

- Batch: `next40`
- Context ID: `smallari_next40_002_unlearning_forget_machine_set_classification__v02_next40`
- Area: `efficient inference and compression`
- Top terms: `unlearning, forget, machine, set, classification`
- Mean pairwise cosine: `0.088`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh next40 neighborhood around efficient inference and compression: unlearning, forget, machine, set, classification. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文形成了一个围绕高效推理和压缩的全新 next40 邻域（neighborhood）：遗忘学习（unlearning）、遗忘（forget）、机器（machine）、集合（set）、分类（classification）。该上下文基于论文标题、摘要以及审稿人的局限性信号。它测试模型能否从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this next40 neighborhood around efficient inference and compression: unlearning, forget, machine, set, classification, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合这个围绕高效推理和压缩的 next40 邻域：遗忘学习（unlearning）、遗忘（forget）、机器（machine）、集合（set）、分类（classification），针对在所提供的审稿意见和摘要中可见的局限性或评估空白（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公共数据集和开放权重模型；最小验证（minimal validation）<=8 A100 GPU-days；无专有模型权重；无未来论文答案密钥（future-paper answer keys）；包含一个来自所提供论文的基线（baseline）以及一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪的下一步测试，而不是一个广泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `KEeTRb8GLf`
- URL: https://openreview.net/forum?id=KEeTRb8GLf
- Title / 标题:
  - EN:
    > Blind Unlearning: Unlearning Without a Forget Set
  - ZH:
    > 盲遗忘 (Blind Unlearning)：无需遗忘集 (Forget Set) 的遗忘
- Abstract / 摘要:
  - EN:
    > Machine unlearning is the study of methods to efficiently remove the influence of some subset of the training data from the parameters of a previously-trained model. Existing methods typically require direct access to the “forget set” – the subset of training data to be forgotten by the model. This limitation impedes privacy, as organizations need to retain user data for the sake of unlearning when a request for deletion is made, rather than being able to delete it immediately. We first introduce the setting of blind unlearning – unlearning without explicit access to the forget set. Then, we propose a method for approximate unlearning called RELOAD, that leverages ideas from gradient-based unlearning and neural network sparsity to achieve blind unlearning. The method serially applies an ascent step with targeted parameter re-initialization and fine-tuning, and on empirical unlearning tasks, RELOAD often approximates the behaviour of a from-scratch retrained model better than approaches that leverage the forget set. Finally, we extend the blind unlearning setting to blind remedial learning, the task of efficiently updating a previously-trained model to an amended dataset.
  - ZH:
    > 机器遗忘 (Machine unlearning) 是研究从先前训练过的模型参数中高效移除部分训练数据子集影响的方法。现有方法通常需要直接访问“遗忘集 (forget set)”——即模型要遗忘的训练数据子集。这种限制阻碍了隐私，因为当提出删除请求时，组织为了遗忘的目的需要保留用户数据，而不是能够立即删除它。我们首先引入盲遗忘 (blind unlearning) 的设定——在没有明确访问遗忘集的情况下的遗忘。然后，我们提出了一种名为 RELOAD 的近似遗忘 (approximate unlearning) 方法，该方法利用基于梯度的遗忘和神经网络稀疏性的思想来实现盲遗忘。该方法依次应用带有目标参数重新初始化和微调的上升步 (ascent step)，在经验性遗忘任务上，RELOAD 通常比利用遗忘集的方法更好地近似了从头重新训练的模型的行为。最后，我们将盲遗忘设定扩展到盲补救学习 (blind remedial learning)，即高效地将先前训练过的模型更新到修正后的数据集的任务。
- Key contribution / 关键贡献:
  - EN:
    > The paper proposes the setting of Blind unlearning.
  - ZH:
    > 该论文提出了盲遗忘 (Blind unlearning) 的设定。
- Limitation / 局限:
  - EN:
    > There are three main weakness of the paper which I believe makes the paper unsuitable for publishing at its current stage.
  - ZH:
    > 这篇论文存在三个主要弱点，我认为这使得该论文在当前阶段不适合发表。
- Important result / 重要结果:
  - EN:
    > Then, we propose a method for approximate unlearning called RELOAD, that leverages ideas from gradient-based unlearning and neural network sparsity to achieve blind unlearning.
  - ZH:
    > 然后，我们提出了一种名为 RELOAD 的近似遗忘方法，该方法利用基于梯度的遗忘和神经网络稀疏性的思想来实现盲遗忘。

#### Paper 2

- Paper ID: `7tpMhoPXrL`
- URL: https://openreview.net/forum?id=7tpMhoPXrL
- Title / 标题:
  - EN:
    > Forget Vectors at Play: Universal Input Perturbations Driving Machine Unlearning in Image Classification
  - ZH:
    > 遗忘向量 (Forget Vectors) 发挥作用：驱动图像分类中机器遗忘 (Machine Unlearning) 的通用输入扰动
- Abstract / 摘要:
  - EN:
    > Machine unlearning (MU), which seeks to erase the influence of specific unwanted data from already-trained models, is becoming increasingly vital in model editing, particularly to comply with evolving data regulations like the "right to be forgotten''. Conventional approaches are predominantly model-based, typically requiring retraining or fine-tuning the model's weights to meet unlearning requirements. In this work, we approach the MU problem from a novel input perturbation-based perspective, where the model weights remain intact throughout the unlearning process. We demonstrate the existence of a proactive input-based unlearning strategy, referred to forget vector, which can be generated as an input-agnostic data perturbation and remains as effective as model-based approximate unlearning approaches. We also show that multiple given forget vectors (e.g., each targeting the unlearning of a specific data class) can be combined through simple arithmetic operations (e.g., linear combinations) to generate new forget vectors for unseen unlearning tasks (e.g., targeting the unlearning of an arbitrary subset across all classes). An additional advantage of our proposed forget vector approach is its parameter efficiency, as it eliminates the need for updating model weights. We conduct extensive experiments to validate the effectiveness of forget vector and its arithmetic for MU in im...
  - ZH:
    > 机器遗忘 (Machine unlearning, MU)，旨在从已训练好的模型中消除特定不需要的数据的影响，在模型编辑中变得越来越重要，尤其是为了遵守诸如"被遗忘权''等不断发展的数据法规。传统方法主要是基于模型的，通常需要重新训练或微调模型的权重以满足遗忘需求。在这项工作中，我们从一种新颖的基于输入扰动 (input perturbation-based) 的角度来处理 MU 问题，在整个遗忘过程中模型权重保持原封不动。我们证明了存在一种主动的基于输入的遗忘策略，称为遗忘向量 (forget vector)，它可以作为一种与输入无关 (input-agnostic) 的数据扰动被生成，并且与基于模型的近似遗忘方法一样有效。我们还展示了多个给定的遗忘向量（例如，每个都针对特定数据类的遗忘）可以通过简单的算术运算（例如，线性组合）进行组合，以为未见过的遗忘任务（例如，针对所有类中任意子集的遗忘）生成新的遗忘向量。我们提出的遗忘向量方法的另一个额外优势是其参数效率，因为它消除了更新模型权重的需要。我们进行了广泛的实验，以验证遗忘向量及其算术在 im... 中对 MU 的有效性
- Key contribution / 关键贡献:
  - EN:
    > The paper introduces an innovative approach to machine unlearning (MU) by focusing on input perturbations, using "forget vectors".
  - ZH:
    > 该论文引入了一种创新的机器遗忘 (MU) 方法，其重点在于输入扰动，并使用"遗忘向量 (forget vectors)"。
- Limitation / 局限:
  - EN:
    > While unlearning is highlighted as important, the paper would benefit from demonstrating the method in a real-world application, such as mitigating bias or removing harmful data to better showcase its utility.
  - ZH:
    > 尽管遗忘被强调为是重要的，但如果能在现实世界的应用（例如减轻偏见或移除有害数据）中展示该方法以更好地展现其效用，该论文将会从中受益。
- Important result / 重要结果:
  - EN:
    > We demonstrate the existence of a proactive input-based unlearning strategy, referred to forget vector, which can be generated as an input-agnostic data perturbation and remains as effective as model-based approximate unlearning approaches.
  - ZH:
    > 我们证明了存在一种主动的基于输入的遗忘策略，称为遗忘向量 (forget vector)，它可以作为一种与输入无关的数据扰动被生成，并且与基于模型的近似遗忘方法保持同样有效。

#### Paper 3

- Paper ID: `3vXpZpOn29`
- URL: https://openreview.net/forum?id=3vXpZpOn29
- Title / 标题:
  - EN:
    > Machine Unlearning via Simulated Oracle Matching
  - ZH:
    > 通过模拟预言机匹配进行机器遗忘
- Abstract / 摘要:
  - EN:
    > Machine unlearning---efficiently removing the effect of a small "forget set" of training data on a pre-trained machine learning model---has recently attracted significant research interest. Despite this interest, however, recent work shows that existing machine unlearning techniques do not hold up to thorough evaluation in non-convex settings. In this work, we introduce a new machine unlearning technique that exhibits strong empirical performance even in such challenging settings. Our starting point is the perspective that the goal of unlearning is to produce a model whose outputs are *statistically indistinguishable* from those of a model re-trained on all but the forget set. This perspective naturally suggests a reduction from the unlearning problem to that of *data attribution, where the goal is to predict the effect of changing the training set on a model's outputs. Thus motivated, we propose the following meta-algorithm, which we call Datamodel Matching (DMM): given a trained model, we (a) use data attribution to *predict* the output of the model if it were re-trained on all but the forget set points; then (b) *fine-tune* the pre-trained model to match these predicted outputs. In a simple convex setting, we show how this approach provably outperforms a variety of iterative unlearning algorithms. Empirically, we use a combination of existing evaluations and a new metric...
  - ZH:
    > 机器遗忘（Machine unlearning）——有效地消除一小部分训练数据"遗忘集"（forget set）对预训练机器学习模型的影响——最近引起了重大的研究兴趣。然而，尽管有这种兴趣，最近的工作表明，现有的机器遗忘技术在非凸设定（non-convex settings）的全面评估中经不起考验。在这项工作中，我们引入了一种新的机器遗忘技术，即使在这样具有挑战性的设定中也表现出很强的实证表现。我们的出发点是这样一种观点，即遗忘的目标是产生一个模型，其输出与在除遗忘集之外的所有数据上重新训练的模型的输出*在统计上不可区分*。这一观点自然地建议将遗忘问题归约为*数据归因（data attribution），其中的目标是预测改变训练集对模型输出的影响。受此启发，我们提出了以下元算法，我们称之为数据模型匹配（Datamodel Matching, DMM）：给定一个训练好的模型，我们（a）使用数据归因来*预测*如果模型在除遗忘集数据点之外的所有数据上重新训练时的输出；然后（b）*微调*（fine-tune）预训练模型以匹配这些预测的输出。在一个简单的凸设定中，我们展示了这种方法如何可证明地优于各种迭代遗忘算法。在经验上，我们使用现有评估和一项新指标的组合...
- Key contribution / 关键贡献:
  - EN:
    > The paper addresses the problem of _machine unlearning_ (removing the effect of a few training data points "forget set" on the model's outputs) with by reducing it to the problem of _data attribution_ (predicting the effect the training set on the model's outputs).
  - ZH:
    > 该论文通过将其归约为_数据归因_（预测训练集对模型输出的影响）的问题，解决了_机器遗忘_（消除少数训练数据点"遗忘集"对模型输出的影响）的问题。
- Limitation / 局限:
  - EN:
    > It is unclear that linear datamodels extend to other kinds of tasks, e.g.
  - ZH:
    > 目前尚不清楚线性数据模型能否扩展到其他类型的任务，例如
- Important result / 重要结果:
  - EN:
    > Despite this interest, however, recent work shows that existing machine unlearning techniques do not hold up to thorough evaluation in non-convex settings.
  - ZH:
    > 然而，尽管有这种兴趣，最近的工作表明，现有的机器遗忘技术在非凸设定的全面评估中经不起考验。

#### Paper 4

- Paper ID: `KzSGJy1PIf`
- URL: https://openreview.net/forum?id=KzSGJy1PIf
- Title / 标题:
  - EN:
    > Selective Unlearning via Representation Erasure Using Domain Adversarial Training
  - ZH:
    > 通过使用领域对抗训练进行表示擦除的选择性遗忘学习
- Abstract / 摘要:
  - EN:
    > When deploying machine learning models in the real world, we often face the challenge of “unlearning” specific data points or subsets after training. Inspired by Domain-Adversarial Training of Neural Networks (DANN), we propose a novel algorithm,SURE, for targeted unlearning.SURE treats the process as a domain adaptation problem, where the “forget set” (data to be removed) and a validation set from the same distribution form two distinct domains. We train a domain classifier to discriminate between representations from the forget and validation sets.Using a gradient reversal strategy similar to DANN, we perform gradient updates to the representations to “fool” the domain classifier and thus obfuscate representations belonging to the forget set. Simultaneously, gradient descent is applied to the retain set (original training data minus the forget set) to preserve its classification performance. Unlike other unlearning approaches whose training objectives are built based on model outputs, SURE directly manipulates the representations.This is key to ensure robustness against a set of more powerful attacks than currently considered in the literature, that aim to detect which examples were unlearned through access to learned embeddings. Our thorough experiments reveal that SURE has a better unlearning quality to utility trade-off compared to other standard unlearning techniques f...
  - ZH:
    > 在现实世界中部署机器学习模型时，我们经常面临在训练后对特定数据点或子集进行“遗忘学习” (unlearning) 的挑战。受神经网络领域对抗训练 (Domain-Adversarial Training of Neural Networks, DANN) 的启发，我们提出了一种用于目标遗忘学习的新颖算法 SURE。SURE 将该过程视为一个领域自适应 (domain adaptation) 问题，其中“遗忘集”（要移除的数据）和来自相同分布的验证集构成了两个不同的领域。我们训练了一个领域分类器来区分来自遗忘集和验证集的表示 (representations)。使用类似于 DANN 的梯度反转策略，我们对表示执行梯度更新以“欺骗”领域分类器，从而混淆属于遗忘集的表示。同时，将梯度下降应用于保留集（原始训练数据减去遗忘集）以保持其分类性能。与其他其训练目标基于模型输出构建的遗忘学习方法不同，SURE 直接操作表示。这是确保对一组比目前文献中考虑的更强大的攻击具有鲁棒性的关键，这些攻击旨在通过访问学习到的嵌入 (learned embeddings) 来检测哪些示例被遗忘了。我们全面的实验表明，与其他标准遗忘学习技术相比，SURE 具有更好的遗忘质量与效用权衡 f...
- Key contribution / 关键贡献:
  - EN:
    > The paper proposes a novel algorithm – SURE, for targeted unlearning.
  - ZH:
    > 该论文提出了一种用于目标遗忘学习的新颖算法——SURE。
- Limitation / 局限:
  - EN:
    > The experiments are limited to CIFAR-10 and ResNet-18, albeit with a few results on CINIC-10.
  - ZH:
    > 实验仅限于 CIFAR-10 和 ResNet-18，尽管在 CINIC-10 上有少量结果。
- Important result / 重要结果:
  - EN:
    > The paper is easy to understand.
  - ZH:
    > 该论文易于理解。

## t1_formal_006

- Batch: `next40`
- Context ID: `smallari_next40_013_multi_view_fusion_clustering_trusted_evolutionar__v02_next40`
- Area: `alignment, safety, fairness, and privacy`
- Top terms: `multi-view, fusion, clustering, trusted, evolutionary`
- Mean pairwise cosine: `0.07`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh next40 neighborhood around alignment, safety, fairness, and privacy: multi-view, fusion, clustering, trusted, evolutionary. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文构成了一个围绕对齐、安全、公平和隐私的全新 next40 邻域（neighborhood）：多视图（multi-view）、融合（fusion）、聚类（clustering）、可信（trusted）、进化（evolutionary）。该上下文建立在论文标题、摘要和审稿人的局限性信号之上。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this next40 neighborhood around alignment, safety, fairness, and privacy: multi-view, fusion, clustering, trusted, evolutionary, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕对齐、安全、公平和隐私的 next40 邻域：多视图、融合、聚类、可信、进化，针对在提供的审阅意见和摘要中可见的局限性或评估差距（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公共数据集和开放权重（open-weight）模型；用于最小化验证的 <=8 A100 GPU-days；无专有模型权重；无未来论文答案键（answer keys）；包括一个来自所提供论文的基线（baseline）以及一个失效模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构建一个最小的、可证伪的下一步测试，而不是一个广泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `M3kBtqpys5`
- URL: https://openreview.net/forum?id=M3kBtqpys5
- Title / 标题:
  - EN:
    > Trusted Multi-View Classification via Evolutionary Multi-View Fusion
  - ZH:
    > 通过进化多视图融合的可信多视图分类
- Abstract / 摘要:
  - EN:
    > Multi-view classification based on the Dempster-Shafer theory is widely recognized for its reliability in safety-critical domains with multi-view data. However, the adoption of a late fusion strategy constrains information interaction among views, thereby leading to suboptimal utilization of multi-view data. A recent advancement addressing this limitation involves generating a pseudo view by concatenating individual views. Yet, the efficacy of this pseudo view may diminish when incorporating underperforming views like noisy views. Additionally, the integration of a pseudo view exacerbates the issue of imbalanced multi-view learning, as it contains a disproportionate amount of information compared to individual views. To address these issues, we propose the enhancing Trusted multi-view classification via Evolutionary multi-view Fusion (TEF) approach. TEF employs an evolutionary multi-view architecture search method to create a high-quality fusion architecture serving as the pseudo view, facilitating adaptive view and fusion operator selection. Furthermore, TEF enhances each view within the fusion architecture by concatenating the fusion architecture's decision output with its respective view. Our experimental results demonstrate the effectiveness of this straightforward yet powerful strategy in mitigating imbalanced multi-view learning issues, particularly on complex many-vie...
  - ZH:
    > 基于Dempster-Shafer理论的多视图分类因其在具有多视图数据的安全关键领域中的可靠性而得到广泛认可。然而，采用后期融合 (late fusion) 策略限制了视图之间的信息交互，从而导致多视图数据的次优利用。解决这一局限性的最新进展涉及通过拼接 (concatenating) 各个视图来生成一个伪视图 (pseudo view)。然而，当结合诸如噪声视图等表现不佳的视图时，这种伪视图的效力可能会降低。此外，伪视图的整合加剧了不平衡多视图学习 (imbalanced multi-view learning) 的问题，因为与各个单独视图相比，它包含不成比例的信息量。为了解决这些问题，我们提出了通过进化多视图融合 (Evolutionary multi-view Fusion, TEF) 增强可信多视图分类的方法。TEF采用进化多视图架构搜索方法来创建一个高质量的融合架构作为伪视图，从而促进自适应的视图和融合算子选择。此外，TEF通过将融合架构的决策输出与其各自的视图进行拼接，来增强融合架构内的每个视图。我们的实验结果证明了这种简单而强大的策略在缓解不平衡多视图学习问题方面的有效性，特别是在复杂的多视...
- Key contribution / 关键贡献:
  - EN:
    > This paper illustrates two main issues in existing trustworthy fusion methods: the lack of feature interaction in late fusion and the insufficient attention given to multi-view imbalance, which leads to inadequate training and suboptimal performance.
  - ZH:
    > 本文阐明了现有可信融合方法中的两个主要问题：后期融合中缺乏特征交互，以及对多视图不平衡的关注不足，这导致了训练不充分和性能次优。
- Limitation / 局限:
  - EN:
    > I am interested in your concatenation operation.
  - ZH:
    > 我对你们的拼接操作 (concatenation operation) 很感兴趣。
- Important result / 重要结果:
  - EN:
    > Our experimental results demonstrate the effectiveness of this straightforward yet powerful strategy in mitigating imbalanced multi-view learning issues, particularly on complex many-view datasets exceeding three views.
  - ZH:
    > 我们的实验结果证明了这种简单而强大的策略在缓解不平衡多视图学习问题方面的有效性，特别是在超过三个视图的复杂多视图数据集上。

#### Paper 2

- Paper ID: `QQscjhKXIF`
- URL: https://openreview.net/forum?id=QQscjhKXIF
- Title / 标题:
  - EN:
    > Class-Incremental Continual Learning for Multi-View Clustering
  - ZH:
    > 多视图聚类 (Multi-View Clustering) 的类增量连续学习 (Class-Incremental Continual Learning)
- Abstract / 摘要:
  - EN:
    > Multi-view clustering (MVC) aims to explore common semantics for multi-view data and has become an active research topic. However, existing MVC methods focus on learning from static training data and ignore streaming multi-view data with incremental classes, which is frequent in real-world applications given the continually evolving nature of our world. Meanwhile, the existing continual clustering methods only consider single-view data, which cannot effectively mine the semantics of multi-view data. In this paper, we propose a novel Class-incremental Continual Multi-View Clustering (CCMVC) method to handle class-incremental continual learning for multi-view clustering, where multi-view data with incremental semantic classes come sequentially. Our method conducts two iterative optimization phases, i.e., multi-view cluster search and multi-view cluster consolidation, for sequential multi-view training data. In the test, our CCMVC can perform online multi-view clustering for all emerged classes. Firstly, CCMVC learns the common feature space for multi-view data and searches clusters for the incoming data. Secondly, CCMVC harmonizes and consolidates all learned clusters in a unified MVC model with data replay for all emerged classes. In particular, we propose a cross-view synchronous loss to mitigate the asynchronous convergence problem inherent in multi-view continual learning....
  - ZH:
    > 多视图聚类 (Multi-view clustering, MVC) 旨在探索多视图数据的公共语义，并已成为一个活跃的研究课题。然而，现有的 MVC 方法侧重于从静态训练数据中学习，而忽略了带有增量类 (incremental classes) 的流式多视图数据，鉴于我们世界不断演变的性质，这在现实世界的应用中是很频繁的。同时，现有的连续聚类 (continual clustering) 方法仅考虑单视图数据，这无法有效地挖掘多视图数据的语义。在本文中，我们提出了一种新颖的类增量连续多视图聚类 (Class-incremental Continual Multi-View Clustering, CCMVC) 方法，以处理多视图聚类的类增量连续学习，其中具有增量语义类的多视图数据按顺序到来。我们的方法针对顺序多视图训练数据执行两个迭代优化阶段，即多视图聚类搜索和多视图聚类巩固。在测试中，我们的 CCMVC 可以对所有出现的类执行在线多视图聚类。首先，CCMVC 学习多视图数据的公共特征空间，并为传入的数据搜索聚类。其次，CCMVC 将所有学到的聚类协调并巩固到一个统一的 MVC 模型中，并对所有出现的类进行数据重放 (data replay)。特别是，我们提出了一种跨视图同步损失，以缓解多视图连续学习中固有的异步收敛问题....
- Key contribution / 关键贡献:
  - EN:
    > This paper focuses on incremental learning in multi-view clustering.
  - ZH:
    > 本文侧重于多视图聚类中的增量学习。
- Limitation / 局限:
  - EN:
    > In INTRODUCTION, the authors propose two challenges.
  - ZH:
    > 在 INTRODUCTION 中，作者提出了两个挑战。
- Important result / 重要结果:
  - EN:
    > The studied problem is interesting.
  - ZH:
    > 所研究的问题很有趣。

#### Paper 3

- Paper ID: `0JTwZ30qPH`
- URL: https://openreview.net/forum?id=0JTwZ30qPH
- Title / 标题:
  - EN:
    > Task-Oriented Multi-View Representation Learning
  - ZH:
    > 面向任务的多视图表示学习
- Abstract / 摘要:
  - EN:
    > Multi-view representation learning aims to learn a high-quality unified representation for an entity from its multiple observable views to facilitate the performance of downstream tasks. A typical multi-view representation learning framework consists of four main components: View-specific encoding, Single-view learning (SVL), Multi-view learning (MVL), and Fusion. Recent studies achieve promising performance by carefully designing SVL and MVL constraints, but almost all of them ignore the basic fact that \textit{effective representations are different for different tasks, even for the same entity}. To bridge this gap, this work proposes a \textbf{T}ask-\textbf{O}riented \textbf{M}ulti-\textbf{V}iew \textbf{R}epresentation \textbf{L}earning (TOMRL) method, where the key idea is to modulate features in the View-specific encoding and Fusion modules according to the task guidance. To this end, we first design a gradient-based embedding strategy to flexibly represent multi-view tasks. After that, a meta-learner is trained to map the task embedding into a set of view-specific parameters and a view-shared parameter for modulation in the Encoding and Fusion modules, respectively. This whole process is formalized as a nested optimization problem and ultimately solved by a bi-level optimization scheme. Extensive experiments on four multi-view datasets validate that our TOMRL consisten...
  - ZH:
    > 多视图表示学习旨在从实体的多个可观测视图中为其学习一个高质量的统一表示，以促进下游任务的性能。一个典型的多视图表示学习框架由四个主要组件组成：视图特定编码 (View-specific encoding)、单视图学习 (Single-view learning, SVL)、多视图学习 (Multi-view learning, MVL) 和融合 (Fusion)。最近的研究通过精心设计 SVL 和 MVL 约束取得了大有希望的性能，但它们几乎全都忽略了一个基本事实，即 \textit{有效的表示对于不同的任务是不同的，即使对于同一个实体也是如此}。为了弥合这一差距，这项工作提出了一种 \textbf{T}ask-\textbf{O}riented \textbf{M}ulti-\textbf{V}iew \textbf{R}epresentation \textbf{L}earning (TOMRL，面向任务的多视图表示学习) 方法，其核心思想是根据任务指导在视图特定编码和融合模块中调制特征。为此，我们首先设计了一种基于梯度的嵌入策略来灵活地表示多视图任务。之后，训练一个元学习器 (meta-learner)，将任务嵌入映射为一组视图特定参数和一个视图共享参数，分别用于编码和融合模块中的调制。这整个过程被形式化为一个嵌套优化问题，并最终通过双层优化方案来求解。在四个多视图数据集上的广泛实验验证了我们的 TOMRL 始终...
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces a task-oriented multi-view representation learning method.
  - ZH:
    > 本文介绍了一种面向任务的多视图表示学习方法。
- Limitation / 局限:
  - EN:
    > The framework and methodology lack innovation, constituting a simple combination and minor extension of existing works without significant theoretical contributions.
  - ZH:
    > 该框架和方法缺乏创新性，是对现有工作的简单组合和轻微扩展，没有重大的理论贡献。
- Important result / 重要结果:
  - EN:
    > Recent studies achieve promising performance by carefully designing SVL and MVL constraints, but almost all of them ignore the basic fact that \textit{effective representations are different for different tasks, even for the same entity}.
  - ZH:
    > 最近的研究通过精心设计 SVL 和 MVL 约束取得了大有希望的性能，但它们几乎全都忽略了一个基本事实，即 \textit{有效的表示对于不同的任务是不同的，即使对于同一个实体也是如此}。

#### Paper 4

- Paper ID: `T218mLyMHg`
- URL: https://openreview.net/forum?id=T218mLyMHg
- Title / 标题:
  - EN:
    > Spectrum-guided Multi-view Graph Fusion
  - ZH:
    > 频谱引导的多视图图融合
- Abstract / 摘要:
  - EN:
    > Multi-view graphs capture diverse relations among entities through graph views and individual characteristics via attribute views, presenting a challenge for unsupervised learning due to potential conflicts across views. Existing approaches often lack efficacy, efficiency, and the ability to explicitly control view contributions. In this paper, we present SMGF, a novel graph fusion framework that approximates underlying entity connections by aggregating view-specific graph structures. We construct a multi-view Laplacian $\mathcal{L}$ from normalized Laplacian matrices representing all views. View weights are determined through the optimization of two objectives derived from $\mathcal{L}$'s spectral properties, which exploit the eigenvalue gap and enhance connectivity. Comprehensive experiments on six real-world datasets showcase the superior performance of SMGF in node embedding and clustering results, along with its efficiency and scalability. SMGF offers a promising solution for unsupervised learning on multi-view graphs, addressing the challenge of interpretably combining diverse and potentially conflicting information from both graph and attribute views. The source code of SMGF is available at \url{https://anonymous.4open.science/r/SMGF-E903/}.
  - ZH:
    > 多视图图（Multi-view graphs）通过图视图捕获实体之间的多样化关系，并通过属性视图捕获个体特征，由于视图之间潜在的冲突，这给无监督学习带来了挑战。现有方法通常缺乏有效性、效率以及明确控制视图贡献的能力。在本文中，我们提出了SMGF，这是一种新颖的图融合框架，它通过聚合特定于视图的图结构来近似潜在的实体连接。我们从表示所有视图的归一化拉普拉斯矩阵（normalized Laplacian matrices）构造了一个多视图拉普拉斯 $\mathcal{L}$。视图权重是通过优化源自 $\mathcal{L}$ 的谱性质的两个目标来确定的，这些目标利用了特征值间隙并增强了连通性。在六个真实数据集上的全面实验展示了SMGF在节点嵌入和聚类结果方面的卓越性能，以及其效率和可扩展性。SMGF为多视图图上的无监督学习提供了一个有前途的解决方案，解决了从图视图和属性视图中可解释地结合多样化且潜在冲突的信息的挑战。SMGF的源代码可在 \url{https://anonymous.4open.science/r/SMGF-E903/} 获取。
- Key contribution / 关键贡献:
  - EN:
    > This paper proposed a novel graph fusion framework that approximates underlying entity connections by aggregating view-specific graph structures, which constructs a multi-view Laplacian L from normalized Laplacian matrices representing all views.
  - ZH:
    > 本文提出了一种新颖的图融合框架，它通过聚合特定于视图的图结构来近似潜在的实体连接，该框架从表示所有视图的归一化拉普拉斯矩阵构造了一个多视图拉普拉斯 L。
- Limitation / 局限:
  - EN:
    > For attribute views, how to construct G_X?
  - ZH:
    > 对于属性视图，如何构造 G_X？
- Important result / 重要结果:
  - EN:
    > Comprehensive experiments on six real-world datasets showcase the superior performance of SMGF in node embedding and clustering results, along with its efficiency and scalability.
  - ZH:
    > 在六个真实数据集上的全面实验展示了SMGF在节点嵌入和聚类结果方面的卓越性能，以及其效率和可扩展性。

## t1_formal_007

- Batch: `next40`
- Context ID: `smallari_next40_036_clustering_manifold_k_means_algorithm_unsupervis__v02_next40`
- Area: `alignment, safety, fairness, and privacy`
- Top terms: `clustering, manifold, k-means, algorithm, unsupervised`
- Mean pairwise cosine: `0.0707`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh next40 neighborhood around alignment, safety, fairness, and privacy: clustering, manifold, k-means, algorithm, unsupervised. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文构成了一个围绕对齐 (alignment)、安全 (safety)、公平 (fairness) 和隐私 (privacy) 的全新 next40 邻域 (neighborhood)：聚类 (clustering)、流形 (manifold)、k-means、算法 (algorithm)、无监督 (unsupervised)。该上下文基于论文标题、摘要和审稿人的局限性 (limitation) 信号。它测试模型是否能从一个紧密的局部文献集群 (literature cluster) 中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this next40 neighborhood around alignment, safety, fairness, and privacy: clustering, manifold, k-means, algorithm, unsupervised, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕对齐、安全、公平和隐私的 next40 邻域：聚类、流形、k-means、算法、无监督，针对提供的审稿意见和摘要中可见的局限性或评估空白 (evaluation gap)。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重 (open-weight) 模型；最小验证 <=8 A100 GPU-days；无专有模型权重；无未来论文答案密钥 (future-paper answer keys)；包含一个来自所提供论文的基线 (baseline) 以及一个失败模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的可证伪的 (minimal falsifiable) 下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `eIYDKNqXuV`
- URL: https://openreview.net/forum?id=eIYDKNqXuV
- Title / 标题:
  - EN:
    > Village-Net clustering: A novel unsupervised manifold clustering method
  - ZH:
    > Village-Net clustering：一种新颖的无监督流形聚类方法
- Abstract / 摘要:
  - EN:
    > We present "Village-Net Clustering," a novel unsupervised clustering algorithm designed for effectively clustering complex manifold data. The algorithm operates in two primary phases: first, utilizing K-Means clustering, it divides the dataset into distinct "villages." Subsequently, a weighted network is created, where each node represents a village, capturing their proximity relationships. To attain the optimal clustering, we cluster this network using the Walk-likelihood Community Finder (WLCF), a community detection algorithm developed by one of our team members. An important feature of Village-Net Clustering is its ability to autonomously determine the optimal number of cluster. Extensive benchmarking on real datasets with known ground-truth labels showcases its competitive performance, particularly in terms of the normalized mutual information (NMI) score, when compared to state-of-the-art methods. Additionally, the algorithm demonstrates impressive computational efficiency, boasting a time complexity of O(N*k*d), where N signifies the number of instances, k represents the number of villages and d represents the dimension of the dataset, making it well-suited for effectively handling large-scale datasets.
  - ZH:
    > 我们提出了“Village-Net Clustering”，一种新颖的无监督聚类算法，旨在有效地对复杂的流形数据（manifold data）进行聚类。该算法在两个主要阶段运行：首先，利用K-Means聚类，它将数据集划分为不同的“村庄（villages）”。随后，创建一个加权网络，其中每个节点代表一个村庄，捕捉它们的邻近关系。为了获得最佳聚类，我们使用Walk-likelihood Community Finder (WLCF)对该网络进行聚类，这是一种由我们团队的一名成员开发的社区发现（community detection）算法。Village-Net Clustering的一个重要特征是其能够自主确定最佳聚类数。在具有已知真实（ground-truth）标签的真实数据集上进行的广泛基准测试展示了其具有竞争力的性能，特别是与最先进的方法相比，在归一化互信息（normalized mutual information, NMI）得分方面。此外，该算法展示了令人印象深刻的计算效率，拥有O(N*k*d)的时间复杂度，其中N表示实例数量，k表示村庄数量，d表示数据集的维度，使其非常适合有效地处理大规模数据集。
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces an unsupervised clustering algorithm called "Village-Net Clustering" for effectively clustering complex manifold data.
  - ZH:
    > 本文引入了一种称为“Village-Net Clustering”的无监督聚类算法，用于有效地对复杂的流形数据进行聚类。
- Limitation / 局限:
  - EN:
    > Dependency on K-Means Clustering: The first step of the VillageNet clustering method involves using the K-Means clustering algorithm to create initial "villages." Therefore, the performance and results of K-Means clustering have a certain dependency.
  - ZH:
    > 对K-Means聚类的依赖：VillageNet聚类方法的第一步涉及使用K-Means聚类算法来创建初始的“村庄”。因此，K-Means聚类的性能和结果具有一定的依赖性。
- Important result / 重要结果:
  - EN:
    > To attain the optimal clustering, we cluster this network using the Walk-likelihood Community Finder (WLCF), a community detection algorithm developed by one of our team members.
  - ZH:
    > 为了获得最佳聚类，我们使用Walk-likelihood Community Finder (WLCF)对该网络进行聚类，这是一种由我们团队的一名成员开发的社区发现算法。

#### Paper 2

- Paper ID: `kp3Trt4uvf`
- URL: https://openreview.net/forum?id=kp3Trt4uvf
- Title / 标题:
  - EN:
    > AuToMATo: An Out-Of-The-Box Persistence-Based Clustering Algorithm
  - ZH:
    > AuToMATo：一种开箱即用的基于持久性的聚类算法
- Abstract / 摘要:
  - EN:
    > We present AuToMATo, a novel clustering algorithm based on persistent homology. While AuToMATo is not parameter-free per se, we provide default choices for its parameters that make it into an out-of-the-box clustering algorithm that performs well across the board. AuToMATo combines the existing ToMATo clustering algorithm with a bootstrapping procedure in order to separate significant peaks of an estimated density function from non-significant ones. We perform a thorough comparison of AuToMATo (with its parameters fixed to their defaults) against many other state-of-the-art clustering algorithms. We find not only that AuToMATo compares favorably against parameter-free clustering algorithms, but in many instances also significantly outperforms even the best selection of parameters for other algorithms. AuToMATo is motivated by applications in topological data analysis, in particular the Mapper algorithm, where it is desirable to work with a clustering algorithm that does not need tuning of its parameters. Indeed, we provide evidence that AuToMATo performs well when used with Mapper. Finally, we provide an open-source implementation of AuToMATo in Python that is fully compatible with the standard scikit-learn architecture.
  - ZH:
    > 我们提出了AuToMATo，这是一种基于持久同调（persistent homology）的新型聚类算法。虽然AuToMATo本身并非无参数（parameter-free），但我们为其参数提供了默认选择，使其成为一种在各方面表现良好的开箱即用聚类算法。AuToMATo将现有的ToMATo聚类算法与自助法（bootstrapping procedure）相结合，以便将估计密度函数中的显著峰值与非显著峰值分离开来。我们将AuToMATo（其参数固定为默认值）与许多其他最先进的聚类算法进行了彻底的比较。我们发现，AuToMATo不仅与无参数聚类算法相比具有优势，而且在许多情况下甚至显著优于其他算法的最佳参数选择。AuToMATo的动机来自于拓扑数据分析（topological data analysis）中的应用，特别是Mapper算法，在这些应用中，理想的做法是使用不需要调整其参数的聚类算法。实际上，我们提供了证据表明AuToMATo在与Mapper一起使用时表现良好。最后，我们在Python中提供了AuToMATo的开源实现，它与标准的scikit-learn架构完全兼容。
- Key contribution / 关键贡献:
  - EN:
    > This paper considers and extends the ToMATo clustering algorithm, which finds clusters based on the persistent homology of a density estimate of the data.
  - ZH:
    > 本文考虑并扩展了ToMATo聚类算法，该算法基于数据密度估计的持久同调来寻找聚类（clusters）。
- Limitation / 局限:
  - EN:
    > The precise novel contribution of this paper is not completely clear.
  - ZH:
    > 本文确切的新颖贡献并不完全清楚。
- Important result / 重要结果:
  - EN:
    > We find not only that AuToMATo compares favorably against parameter-free clustering algorithms, but in many instances also significantly outperforms even the best selection of parameters for other algorithms.
  - ZH:
    > 我们发现，AuToMATo不仅与无参数聚类算法相比具有优势，而且在许多情况下甚至显著优于其他算法的最佳参数选择。

#### Paper 3

- Paper ID: `utESCpnVBN`
- URL: https://openreview.net/forum?id=utESCpnVBN
- Title / 标题:
  - EN:
    > Active Probabilistic Clustering
  - ZH:
    > 主动概率聚类
- Abstract / 摘要:
  - EN:
    > Active Constrained Clustering (ACC) is a widely used semi-supervised clustering framework to improve clustering quality through progressive annotation of informative pairwise constraints. However, the application of existing ACC methods to large datasets with numerous classes incurs high computational or query expenses. In this paper, we conduct a theoretical analysis of the inefficiency of sample-based ACC and the rationale behind cluster-based ACC. Moreover, we provide the theoretical guarantee for cluster fusion under a certain purity constraint and a clustering quality constraint with respect to normalized mutual information (NMI). Drawing on these theoretical insights, we introduce a novel Active Probabilistic Clustering (APC) framework designed to scale effectively with large datasets. Compared to previous methods, APC demonstrates superior performance across eight datasets of varying sizes (ranging from 350 to 100,000 samples) in terms of clustering quality, query cost, and computational expense. Specifically, APC accomplishes satisfactory clustering outcomes (e.g., NMI $>0.95$) using 3,920 queries on a dataset with 100,000 samples, while baseline methods yield inferior clustering results (e.g., NMI $\leq0.85$) with 10,000 queries. Concurrently, APC operates at a speed 100x faster than baseline methods.
  - ZH:
    > 主动约束聚类 (Active Constrained Clustering, ACC) 是一种广泛使用的半监督聚类框架，通过对信息丰富的成对约束进行逐步注释来提高聚类质量。然而，将现有的 ACC 方法应用于具有众多类别的大型数据集会产生很高的计算或查询开销。在本文中，我们对基于样本的 ACC 的低效性以及基于簇的 ACC 背后的基本原理进行了理论分析。此外，我们在特定的纯度约束和关于归一化互信息 (normalized mutual information, NMI) 的聚类质量约束下，为簇融合提供了理论保证。借鉴这些理论见解，我们引入了一种新颖的主动概率聚类 (Active Probabilistic Clustering, APC) 框架，旨在有效地扩展到大型数据集。与以前的方法相比，APC 在八个不同大小（范围从 350 到 100,000 个样本）的数据集上，在聚类质量、查询成本和计算开销方面展示了卓越的性能。具体而言，APC 在具有 100,000 个样本的数据集上使用 3,920 次查询完成了令人满意的聚类结果（例如，NMI $>0.95$），而基线方法使用 10,000 次查询产生较差的聚类结果（例如，NMI $\leq0.85$）。同时，APC 的运行速度比基线方法快 100 倍。
- Key contribution / 关键贡献:
  - EN:
    > This paper considers the problem of active clustering.
  - ZH:
    > 本文考虑主动聚类的问题。
- Limitation / 局限:
  - EN:
    > The writing needs some work in places.
  - ZH:
    > 写作在某些地方需要一些工作。
- Important result / 重要结果:
  - EN:
    > Active Constrained Clustering (ACC) is a widely used semi-supervised clustering framework to improve clustering quality through progressive annotation of informative pairwise constraints.
  - ZH:
    > 主动约束聚类 (Active Constrained Clustering, ACC) 是一种广泛使用的半监督聚类框架，通过对信息丰富的成对约束进行逐步注释来提高聚类质量。

#### Paper 4

- Paper ID: `E5DYpUWsES`
- URL: https://openreview.net/forum?id=E5DYpUWsES
- Title / 标题:
  - EN:
    > Manifold K-means with $\ell_{2,p}$-Norm Maximization
  - ZH:
    > 带有 $\ell_{2,p}$-范数最大化的流形 K-means
- Abstract / 摘要:
  - EN:
    > Although a variety of different methods have emerged in the field of clustering, K-means still occupies an important position, and many advanced clustering methods even rely on the K-means to achieve effective cluster detection. However, the sensitivity of K-means to the selection of the initial cluster center and its limited ability to handle nonlinear separable data somewhat restrict its clustering performance. In order to overcome the limitations of K-means, we draw inspiration from manifold learning and redefine K-means as a manifold K-means clustering framework. This framework supports various types of distance matrices, thus facilitating the efficient processing of nonlinear separable data. A unique advantage of this approach is that it does not require the calculation of the cluster center, while it maintains the consistency between manifold structure and cluster labels. Additionally, we highlight the significant role of the $\ell_{2,p}$-norm; by maximizing the $\ell_{2,p}$-norm, we can ensure the balance of classes in the clustering process, which is also supported by theoretical analysis. The results from extensive experiments across multiple databases substantiate the superiority of our proposed model.
  - ZH:
    > 尽管在聚类 (clustering) 领域涌现了各种不同的方法，K-means 仍然占据着重要的位置，许多先进的聚类方法甚至依赖于 K-means 来实现有效的簇检测 (cluster detection)。然而，K-means 对初始簇中心选择的敏感性以及其处理非线性可分数据 (nonlinear separable data) 的有限能力在一定程度上限制了其聚类性能。为了克服 K-means 的局限性，我们从流形学习 (manifold learning) 中汲取灵感，将 K-means 重新定义为流形 K-means 聚类框架。该框架支持各种类型的距离矩阵，从而促进了对非线性可分数据的高效处理。这种方法的一个独特优势是它不需要计算簇中心，同时保持了流形结构和簇标签 (cluster labels) 之间的一致性。此外，我们强调了 $\ell_{2,p}$-范数的重要作用；通过最大化 $\ell_{2,p}$-范数，我们可以确保聚类过程中类的平衡，这也得到了理论分析的支持。在多个数据库上进行的大量实验结果证实了我们提出的模型的优越性。
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces a new manifold-based K-means clustering framework that addresses limitations in standard K-means, particularly sensitivity to initial cluster centers and difficulty with nonlinearly separable data.
  - ZH:
    > 本文引入了一种新的基于流形的 K-means 聚类框架，解决了标准 K-means 中的局限性，特别是对初始簇中心的敏感性以及处理非线性可分数据的困难。
- Limitation / 局限:
  - EN:
    > 1.The paper does not fully clarify how the proposed method theoretically differs or improves upon existing manifold-based clustering methods.
  - ZH:
    > 1.该论文没有充分阐明所提出的方法在理论上与现有的基于流形的聚类方法有何不同或改进。
- Important result / 重要结果:
  - EN:
    > Although a variety of different methods have emerged in the field of clustering, K-means still occupies an important position, and many advanced clustering methods even rely on the K-means to achieve effective cluster detection.
  - ZH:
    > 尽管在聚类领域涌现了各种不同的方法，K-means 仍然占据着重要的位置，许多先进的聚类方法甚至依赖于 K-means 来实现有效的簇检测。

## t1_formal_008

- Batch: `next40`
- Context ID: `smallari_next40_038_transport_optimal_sliced_spherical_comparing__v02_next40`
- Area: `efficient inference and compression`
- Top terms: `transport, optimal, sliced, spherical, comparing`
- Mean pairwise cosine: `0.1281`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh next40 neighborhood around efficient inference and compression: transport, optimal, sliced, spherical, comparing. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文构成了一个围绕高效推理与压缩（efficient inference and compression）的全新 next40 邻域（neighborhood）：transport, optimal, sliced, spherical, comparing。该上下文基于论文标题、摘要和审稿人的局限性信号（limitation signals）。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this next40 neighborhood around efficient inference and compression: transport, optimal, sliced, spherical, comparing, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕高效推理与压缩的 next40 邻域：transport, optimal, sliced, spherical, comparing，针对在提供的审稿意见和摘要中可见的局限性或评估差距（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重（open-weight）模型；用于最小化验证的资源 <=8 A100 GPU-days；无专有模型权重；无未来论文的答案标准（answer keys）；包含一个来自所提供论文的基线（baseline），以及一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪的（falsifiable）下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `fgUFZAxywx`
- URL: https://openreview.net/forum?id=fgUFZAxywx
- Title / 标题:
  - EN:
    > Linear Spherical Sliced Optimal Transport: A Fast Metric for Comparing Spherical Data
  - ZH:
    > 线性球面切片最优传输：用于比较球面数据的快速度量
- Abstract / 摘要:
  - EN:
    > Efficient comparison of spherical probability distributions becomes important in fields such as computer vision, geosciences, and medicine. Sliced optimal transport distances, such as spherical and stereographic spherical sliced Wasserstein distances, have recently been developed to address this need. These methods reduce the computational burden of optimal transport by slicing hyperspheres into one-dimensional projections, i.e., lines or circles. Concurrently, linear optimal transport has been proposed to embed distributions into $L^2$ spaces, where the $L^2$ distance approximates the optimal transport distance, thereby simplifying comparisons across multiple distributions. In this work, we introduce the Linear Spherical Sliced Optimal Transport (LSSOT) framework, which utilizes slicing to embed spherical distributions into $L^2$ spaces while preserving their intrinsic geometry, offering a computationally efficient metric for spherical probability measures. We establish the metricity of LSSOT and demonstrate its superior computational efficiency in applications such as cortical surface registration, 3D point cloud interpolation via gradient flow, and shape embedding. Our results demonstrate the significant computational benefits and high accuracy of LSSOT in these applications.
  - ZH:
    > 球面概率分布的高效比较在计算机视觉、地球科学和医学等领域变得重要。切片最优传输（Sliced optimal transport）距离，例如球面和立体投影球面切片 Wasserstein 距离，最近已被开发以满足这一需求。这些方法通过将超球面切片为一维投影（即直线或圆），减少了最优传输的计算负担。同时，线性最优传输已被提出用于将分布嵌入到 $L^2$ 空间，其中 $L^2$ 距离近似于最优传输距离，从而简化了跨多个分布的比较。在这项工作中，我们引入了线性球面切片最优传输（Linear Spherical Sliced Optimal Transport, LSSOT）框架，该框架利用切片将球面分布嵌入到 $L^2$ 空间中，同时保留其内在几何形状，为球面概率测度提供了一种计算高效的度量。我们确立了 LSSOT 的度量性质（metricity），并在皮层表面配准（cortical surface registration）、通过梯度流进行的 3D 点云插值以及形状嵌入等应用中展示了其卓越的计算效率。我们的结果证明了 LSSOT 在这些应用中的显著计算优势和高精度。
- Key contribution / 关键贡献:
  - EN:
    > The authors propose the linear spherical sliced optimal transport framework (LSSOT) as an efficient method for comparing probability distributions on spherical manifolds.
  - ZH:
    > 作者提出了线性球面切片最优传输框架（LSSOT），作为比较球面流形上概率分布的高效方法。
- Limitation / 局限:
  - EN:
    > I have several questions about the experimental evaluation of this work, specifically as it pertains to cortical surface registration.
  - ZH:
    > 我对这项工作的实验评估有几个问题，特别是涉及皮层表面配准的部分。
- Important result / 重要结果:
  - EN:
    > We establish the metricity of LSSOT and demonstrate its superior computational efficiency in applications such as cortical surface registration, 3D point cloud interpolation via gradient flow, and shape embedding.
  - ZH:
    > 我们确立了 LSSOT 的度量性质，并在皮层表面配准、通过梯度流进行的 3D 点云插值以及形状嵌入等应用中展示了其卓越的计算效率。

#### Paper 2

- Paper ID: `P7O1Vt1BdU`
- URL: https://openreview.net/forum?id=P7O1Vt1BdU
- Title / 标题:
  - EN:
    > Expected Sliced Transport Plans
  - ZH:
    > 期望切片传输计划
- Abstract / 摘要:
  - EN:
    > The optimal transport (OT) problem has gained significant traction in modern machine learning for its ability to: (1) provide versatile metrics, such as Wasserstein distances and their variants, and (2) determine optimal couplings between probability measures. To reduce the computational complexity of OT solvers, methods like entropic regularization and sliced optimal transport have been proposed. The sliced OT framework improves efficiency by comparing one-dimensional projections (slices) of high-dimensional distributions. However, despite their computational efficiency, sliced-Wasserstein approaches lack a transportation plan between the input measures, limiting their use in scenarios requiring explicit coupling. In this paper, we address two key questions: Can a transportation plan be constructed between two probability measures using the sliced transport framework? If so, can this plan be used to define a metric between the measures? We propose a ‘lifting’ operation to extend one-dimensional optimal transport plans back to the original space of the measures. By computing the expectation of these lifted plans, we derive a new transportation plan, termed expected sliced transport (EST) plans. We further prove that using the EST plan to weight the sum of the individual Euclidean costs $\|x - y\|^p$ for moving from $x$ to $y$ results in a valid metric between the input discr...
  - ZH:
    > 最优传输（optimal transport, OT）问题在现代机器学习中获得了极大的关注，因为其能够：（1）提供多功能的度量，例如 Wasserstein 距离及其变体，以及（2）确定概率测度之间的最优耦合。为了降低 OT 求解器的计算复杂度，已经提出了熵正则化和切片最优传输等方法。切片 OT 框架通过比较高维分布的一维投影（切片）来提高效率。然而，尽管切片-Wasserstein 方法具有计算效率，但它们缺乏输入测度之间的传输计划，限制了它们在需要显式耦合的场景中的使用。在本文中，我们解决了两个关键问题：能否使用切片传输框架在两个概率测度之间构建传输计划？如果可以，这个计划能否用于定义测度之间的度量？我们提出了一种“提升（lifting）”操作，将一维最优传输计划扩展回测度的原始空间。通过计算这些提升计划的期望，我们推导出了一个新的传输计划，称为期望切片传输（expected sliced transport, EST）计划。我们进一步证明，使用 EST 计划对从 $x$ 移动到 $y$ 的个体欧几里得代价 $\|x - y\|^p$ 的总和进行加权，会产生输入 discr... 之间的一个有效度量。
- Key contribution / 关键贡献:
  - EN:
    > They propose a novel method to give transport plans between disctrete distributions on Eucledian spaces named "expected sliced transport plan".
  - ZH:
    > 他们提出了一种新颖的方法，在欧几里得空间上的离散分布（disctrete distributions）之间提供传输计划，名为“期望切片传输计划（expected sliced transport plan）”。
- Limitation / 局限:
  - EN:
    > While the motivation is computational efficiency, they do not argue it sufficiently.
  - ZH:
    > 虽然动机是计算效率，但他们并没有充分论证这一点。
- Important result / 重要结果:
  - EN:
    > The sliced OT framework improves efficiency by comparing one-dimensional projections (slices) of high-dimensional distributions.
  - ZH:
    > 切片 OT 框架通过比较高维分布的一维投影（切片）来提高效率。

#### Paper 3

- Paper ID: `FPQzXME9NK`
- URL: https://openreview.net/forum?id=FPQzXME9NK
- Title / 标题:
  - EN:
    > Spherical Tree-Sliced Wasserstein Distance
  - ZH:
    > 球面树切片Wasserstein距离
- Abstract / 摘要:
  - EN:
    > Sliced Optimal Transport (OT) simplifies the OT problem in high-dimensional spaces by projecting supports of input measures onto one-dimensional lines, then exploiting the closed-form expression of the univariate OT to reduce the computational burden of OT. Recently, the Tree-Sliced method has been introduced to replace these lines with more intricate structures, known as tree systems. This approach enhances the ability to capture topological information of integration domains in Sliced OT while maintaining low computational cost. Inspired by this approach, in this paper, we present an adaptation of tree systems on OT problem for measures supported on a sphere. As counterpart to the Radon transform variant on tree systems, we propose a novel spherical Radon transform, with a new integration domain called spherical trees. By leveraging this transform and exploiting the spherical tree structures, we derive closed-form expressions for OT problems on the sphere. Consequently, we obtain an efficient metric for measures on the sphere, named Spherical Tree-Sliced Wasserstein (STSW) distance. We provide an extensive theoretical analysis to demonstrate the topology of spherical trees, the well-definedness and injectivity of our Radon transform variant, which leads to an orthogonally invariant distance between spherical measures. Finally, we conduct a wide range of numerical experimen...
  - ZH:
    > 切片最优传输（Sliced Optimal Transport, OT）通过将输入测度的支撑集投影到一维直线上，然后利用单变量OT的闭式表达式，从而简化了高维空间中的OT问题以减少OT的计算负担。最近，引入了树切片（Tree-Sliced）方法，用称为树系统（tree systems）的更复杂结构来替代这些直线。这种方法增强了在切片OT中捕获积分域的拓扑信息的能力，同时保持了较低的计算成本。受这种方法的启发，在本文中，我们提出了树系统在支撑于球面的测度的OT问题上的改编版本。作为树系统上的Radon变换变体的对应物，我们提出了一种新颖的球面Radon变换，其具有称为球面树（spherical trees）的新积分域。通过利用这种变换并利用球面树结构，我们推导了球面上OT问题的闭式表达式。因此，我们获得了球面上测度的一种高效度量，命名为球面树切片Wasserstein（Spherical Tree-Sliced Wasserstein, STSW）距离。我们提供了广泛的理论分析，以证明球面树的拓扑结构、我们的Radon变换变体的良好定义性（well-definedness）和单射性（injectivity），这导致了球面测度之间的正交不变距离。最后，我们进行了广泛的数值实验...
- Key contribution / 关键贡献:
  - EN:
    > The paper is a natural extension of sliced spherical OT to incorporate tree systems.
  - ZH:
    > 本文是切片球面OT的自然扩展，以结合树系统。
- Limitation / 局限:
  - EN:
    > While I didn't find major weaknesses in the paper, the authors didn't provide sufficient theoretical explanation in several critical places.
  - ZH:
    > 虽然我没有在论文中发现重大弱点，但作者在几个关键地方没有提供充分的理论解释。
- Important result / 重要结果:
  - EN:
    > We provide an extensive theoretical analysis to demonstrate the topology of spherical trees, the well-definedness and injectivity of our Radon transform variant, which leads to an orthogonally invariant distance between spherical measures.
  - ZH:
    > 我们提供了广泛的理论分析，以证明球面树的拓扑结构、我们的Radon变换变体的良好定义性（well-definedness）和单射性（injectivity），这导致了球面测度之间的正交不变距离。

#### Paper 4

- Paper ID: `ueQ6T58ZAK`
- URL: https://openreview.net/forum?id=ueQ6T58ZAK
- Title / 标题:
  - EN:
    > Dynamic Representation of Optimal Transport via Ensemble Systems
  - ZH:
    > 通过系综系统的最优传输动态表示
- Abstract / 摘要:
  - EN:
    > Optimal transport has gained widespread recognition in diverse areas from economics and fluid mechanics, lately, to machine learning. However, its connection and potential applications to the domain of dynamical systems and control remain underexplored. To fill this gap, we establish an ensemble-systems interpretation for modeling the optimal transport process. We interpret displacement interpolation of the transport between continuous distributions as a dynamic process and show that this can be modeled as an ensemble control system. This is achieved by establishing moment kernel representations for describing the dynamics of optimal transport and ensemble systems. This methodology further gives rise to an optimal transport based algorithm for learning controls for ensemble systems.
  - ZH:
    > 最优传输（Optimal transport）在从经济学和流体力学，到最近的机器学习等不同领域获得了广泛的认可。然而，它与动力系统和控制领域的联系及潜在应用仍然探索不足。为了填补这一空白，我们建立了一种用于对最优传输过程进行建模的系综系统（ensemble-systems）解释。我们将连续分布之间传输的位移插值（displacement interpolation）解释为一个动态过程，并证明这可以被建模为一个系综控制系统（ensemble control system）。这是通过建立用于描述最优传输和系综系统动力学的矩核表示（moment kernel representations）来实现的。这种方法论进一步产生了一种基于最优传输的算法，用于学习系综系统的控制。
- Key contribution / 关键贡献:
  - EN:
    > The paper explores the dynamic formation of optimal transport through the use of displacement interpolation and then proposes a dynamical system, called ensemble process, whose purpose would be to track the moments (a number of them) from the trajectory described by the DI.
  - ZH:
    > 本文通过使用位移插值探索了最优传输的动态形成，然后提出了一种称为系综过程（ensemble process）的动力系统，其目的将是跟踪由 DI 描述的轨迹中的矩（其中的多个）。
- Limitation / 局限:
  - EN:
    > I have many concerns regarding the paper.
  - ZH:
    > 我对这篇论文有很多顾虑。
- Important result / 重要结果:
  - EN:
    > We interpret displacement interpolation of the transport between continuous distributions as a dynamic process and show that this can be modeled as an ensemble control system.
  - ZH:
    > 我们将连续分布之间传输的位移插值解释为一个动态过程，并证明这可以被建模为一个系综控制系统。

## t1_formal_009

- Batch: `third40`
- Context ID: `smallari_third40_004_watermarking_text_llms_language_generated__v02_third40`
- Area: `synthetic data, distillation, and data selection`
- Top terms: `watermarking, text, llms, language, generated`
- Mean pairwise cosine: `0.1214`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh third40 neighborhood around synthetic data, distillation, and data selection: watermarking, text, llms, language, generated. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕合成数据 (synthetic data)、蒸馏 (distillation) 和数据选择 (data selection) 构成了一个新的 third40 邻域：水印、文本、llms、语言、生成的。该上下文基于论文标题、摘要和审稿人的局限性信号。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this third40 neighborhood around synthetic data, distillation, and data selection: watermarking, text, llms, language, generated, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕合成数据、蒸馏和数据选择的 third40 邻域：水印、文本、llms、语言、生成的，针对所提供的评论和摘要中可见的局限性或评估差距 (evaluation gap)。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公共数据集和开放权重模型 (open-weight models)；最小化验证 <=8 A100 GPU-days；无专有模型权重；无未来论文答案键 (future-paper answer keys)；包含一个来自所提供论文的基线 (baseline) 以及一个故障模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪的 (falsifiable) 下一步测试，而不是一个广泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `jbfDg4DgAk`
- URL: https://openreview.net/forum?id=jbfDg4DgAk
- Title / 标题:
  - EN:
    > Sparse Watermarking in LLMs with Enhanced Text Quality
  - ZH:
    > 具有增强文本质量的LLMs稀疏水印
- Abstract / 摘要:
  - EN:
    > With the widespread adoption of Large Language Models (LLMs), concerns about potential misuse have emerged. To this end, watermarking has been adapted to LLM, enabling a simple and effective way to detect and monitor generated text. However, while the existing methods can differentiate between watermarked and unwatermarked text with high accuracy, they often face a trade-off between the quality of the generated text and the effectiveness of the watermarking process. In this work, we present a novel type of LLM watermark, *Sparse Watermark*, which aims to mitigate this trade-off by applying watermarks to a small subset of generated tokens distributed across the text. To demonstrate this type of watermark, we introduce **SpARK**, a **Sp**arse Waterm**ARK** method that achieves sparsity by anchoring watermarked tokens to words that have specific Part-of-Speech (POS) tags. Our experimental results demonstrate that the proposed watermarking scheme achieves high detectability while generating text that outperforms previous LLM watermarking methods in quality across various tasks.
  - ZH:
    > 随着大型语言模型（LLMs）的广泛采用，关于潜在滥用的担忧已经出现。为此，水印已被适配于LLM，从而实现了一种简单有效的方法来检测和监控生成的文本。然而，尽管现有方法能够以高准确度区分带水印和不带水印的文本，但它们通常面临在生成的文本质量与水印过程的有效性之间的权衡。在这项工作中，我们提出了一种新型的LLM水印，即*Sparse Watermark*，旨在通过将水印应用于分布在整个文本中的一小部分生成的标记（tokens）来缓解这种权衡。为了演示这种类型的水印，我们引入了**SpARK**，这是一种**Sp**arse Waterm**ARK**方法，通过将带水印的标记锚定到具有特定词性（Part-of-Speech (POS)）标签的单词来实现稀疏性。我们的实验结果表明，所提出的水印方案实现了高可检测性，同时在各种任务中生成的文本在质量上优于先前的LLM水印方法。
- Key contribution / 关键贡献:
  - EN:
    > The paper proposes SpARK, a new watermarking method for LLMs that aims to improve detectability and text quality.
  - ZH:
    > 本文提出了SpARK，这是一种用于LLMs的新水印方法，旨在提高可检测性和文本质量。
- Limitation / 局限:
  - EN:
    > While the method offers an interesting approach, it lacks significant novelty.
  - ZH:
    > 虽然该方法提供了一种有趣的途径，但它缺乏显著的新颖性。
- Important result / 重要结果:
  - EN:
    > To demonstrate this type of watermark, we introduce **SpARK**, a **Sp**arse Waterm**ARK** method that achieves sparsity by anchoring watermarked tokens to words that have specific Part-of-Speech (POS) tags.
  - ZH:
    > 为了演示这种类型的水印，我们引入了**SpARK**，这是一种**Sp**arse Waterm**ARK**方法，通过将带水印的标记锚定到具有特定词性（Part-of-Speech (POS)）标签的单词来实现稀疏性。

#### Paper 2

- Paper ID: `9k0krNzvlV`
- URL: https://openreview.net/forum?id=9k0krNzvlV
- Title / 标题:
  - EN:
    > On the Learnability of Watermarks for Language Models
  - ZH:
    > 关于语言模型水印的可学习性
- Abstract / 摘要:
  - EN:
    > Watermarking of language model outputs enables statistical detection of model-generated text, which can mitigate harms and misuses of language models. Existing watermarking strategies operate by altering the decoder of an existing language model. In this paper, we ask whether language models can directly learn to generate watermarked text, which would have significant implications for the real-world deployment of watermarks. First, learned watermarks could be used to build open models that naturally generate watermarked text, enabling watermarking for open models, where users can control the decoding procedure. Second, if watermarking is used to determine the provenance of generated text, an adversary can hurt the reputation of a victim model by spoofing its watermark and generating damaging watermarked text. To investigate the learnability of watermarks, we propose watermark distillation, which trains a student model to behave like a teacher model that uses decoding-based watermarking. We test our approach on three decoding-based watermarking strategies and various hyperparameter settings, finding that models can learn to generate watermarked text with high detectability. We also find limitations to learnability, including the loss of watermarking capabilities under fine-tuning on normal text and high sample complexity when learning low-distortion watermarks.
  - ZH:
    > 语言模型输出的水印使得能够对模型生成的文本进行统计检测，这可以减轻语言模型的危害和滥用。现有的水印策略通过改变现有语言模型的解码器来运作。在本文中，我们探究语言模型是否可以直接学习生成带水印的文本，这对水印在现实世界中的部署将具有重大影响。首先，学习到的水印可以用于构建自然生成带水印文本的开放模型 (open models)，从而实现开放模型的水印化，在这些模型中用户可以控制解码过程。其次，如果水印被用来确定生成文本的来源，对手 (adversary) 可以通过伪造其水印并生成具有破坏性的带水印文本来损害受害者模型的声誉。为了调查水印的可学习性，我们提出了水印蒸馏 (watermark distillation)，它训练一个学生模型表现得像一个使用基于解码的水印 (decoding-based watermarking) 的教师模型一样。我们在三种基于解码的水印策略和各种超参数设置上测试了我们的方法，发现模型可以学习生成具有高可检测性的带水印文本。我们还发现了可学习性的局限性，包括在正常文本上进行微调时水印能力的丧失，以及在学习低失真水印时的高样本复杂性。
- Key contribution / 关键贡献:
  - EN:
    > This paper raises a concern about forgery attacks on current LLM watermarking methods.
  - ZH:
    > 本文提出了对当前 LLM 水印方法的伪造攻击 (forgery attacks) 的担忧。
- Limitation / 局限:
  - EN:
    > This paper directly extends distillation strategies on decoding-based watermarking and then poses the limitation of weight-based watermarking.
  - ZH:
    > 本文将蒸馏策略直接扩展到基于解码的水印上，然后提出了基于权重的水印 (weight-based watermarking) 的局限性。
- Important result / 重要结果:
  - EN:
    > We test our approach on three decoding-based watermarking strategies and various hyperparameter settings, finding that models can learn to generate watermarked text with high detectability.
  - ZH:
    > 我们在三种基于解码的水印策略和各种超参数设置上测试了我们的方法，发现模型可以学习生成具有高可检测性的带水印文本。

#### Paper 3

- Paper ID: `eKGEsFdpin`
- URL: https://openreview.net/forum?id=eKGEsFdpin
- Title / 标题:
  - EN:
    > I Know You Did Not Write That! A Sampling Based Watermarking Method for Identifying Machine Generated Text
  - ZH:
    > 我知道那不是你写的！一种用于识别机器生成文本的基于采样的水印方法
- Abstract / 摘要:
  - EN:
    > Potential harms of Large Language Models such as mass misinformation and plagiarism can be partially mitigated if there exists a reliable way to detect machine generated text. In this paper, we propose a new watermarking method to detect machine-generated texts. Our method embeds a unique pattern within the generated text, ensuring that while the content remains coherent and natural to human readers, it carries distinct markers that can be identified algorithmically. Specifically, we intervene with the token sampling process in a way which enables us to trace back our token choices during the detection phase. We show how watermarking affects textual quality and compare our proposed method with a state-of-the-art watermarking method in terms of robustness and detectability. Through extensive experiments, we demonstrate the effectiveness of our watermarking scheme in distinguishing between watermarked and non-watermarked text, achieving high detection rates while maintaining textual quality.
  - ZH:
    > 如果存在一种可靠的方法来检测机器生成的文本，那么大型语言模型 (Large Language Models) 的潜在危害（例如大规模错误信息和剽窃）就可以得到部分缓解。在本文中，我们提出了一种新的水印 (watermarking) 方法来检测机器生成的文本。我们的方法在生成的文本中嵌入了一个独特的模式，确保在内容对人类读者保持连贯和自然的同时，它带有可以通过算法识别的明显标记。具体而言，我们对词元采样 (token sampling) 过程进行干预，其方式使我们能够在检测阶段追溯我们的词元 (token) 选择。我们展示了水印如何影响文本质量，并在鲁棒性 (robustness) 和可检测性 (detectability) 方面将我们提出的方法与最先进的水印方法进行了比较。通过广泛的实验，我们证明了我们的水印方案在区分带水印和不带水印的文本方面的有效性，在保持文本质量的同时实现了高检测率。
- Key contribution / 关键贡献:
  - EN:
    > The authors propose a watermarking scheme by interfering with the randomness of generating the next token.
  - ZH:
    > 作者提出了一种通过干扰生成下一个词元 (token) 的随机性来实现的水印方案。
- Limitation / 局限:
  - EN:
    > The main idea of this approach seems very similar to the one proposed by Kirchenbauer et al.
  - ZH:
    > 这种方法的主要思想似乎与 Kirchenbauer 等人提出的思想非常相似。
- Important result / 重要结果:
  - EN:
    > We show how watermarking affects textual quality and compare our proposed method with a state-of-the-art watermarking method in terms of robustness and detectability.
  - ZH:
    > 我们展示了水印如何影响文本质量，并在鲁棒性和可检测性方面将我们提出的方法与最先进的水印方法进行了比较。

#### Paper 4

- Paper ID: `JYu5Flqm9D`
- URL: https://openreview.net/forum?id=JYu5Flqm9D
- Title / 标题:
  - EN:
    > Towards Codable Watermarking for Injecting Multi-Bits Information to LLMs
  - ZH:
    > 迈向用于向LLMs注入多比特信息的可编码水印
- Abstract / 摘要:
  - EN:
    > As large language models (LLMs) generate texts with increasing fluency and realism, there is a growing need to identify the source of texts to prevent the abuse of LLMs. Text watermarking techniques have proven reliable in distinguishing whether a text is generated by LLMs by injecting hidden patterns. However, we argue that existing LLM watermarking methods are encoding-inefficient and cannot flexibly meet the diverse information encoding needs (such as encoding model version, generation time, user id, etc.). In this work, we conduct the first systematic study on the topic of **Codable Text Watermarking for LLMs** (CTWL) that allows text watermarks to carry multi-bit customizable information. First of all, we study the taxonomy of LLM watermarking technologies and give a mathematical formulation for CTWL. Additionally, we provide a comprehensive evaluation system for CTWL: (1) watermarking success rate, (2) robustness against various corruptions, (3) coding rate of payload information, (4) encoding and decoding efficiency, (5) impacts on the quality of the generated text. To meet the requirements of these non-Pareto-improving metrics, we follow the most prominent vocabulary partition-based watermarking direction, and devise an advanced CTWL method named **Balance-Marking**. The core idea of our method is to use a proxy language model to split the vocabulary into probability...
  - ZH:
    > 随着大型语言模型(LLMs)生成越来越流畅和逼真的文本，识别文本来源以防止LLMs被滥用的需求日益增长。文本水印(Text watermarking)技术已被证明能通过注入隐藏模式可靠地区分文本是否由LLMs生成。然而，我们认为现有的LLM水印方法在编码上效率低下，无法灵活满足多样的信息编码需求（例如编码模型版本、生成时间、用户id等）。在这项工作中，我们对**LLMs的可编码文本水印** (**Codable Text Watermarking for LLMs**, CTWL)这一主题进行了首次系统性研究，该主题允许文本水印携带多比特的可定制信息。首先，我们研究了LLM水印技术的分类，并给出了CTWL的数学公式化。此外，我们提供了一个全面的CTWL评估系统：(1) 水印成功率，(2) 抵抗各种破坏的鲁棒性(robustness)，(3) 载荷信息(payload information)的编码率，(4) 编码和解码效率，(5) 对生成文本质量的影响。为了满足这些非帕累托改进(non-Pareto-improving)指标的要求，我们遵循最突出的基于词表划分(vocabulary partition-based)的水印方向，并设计了一种名为**Balance-Marking**的高级CTWL方法。我们方法的核心思想是使用一个代理语言模型将词表划分为概率...
- Key contribution / 关键贡献:
  - EN:
    > In this paper, the authors propose a novel approach to inject multi-bit message information into large language models (LLMs).
  - ZH:
    > 在本文中，作者提出了一种将多比特消息信息注入到大型语言模型(LLMs)中的新方法。
- Limitation / 局限:
  - EN:
    > It is essential to compare the watermarked text with other approaches to evaluate the effectiveness of the proposed method.
  - ZH:
    > 必须将带水印的文本与其他方法进行比较，以评估所提出方法的有效性。
- Important result / 重要结果:
  - EN:
    > It is the first work to inject the multi-bit information during the generation process of LLM instead of the postprocessing.
  - ZH:
    > 这是第一项在LLM的生成过程而不是后处理(postprocessing)中注入多比特信息的工作。

## t1_formal_010

- Batch: `third40`
- Context ID: `smallari_third40_013_low_rank_adaptation_lora_fine_tuning_transformer__v02_third40`
- Area: `continual, meta, and test-time adaptation`
- Top terms: `low-rank, adaptation, lora, fine-tuning, transformer`
- Mean pairwise cosine: `0.0948`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh third40 neighborhood around continual, meta, and test-time adaptation: low-rank, adaptation, lora, fine-tuning, transformer. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文形成了一个围绕持续、元和测试时适应（continual, meta, and test-time adaptation）的全新 third40 邻域：低秩（low-rank）、适应（adaptation）、lora、微调（fine-tuning）、transformer。该背景基于论文标题、摘要和审稿人的局限性信号（limitation signals）。它测试模型是否能从一个紧密的局部文献聚类中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this third40 neighborhood around continual, meta, and test-time adaptation: low-rank, adaptation, lora, fine-tuning, transformer, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕持续、元和测试时适应的 third40 邻域：低秩、适应、lora、微调、transformer，针对所提供的审稿意见和摘要中可见的局限性或评估差距。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；最小化验证 <=8 A100 GPU-days；无专有模型权重；无未来论文答案标准（answer keys）；包含一个来自所提供论文的基线（baseline）以及一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小化的可证伪下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `likXVjmh3E`
- URL: https://openreview.net/forum?id=likXVjmh3E
- Title / 标题:
  - EN:
    > The Expressive Power of Low-Rank Adaptation
  - ZH:
    > 低秩自适应的表达能力
- Abstract / 摘要:
  - EN:
    > *Low-Rank Adaptation* (LoRA), a parameter-efficient fine-tuning method that leverages low-rank adaptation of weight matrices, has emerged as a prevalent technique for fine-tuning pre-trained models such as large language models and diffusion models. Despite its huge success in practice, the theoretical underpinnings of LoRA have largely remained unexplored. This paper takes the first step to bridge this gap by theoretically analyzing the expressive power of LoRA. We prove that, for fully connected neural networks, LoRA can adapt any model $f$ to accurately represent any smaller target model $\bar{f}$ if LoRA-rank $\geq(\text{width of }f) \times \frac{\text{depth of }\bar{f}}{\text{depth of }f}$, under a mild assumption. We also quantify the approximation error when the LoRA-rank is lower than the threshold. For Transformer networks, we show any model can be adapted to a target model of the same size with rank-$(\frac{\text{embedding size}}{2})$ LoRA adapters. All our theoretical insights are validated by numerical experiments.
  - ZH:
    > *低秩自适应*（Low-Rank Adaptation, LoRA）是一种利用权重矩阵低秩自适应的参数高效微调方法，已成为微调预训练模型（如大型语言模型和扩散模型）的流行技术。尽管在实践中取得了巨大成功，LoRA 的理论基础在很大程度上仍未被探索。本文迈出了弥合这一差距的第一步，从理论上分析了 LoRA 的表达能力。我们证明，对于全连接神经网络，在一个温和的假设下，如果 LoRA-rank $\geq(\text{width of }f) \times \frac{\text{depth of }\bar{f}}{\text{depth of }f}$，LoRA 可以使任何模型 $f$ 适应以准确表示任何更小的目标模型 $\bar{f}$。我们还量化了当 LoRA-rank 低于该阈值时的近似误差。对于 Transformer 网络，我们表明任何模型都可以通过 rank-$(\frac{\text{embedding size}}{2})$ LoRA 适配器适应到相同大小的目标模型。我们所有的理论见解都得到了数值实验的验证。
- Key contribution / 关键贡献:
  - EN:
    > While conventional fine-tuning updates all model parameters for specialized tasks, full weight updating would be prohibitive for large language models (LLMs).
  - ZH:
    > 虽然传统的微调为了专门的任务会更新所有模型参数，但全权重更新对于大型语言模型（LLMs）来说将是令人望而却步的。
- Limitation / 局限:
  - EN:
    > (1) From Figure 1, I can see that LoRA of FNN performs on par with gradient update, whereas LoRA of TFNs significantly outperform gradient updates.
  - ZH:
    > (1) 从图 1 中，我可以看到 FNN 的 LoRA 表现与梯度更新相当，而 TFNs 的 LoRA 显著优于梯度更新。
- Important result / 重要结果:
  - EN:
    > For Transformer networks, we show any model can be adapted to a target model of the same size with rank-$(\frac{\text{embedding size}}{2})$ LoRA adapters.
  - ZH:
    > 对于 Transformer 网络，我们表明任何模型都可以通过 rank-$(\frac{\text{embedding size}}{2})$ LoRA 适配器适应到相同大小的目标模型。

#### Paper 2

- Paper ID: `Lf5znhZmFu`
- URL: https://openreview.net/forum?id=Lf5znhZmFu
- Title / 标题:
  - EN:
    > Computational Limits of Low-Rank Adaptation (LoRA) Fine-Tuning for Transformer Models
  - ZH:
    > Transformer模型低秩适应（Low-Rank Adaptation (LoRA)）微调的计算极限
- Abstract / 摘要:
  - EN:
    > We study the computational limits of Low-Rank Adaptation (LoRA) for finetuning transformer-based models using fine-grained complexity theory. Our key observation is that the existence of low-rank decompositions within the gradient computation of LoRA adaptation leads to possible algorithmic speedup. This allows us to (i) identify a phase transition behavior of efficiency \blue{assuming the Strong Exponential Time Hypothesis (SETH)}, and (ii) prove the existence of almost linear algorithms by controlling the LoRA update computation term by term. For the former, we identify a sharp transition in the efficiency of all possible rank-$r$ LoRA update algorithms for transformers, based on specific norms resulting from the multiplications of the input sequence $X$, pretrained weights ${W^\star}$, and adapter matrices $\alpha B A/r$. Specifically, we derive a shared upper bound threshold for such norms and show that efficient (sub-quadratic) approximation algorithms of LoRA exist only below this threshold. For the latter, we prove the existence of almost linear approximation algorithms for LoRA adaptation by utilizing the hierarchical low-rank structures of LoRA gradients and approximating the gradients with a series of chained low-rank approximations. To showcase our theory, we consider two practical scenarios: partial (e.g., only $W_V$ and $W_Q$) and full adaptations (e.g., $W_Q$,...
  - ZH:
    > 我们使用细粒度复杂性理论研究了用于微调基于Transformer的模型的低秩适应（Low-Rank Adaptation (LoRA)）的计算极限。我们的关键观察是，LoRA适应的梯度计算中低秩分解的存在导致了可能的算法加速。这使我们能够 (i) \blue{假设强指数时间假设（Strong Exponential Time Hypothesis (SETH)）}，确定效率的相变行为，以及 (ii) 通过逐项控制LoRA更新计算，证明几乎线性的算法的存在。对于前者，基于由输入序列$X$、预训练权重${W^\star}$和适配器矩阵$\alpha B A/r$相乘产生的特定范数，我们确定了所有可能的用于Transformer的秩为$r$的LoRA更新算法在效率上的急剧转变。具体而言，我们推导了此类范数的一个共享上限阈值，并表明只有在此阈值之下才存在LoRA的高效（次二次）近似算法。对于后者，我们通过利用LoRA梯度的分层低秩结构，并使用一系列链式低秩近似来近似梯度，证明了用于LoRA适应的几乎线性近似算法的存在。为了展示我们的理论，我们考虑了两种实际场景：部分（例如，仅$W_V$和$W_Q$）和完全适应（例如，$W_Q$，...
- Key contribution / 关键贡献:
  - EN:
    > This paper studies how to make large Transformer models more computationally efficient during fine-tuning.
  - ZH:
    > 本文研究了如何在微调期间使大型Transformer模型在计算上更高效。
- Limitation / 局限:
  - EN:
    > The paper's primary focus seems to be on theoretical analysis.
  - ZH:
    > 本文的主要重点似乎是理论分析。
- Important result / 重要结果:
  - EN:
    > Specifically, we derive a shared upper bound threshold for such norms and show that efficient (sub-quadratic) approximation algorithms of LoRA exist only below this threshold.
  - ZH:
    > 具体而言，我们推导了此类范数的一个共享上限阈值，并表明只有在此阈值之下才存在LoRA的高效（次二次）近似算法。

#### Paper 3

- Paper ID: `TjfXcDgvzk`
- URL: https://openreview.net/forum?id=TjfXcDgvzk
- Title / 标题:
  - EN:
    > NOLA: Compressing LoRA using Linear Combination of Random Basis
  - ZH:
    > NOLA：使用随机基的线性组合压缩LoRA
- Abstract / 摘要:
  - EN:
    > Fine-tuning Large Language Models (LLMs) and storing them for each downstream task or domain is impractical because of the massive model size (e.g., 350GB in GPT-3). Current literature, such as LoRA, showcases the potential of low-rank modifications to the original weights of an LLM, enabling efficient adaptation and storage for task-specific models. These methods can reduce the number of parameters needed to fine-tune an LLM by several orders of magnitude. Yet, these methods face two primary limitations: (1) the parameter count is lower-bounded by the rank one decomposition, and (2) the extent of reduction is heavily influenced by both the model architecture and the chosen rank. We introduce NOLA, which overcomes the rank one lower bound present in LoRA. It achieves this by re-parameterizing the low-rank matrices in LoRA using linear combinations of randomly generated matrices (basis) and optimizing the linear mixture coefficients only. This approach allows us to decouple the number of trainable parameters from both the choice of rank and the network architecture. We present adaptation results using GPT-2, LLaMA-2, and ViT in natural language and computer vision tasks. NOLA performs as well as LoRA models with much fewer number of parameters compared to LoRA with rank one, the best compression LoRA can archive. Particularly, on LLaMA-2 70B, our method is almost 20 times mor...
  - ZH:
    > 微调大型语言模型（Large Language Models, LLMs）并为每个下游任务或领域存储它们是不切实际的，因为模型尺寸巨大（例如，GPT-3中为350GB）。当前的文献，如LoRA，展示了对LLM原始权重进行低秩修改的潜力，从而能够为特定任务模型实现高效的适应和存储。这些方法可以将微调LLM所需参数的数量减少几个数量级。然而，这些方法面临两个主要限制：（1）参数数量受到秩一分解（rank one decomposition）的下界限制，以及（2）减少的程度受到模型架构和所选秩的严重影响。我们引入了NOLA，它克服了LoRA中存在的秩一下界。它通过使用随机生成的矩阵（基）的线性组合重新参数化LoRA中的低秩矩阵，并仅优化线性混合系数来实现这一点。这种方法使我们能够将可训练参数的数量与秩的选择和网络架构解耦。我们展示了在自然语言和计算机视觉任务中使用GPT-2、LLaMA-2和ViT的适应结果。与具有秩一的LoRA（LoRA所能存档（archive）的最佳压缩）相比，NOLA在参数数量少得多的情况下，表现得和LoRA模型一样好。特别是，在LLaMA-2 70B上，我们的方法几乎是20倍的mor...
- Key contribution / 关键贡献:
  - EN:
    > Low Rank Adaptation (LoRA) presents a series of drawbacks, particularly its constrained parameter reduction due to rank-1 matrices, which cannot be further diminished.
  - ZH:
    > 低秩适应（Low Rank Adaptation, LoRA）呈现了一系列缺点，特别是其由于秩-1矩阵导致的参数减少受限，这无法进一步缩小。
- Limitation / 局限:
  - EN:
    > Poorly presented results**- The main issue in the presentation of the results lies in their lack of clarity and explanatory depth.
  - ZH:
    > 呈现不佳的结果**- 结果呈现的主要问题在于缺乏清晰度和解释深度。
- Important result / 重要结果:
  - EN:
    > Current literature, such as LoRA, showcases the potential of low-rank modifications to the original weights of an LLM, enabling efficient adaptation and storage for task-specific models.
  - ZH:
    > 当前的文献，如LoRA，展示了对LLM原始权重进行低秩修改的潜力，从而能够为特定任务模型实现高效的适应和存储。

#### Paper 4

- Paper ID: `w4abltTZ2f`
- URL: https://openreview.net/forum?id=w4abltTZ2f
- Title / 标题:
  - EN:
    > Batched Low-Rank Adaptation of Foundation Models
  - ZH:
    > 基础模型的批处理低秩适配
- Abstract / 摘要:
  - EN:
    > Low-Rank Adaptation (LoRA) has recently gained attention for fine-tuning foundation models by incorporating trainable low-rank matrices, thereby reducing the number of trainable parameters. While \lora/ offers numerous advantages, its applicability for real-time serving to a diverse and global user base is constrained by its incapability to handle multiple task-specific adapters efficiently. This imposes a performance bottleneck in scenarios requiring personalized, task-specific adaptations for each incoming request. To address this, we introduce FLoRA (Fast LoRA), a framework in which each input example in a minibatch can be associated with its unique low-rank adaptation weights, allowing for efficient batching of heterogeneous requests. We empirically demonstrate that \flora/ retains the performance merits of \lora/, showcasing competitive results on the MultiPL-E code generation benchmark spanning over 8 languages and a multilingual speech recognition task across 6 languages.
  - ZH:
    > 低秩适配 (Low-Rank Adaptation, LoRA) 最近在通过结合可训练的低秩矩阵来微调基础模型 (foundation models) 方面受到了关注，从而减少了可训练参数的数量。虽然 \lora/ 提供了许多优势，但其向多样化和全球用户群提供实时服务的适用性，因其无法有效处理多个特定任务的适配器 (adapters) 而受到限制。这在需要对每个传入请求进行个性化、特定任务适配的场景中造成了性能瓶颈。为了解决这个问题，我们引入了 FLoRA (Fast LoRA)，这是一个框架，其中小批量 (minibatch) 中的每个输入示例都可以与其独特的低秩适配权重相关联，从而允许对异构请求进行高效的批处理。我们实证证明了 \flora/ 保留了 \lora/ 的性能优点，在涵盖超过8种语言的 MultiPL-E 代码生成基准测试和跨6种语言的多语言语音识别任务上展示了具有竞争力的结果。
- Key contribution / 关键贡献:
  - EN:
    > The paper propose a new low rank adaptation technique based on a generalization of IA3.
  - ZH:
    > 该论文提出了一种基于 IA3 泛化的新低秩适配技术。
- Limitation / 局限:
  - EN:
    > The approach requires re-adapting the models that have already been adapted with LORA to leverage the improvements.
  - ZH:
    > 该方法要求重新适配已经用 LORA 适配过的模型，以利用这些改进。
- Important result / 重要结果:
  - EN:
    > We empirically demonstrate that \flora/ retains the performance merits of \lora/, showcasing competitive results on the MultiPL-E code generation benchmark spanning over 8 languages and a multilingual speech recognition task across 6 languages.
  - ZH:
    > 我们实证证明了 \flora/ 保留了 \lora/ 的性能优点，在涵盖超过8种语言的 MultiPL-E 代码生成基准测试和跨6种语言的多语言语音识别任务上展示了具有竞争力的结果。

## t1_formal_011

- Batch: `third40`
- Context ID: `smallari_third40_022_multi_modal_modality_multiple_completion_complet__v02_third40`
- Area: `continual, meta, and test-time adaptation`
- Top terms: `multi-modal, modality, multiple, completion, complete`
- Mean pairwise cosine: `0.0505`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh third40 neighborhood around continual, meta, and test-time adaptation: multi-modal, modality, multiple, completion, complete. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕持续、元和测试时适应 (continual, meta, and test-time adaptation) 形成了一个新鲜的 third40 邻域：多模态、模态、多个、补全、完整 (multi-modal, modality, multiple, completion, complete)。该上下文基于论文标题、摘要和审稿人的局限性信号 (limitation signals)。它测试模型是否能从一个紧密的局部文献聚类 (local literature cluster) 中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this third40 neighborhood around continual, meta, and test-time adaptation: multi-modal, modality, multiple, completion, complete, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕持续、元和测试时适应的 third40 邻域：多模态、模态、多个、补全、完整，针对在提供的审稿意见和摘要中可见的局限性或评估空白 (evaluation gap)。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型 (open-weight models)；最小化验证 <=8 A100 GPU-days；无专有模型权重；无未来论文标准答案 (future-paper answer keys)；包含一个来自所提供论文的基线 (baseline) 以及一个故障模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的、可证伪的 (falsifiable) 下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `oGrGnPndHw`
- URL: https://openreview.net/forum?id=oGrGnPndHw
- Title / 标题:
  - EN:
    > Autoencoder and Classifier based Joint-Guided Completion for Partial Multi-Modal Hashing
  - ZH:
    > 基于自编码器和分类器的联合引导补全用于部分多模态哈希
- Abstract / 摘要:
  - EN:
    > The Multi-Modal Hashing (MMH) method based on complete modalities cannot effectively handle incomplete multi-modal samples, thus requiring the completion of missing modalities. Existing completion methods typically use complete modality samples with the same label to generate completion information. On one hand, they cannot fully utilize the different information between samples with different labels; on the other hand, they cannot effectively extract the global structural information of multi-modal samples. Therefore, we propose the autoencoder and classifier based joint-guided completion for partial multi-modal hashing (JCPMH) method that integrates autoencoders and classifiers. First, to fully utilize the different information between samples with different labels, we design a multi-modal classification module composed of multiple classifiers to learn different information. Second, we concatenate the multi-modal data into a whole and extract cross-modal global structural information through an autoencoder. Finally, based on the hashing module, multi-modal classification module and autoencoder module, we design a loss function to guide the generator to generate more accurate completion information for learning hash codes. JCPMH can utilize partial multi-modal samples for offline training and handle incomplete multi-modal samples during online retrieval. Additionally, we co...
  - ZH:
    > 基于完整模态的多模态哈希 (Multi-Modal Hashing, MMH) 方法无法有效处理不完整的多模态样本，因此需要补全缺失的模态。现有的补全方法通常使用具有相同标签的完整模态样本来生成补全信息。一方面，它们无法充分利用不同标签样本之间的不同信息；另一方面，它们无法有效地提取多模态样本的全局结构信息。因此，我们提出了融合自编码器和分类器的、基于自编码器和分类器的联合引导补全用于部分多模态哈希 (JCPMH) 方法。首先，为了充分利用不同标签样本之间的不同信息，我们设计了一个由多个分类器组成的多模态分类模块来学习不同的信息。其次，我们将多模态数据拼接成一个整体，并通过自编码器提取跨模态的全局结构信息。最后，基于哈希模块、多模态分类模块和自编码器模块，我们设计了一个损失函数来引导生成器生成更准确的补全信息以学习哈希码。JCPMH 可以利用部分多模态样本进行离线训练，并在在线检索期间处理不完整的多模态样本。此外，我们co...
- Key contribution / 关键贡献:
  - EN:
    > In this paper, the authors present a method for partial multi-modal hashing task.
  - ZH:
    > 在本文中，作者提出了一种用于部分多模态哈希任务的方法。
- Limitation / 局限:
  - EN:
    > More details about the algorithm or the experiments should be given.
  - ZH:
    > 应该给出关于算法或实验的更多细节。
- Important result / 重要结果:
  - EN:
    > Additionally, we conducted extensive experiments to demonstrate the effectiveness of this model.
  - ZH:
    > 此外，我们进行了广泛的实验以证明该模型的有效性。

#### Paper 2

- Paper ID: `NwDiald58I`
- URL: https://openreview.net/forum?id=NwDiald58I
- Title / 标题:
  - EN:
    > OFASys: A Multi-Modal Multi-Task Learning System for Building Generalist Models
  - ZH:
    > OFASys: 用于构建通用模型的多模态多任务学习系统
- Abstract / 摘要:
  - EN:
    > Generalist models, which are capable of performing diverse multi-modal tasks in a task-agnostic way within a single model, have been explored recently. Being, hopefully, an alternative to approaching general-purpose AI, existing generalist models are still at an early stage, where modality and task coverage is limited. To empower multi-modal task-scaling and speed up this line of research, we release a generalist model learning system, OFASys, built on top of a declarative task interface named multi-modal instruction. At the core of OFASys is the idea of decoupling multi-modal task representations from the underlying model implementations. In OFASys, a task involving multiple modalities can be defined declaratively even with just a single line of code. The system automatically generates task plans from such instructions for training and inference. It also facilitates multi-task training for diverse multi-modal workloads. As a starting point, we provide presets of 7 different modalities and 23 highly-diverse example tasks in OFASys, with which we also develop a first-in-kind, single model, OFA+, that can handle text, image, speech, video, and motion data. The single OFA+ model achieves 95% performance in average with only 16% parameters of 15 task-finetuned models, showcasing the performance reliability of multi-modal task-scaling provided by OFASys.
  - ZH:
    > 最近，人们探索了能够在一个单一模型中以任务无关的方式执行各种多模态任务的通用模型（Generalist models）。现有通用模型有望成为接近通用人工智能的一种替代方案，但它们仍处于早期阶段，其模态和任务覆盖范围有限。为了赋能多模态任务扩展（task-scaling）并加速这一研究方向，我们发布了一个通用模型学习系统OFASys，该系统建立在名为多模态指令（multi-modal instruction）的声明式任务接口之上。OFASys的核心思想是将多模态任务表示与底层模型实现解耦。在OFASys中，涉及多种模态的任务甚至只需一行代码即可被声明式地定义。系统会从这些指令中自动生成用于训练和推理的任务计划。它还促进了针对各种多模态工作负载的多任务训练。作为起点，我们在OFASys中提供了7种不同模态和23个高度多样化的示例任务的预设，借助这些预设，我们还开发了同类首创的、能够处理文本、图像、语音、视频和动作数据的单一模型OFA+。单一的OFA+模型仅用15个任务微调（task-finetuned）模型的16%的参数就实现了平均95%的性能，展示了OFASys提供的多模态任务扩展的性能可靠性。
- Key contribution / 关键贡献:
  - EN:
    > This paper proposes a generalist model learning system which can combine several modalities and tasks together into just one system.
  - ZH:
    > 本文提出了一个通用模型学习系统，该系统可以将几种模态和任务结合到一个单一系统中。
- Limitation / 局限:
  - EN:
    > On page 4 and page 5, Focusing on the details of how to use this system, rather than the intrinsic insights, confuses readers and makes this paper difficult to understand.
  - ZH:
    > 在第4页和第5页，专注于如何使用该系统的细节而不是内在的见解，这使读者感到困惑并使本文难以理解。
- Important result / 重要结果:
  - EN:
    > The single OFA+ model achieves 95% performance in average with only 16% parameters of 15 task-finetuned models, showcasing the performance reliability of multi-modal task-scaling provided by OFASys.
  - ZH:
    > 单一的OFA+模型仅用15个任务微调模型的16%的参数就实现了平均95%的性能，展示了OFASys提供的多模态任务扩展的性能可靠性。

#### Paper 3

- Paper ID: `ue1Tt3h1VC`
- URL: https://openreview.net/forum?id=ue1Tt3h1VC
- Title / 标题:
  - EN:
    > Multiple Heads are Better than One: Mixture of Modality Knowledge Experts for Entity Representation Learning
  - ZH:
    > 多个头比一个好：用于实体表示学习的模态知识专家混合
- Abstract / 摘要:
  - EN:
    > Learning high-quality multi-modal entity representations is an important goal of multi-modal knowledge graph (MMKG) representation learning, which can en- hance reasoning tasks within the MMKGs, such as MMKG completion (MMKGC). The main challenge is to collaboratively model the structural information concealed in massive triples and the multi-modal features of the entities. Existing methods focus on crafting elegant entity-wise multi-modal fusion strategies, yet they over- look the utilization of multi-perspective features concealed within the modalities under diverse relational contexts. To address this issue, we introduce a novel framework with Mixture of Modality Knowledge experts (MOMOK for short) to learn adaptive multi-modal entity representations for better MMKGC. We design relation-guided modality knowledge experts to acquire relation-aware modality embeddings and integrate the predictions from multi-modalities to achieve joint decisions. Additionally, we disentangle the experts by minimizing their mutual information. Experiments on four public MMKG benchmarks demonstrate the outstanding performance of MOMOK under complex scenarios. Our code and data are available at https://github.com/zjukg/MoMoK.
  - ZH:
    > 学习高质量的多模态实体表示是多模态知识图谱 (multi-modal knowledge graph, MMKG) 表示学习的一个重要目标，这可以增强 MMKG 内的推理任务，例如 MMKG 补全 (MMKG completion, MMKGC)。主要挑战是协同建模隐藏在海量三元组中的结构信息和实体的多模态特征。现有方法专注于设计优雅的实体级多模态融合策略，但它们忽略了对在不同关系上下文中隐藏在模态内的多视角特征的利用。为了解决这个问题，我们引入了一种新颖的包含模态知识专家混合 (Mixture of Modality Knowledge experts，简称 MOMOK) 的框架，以学习自适应的多模态实体表示，从而实现更好的 MMKGC。我们设计了关系引导的模态知识专家以获取关系感知的模态嵌入，并整合来自多模态的预测以实现联合决策。此外，我们通过最小化它们的互信息来解耦专家。在四个公开的 MMKG 基准上的实验证明了 MOMOK 在复杂场景下的出色表现。我们的代码和数据可在 https://github.com/zjukg/MoMoK 获取。
- Key contribution / 关键贡献:
  - EN:
    > This paper tackles MKGE problems by proposing a Mixture of Modality Knowledge Experts framework.
  - ZH:
    > 本文通过提出模态知识专家混合框架来解决 MKGE 问题。
- Limitation / 局限:
  - EN:
    > Metrics Reporting: Table 2 displays only the Hit@1 and MRR metrics for MKG-W and MKG-Y, showing modest performance improvements for MoMoK.
  - ZH:
    > 指标报告：表 2 仅显示了 MKG-W 和 MKG-Y 的 Hit@1 和 MRR 指标，显示 MoMoK 的性能改进适中。
- Important result / 重要结果:
  - EN:
    > We design relation-guided modality knowledge experts to acquire relation-aware modality embeddings and integrate the predictions from multi-modalities to achieve joint decisions.
  - ZH:
    > 我们设计了关系引导的模态知识专家以获取关系感知的模态嵌入，并整合来自多模态的预测以实现联合决策。

#### Paper 4

- Paper ID: `PflweLMInP`
- URL: https://openreview.net/forum?id=PflweLMInP
- Title / 标题:
  - EN:
    > Complete multi-modal metric learning for multi-modal sarcasm detection
  - ZH:
    > 用于多模态讽刺检测的完整多模态度量学习
- Abstract / 摘要:
  - EN:
    > Multi-modal sarcasm detection identifies sarcasm from text-image pairs, an essential technology for accurately understanding the user's real attitude. Most research extracted the incongruity of text-image pairs as sarcasm information. However, these methods neglected inter-modal or intra-modal incongruities in fact and sentiment perspectives, leading to incomplete sarcasm information and biased performance. To address the above issues, this paper proposes a complete multi-modal metric learning network (CMML-Net) for multi-modal sarcasm detection tasks. Specifically, CMML-Net utilizes a fact-sentiment multi-task representation learning module to produce refined fact and sentiment text-image representation pairs. It then designs a complete multi-modal metric learning to iteratively calculate inter-modal and intra-modal incongruities in a unified space (e.g., fact and sentiment metric space), efficiently capturing complete multi-modal incongruities. CMML-Net performs well in explicitly capturing comprehensive sarcasm information and obtaining discriminative performance via deep metric learning. The state-of-the-art performance on the widely-used dataset demonstrates CMML-Net's effectiveness in multi-modal sarcasm detection.
  - ZH:
    > 多模态讽刺检测从文本-图像对中识别讽刺，这是准确理解用户真实态度的基本技术。大多数研究提取文本-图像对的不一致性（incongruity）作为讽刺信息。然而，这些方法忽略了事实和情感视角下的模态间（inter-modal）或模态内（intra-modal）不一致性，导致不完整的讽刺信息和有偏差的性能。为了解决上述问题，本文提出了一种用于多模态讽刺检测任务的完整多模态度量学习网络（CMML-Net）。具体而言，CMML-Net利用事实-情感多任务表示学习模块来产生细化的事实和情感文本-图像表示对。然后，它设计了一个完整的多模态度量学习，以在统一空间（例如，事实和情感度量空间）中迭代计算模态间和模态内不一致性，有效地捕获完整的多模态不一致性。CMML-Net在显式捕获全面的讽刺信息以及通过深度度量学习获得判别性性能方面表现良好。在广泛使用的数据集上最先进的（state-of-the-art）性能证明了CMML-Net在多模态讽刺检测中的有效性。
- Key contribution / 关键贡献:
  - EN:
    > The paper introduces a novel framework called the Complete Multi-Modal Metric Learning Network (CMML-Net) designed for multi-modal sarcasm detection, leveraging both text and image data.
  - ZH:
    > 本文引入了一种称为完整多模态度量学习网络（CMML-Net）的新颖框架，专为多模态讽刺检测而设计，利用了文本和图像数据。
- Limitation / 局限:
  - EN:
    > The paper lacks clarity due to some undefined symbols and terms.
  - ZH:
    > 由于一些未定义的符号和术语，本文缺乏清晰度。
- Important result / 重要结果:
  - EN:
    > The state-of-the-art performance on the widely-used dataset demonstrates CMML-Net's effectiveness in multi-modal sarcasm detection.
  - ZH:
    > 在广泛使用的数据集上最先进的（state-of-the-art）性能证明了CMML-Net在多模态讽刺检测中的有效性。

## t1_formal_012

- Batch: `third40`
- Context ID: `smallari_third40_033_graph_networks_gnn_fl_gnn_fuzzy_logic__v02_third40`
- Area: `graph, geometry, and structured learning`
- Top terms: `graph, networks, gnn, fl-gnn, fuzzy-logic`
- Mean pairwise cosine: `0.0452`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh third40 neighborhood around graph, geometry, and structured learning: graph, networks, gnn, fl-gnn, fuzzy-logic. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕图、几何和结构化学习构成了一个新鲜的 third40 邻域：graph, networks, gnn, fl-gnn, fuzzy-logic。该上下文基于论文标题、摘要和审稿人的局限性信号。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this third40 neighborhood around graph, geometry, and structured learning: graph, networks, gnn, fl-gnn, fuzzy-logic, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕图、几何和结构化学习的 third40 邻域：graph, networks, gnn, fl-gnn, fuzzy-logic，针对在提供的评审和摘要中可见的局限性或评估差距。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；最小化验证 <=8 A100 GPU-days；无专有模型权重；无未来论文答案（answer keys）；包含一个来自所提供论文的基线（baseline）和一个失败模式（failure-mode）或消融（ablation）诊断。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪的下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `RTLjdy6Ntk`
- URL: https://openreview.net/forum?id=RTLjdy6Ntk
- Title / 标题:
  - EN:
    > FL-GNN: A Fuzzy-logic Graph Neural Network
  - ZH:
    > FL-GNN：一种模糊逻辑图神经网络
- Abstract / 摘要:
  - EN:
    > This paper presents a novel hybrid fuzzy-logic Graph Neural Network (FL-GNN) by combining Fuzzy Neural network (FNN) with GNN (Graph Neural Network) to effectively capture and aggregate local information flows within graph structural data. FL-GNN by design has three novel features. First, we introduce a specific structure fuzzy rule to boost the graph inference capability of FL-GNN to be on par with the representative GNN models. Second, we enhance the interpretability of FL-GNN by adding the analytic exploration methods to its graph inference ability from two perspectives: Fuzzy Inference System and Message Passing Algorithm (MPA). Finally, we ameliorate the structure of FL-GNN based on MPA to address the inherent limitations of FL-GNN. This optimization can reduce the calculation complexity of FL-GNN and further improve its learning efficiency. Extensive experiments are conducted to validate the graph inference capability of FL-GNN and report the performance comparison against other widely used GNN models. The results demonstrate that FL-GNN can outperform existing representative graph neural networks for graph inference tasks.
  - ZH:
    > 本文提出了一种新颖的混合模糊逻辑图神经网络 (fuzzy-logic Graph Neural Network, FL-GNN)，通过将模糊神经网络 (Fuzzy Neural network, FNN) 与 GNN (图神经网络, Graph Neural Network) 相结合，以有效地捕获和聚合图结构数据内的局部信息流。FL-GNN 在设计上具有三个新颖特征。首先，我们引入了一种特定结构的模糊规则，以提升 FL-GNN 的图推理能力，使其与具有代表性的 GNN 模型不相上下。其次，我们通过从两个角度（模糊推理系统 (Fuzzy Inference System) 和消息传递算法 (Message Passing Algorithm, MPA)）为其图推理能力添加分析探索方法，增强了 FL-GNN 的可解释性。最后，我们基于 MPA 改进了 FL-GNN 的结构，以解决 FL-GNN 的固有局限性。这种优化可以降低 FL-GNN 的计算复杂度，并进一步提高其学习效率。我们进行了大量实验以验证 FL-GNN 的图推理能力，并报告了与其他广泛使用的 GNN 模型的性能比较。结果表明，对于图推理任务，FL-GNN 能够优于现有的代表性图神经网络。
- Key contribution / 关键贡献:
  - EN:
    > The authors propose a combination of Takagi-Sugeno Fuzzy Neural Networks (TS-FNNs) and Graph Neural Networks (GNNs), which they call a Fuzzy-Logic Graph Neural Network (FL-GNN).
  - ZH:
    > 作者提出了一种 Takagi-Sugeno 模糊神经网络 (Takagi-Sugeno Fuzzy Neural Networks, TS-FNNs) 和图神经网络 (Graph Neural Networks, GNNs) 的结合，他们将其称为模糊逻辑图神经网络 (Fuzzy-Logic Graph Neural Network, FL-GNN)。
- Limitation / 局限:
  - EN:
    > I see the following four weaknesses, ordered descendingly by importance: First, the paper does not provide convincing evidence that the proposed FL-GNN architecture has consistent, measurable advantages over existing GNN architectures.
  - ZH:
    > 我看到了以下四个弱点，按重要性降序排列：第一，该论文没有提供令人信服的证据证明所提出的 FL-GNN 架构比现有的 GNN 架构具有一致的、可衡量的优势。
- Important result / 重要结果:
  - EN:
    > This optimization can reduce the calculation complexity of FL-GNN and further improve its learning efficiency.
  - ZH:
    > 这种优化可以降低 FL-GNN 的计算复杂度，并进一步提高其学习效率。

#### Paper 2

- Paper ID: `exnoX9Iaik`
- URL: https://openreview.net/forum?id=exnoX9Iaik
- Title / 标题:
  - EN:
    > GL-Fusion: Rethinking the Combination of Graph Neural Network and Large Language model
  - ZH:
    > GL-Fusion：重新思考图神经网络 (Graph Neural Network) 和大型语言模型 (Large Language model) 的结合
- Abstract / 摘要:
  - EN:
    > Recent research on integrating Large Language Models (LLMs) with Graph Neural Networks (GNNs) typically follows two approaches: LLM-centered models, which convert graph data into tokens for LLM processing, and GNN-centered models, which use LLMs to encode text features into node and edge representations for GNN input. LLM-centered models often struggle to capture graph structures effectively, while GNN-centered models compress variable-length textual data into fixed-size vectors, limiting their ability to understand complex semantics. Additionally, GNN-centered approaches require converting tasks into a uniform, manually-designed format, restricting them to classification tasks and preventing language output. To address these limitations, we introduce a new architecture that deeply integrates GNN with LLM, featuring three key innovations: (1) Structure-Aware Transformers, which incorporate GNN’s message-passing capabilities directly into LLM’s transformer layers, allowing simultaneous processing of textual and structural information and generating outputs from both GNN and LLM; (2) Graph-Text Cross-Attention, which processes full, uncompressed text from graph nodes and edges, ensuring complete semantic integration; and (3) GNN-LLM Twin Predictor, enabling LLM’s flexible autoregressive generation alongside GNN’s scalable one-pass prediction. GL-Fusion achieves outstand perfor...
  - ZH:
    > 近期关于将大型语言模型 (LLMs) 与图神经网络 (GNNs) 集成的研究通常遵循两种方法：以LLM为中心的模型，将图数据转换为token供LLM处理；以及以GNN为中心的模型，使用LLMs将文本特征编码为节点和边缘表示以供GNN输入。以LLM为中心的模型通常难以有效地捕捉图结构，而以GNN为中心的模型将可变长度的文本数据压缩为固定大小的向量，限制了它们理解复杂语义的能力。此外，以GNN为中心的方法需要将任务转换为统一的、手动设计的格式，将其限制在分类任务并阻止了语言输出。为了解决这些局限性，我们引入了一种将GNN与LLM深度整合的新架构，具有三个关键创新：(1) 结构感知Transformer (Structure-Aware Transformers)，将GNN的消息传递能力直接融入LLM的transformer层中，允许同时处理文本和结构信息，并从GNN和LLM双方面生成输出；(2) 图-文交叉注意力 (Graph-Text Cross-Attention)，处理来自图节点和边缘的完整、未压缩文本，确保完全的语义整合；以及 (3) GNN-LLM双预测器 (GNN-LLM Twin Predictor)，使LLM灵活的自回归生成能够与GNN可扩展的单次预测 (one-pass prediction) 并存。GL-Fusion实现了出色的表...
- Key contribution / 关键贡献:
  - EN:
    > This paper proposed a method to combine GNN and transformer architecture to learn the graph tasks.
  - ZH:
    > 本文提出了一种结合GNN和transformer架构来学习图任务的方法。
- Limitation / 局限:
  - EN:
    > The proposed method is complex which includes three components: text and graph token transformers, text to graph token attention module, and GNN prediction module.
  - ZH:
    > 所提出的方法很复杂，包含三个组件：文本和图token transformer、文本到图token注意力模块，以及GNN预测模块。
- Important result / 重要结果:
  - EN:
    > GL-Fusion achieves outstand performance on various tasks.
  - ZH:
    > GL-Fusion在各种任务上实现了出色的表现。

#### Paper 3

- Paper ID: `mxkm1Pr2PM`
- URL: https://openreview.net/forum?id=mxkm1Pr2PM
- Title / 标题:
  - EN:
    > Graph Neural Network Is A Mean Field Game
  - ZH:
    > 图神经网络是一个平均场博弈 (Mean Field Game)
- Abstract / 摘要:
  - EN:
    > In current graph neural networks (GNNs), it is a common practice to apply a pre-defined message passing heuristics to all graph data, even though the stereotypical relational inductive bias (e.g., graph heat diffusion) might not fit the unseen graph topology. Such gross simplification might be responsible for the lack of an in-depth understanding of graph learning principles, which challenges us to push the boundary from crafting application-specific GNNs to embracing a "meta-learning" paradigm. In this work, we ratchet the gear of GNN another notch forward by formulating GNN as a *mean field game*, that is, the best learning outcome occurs at the *Nash*-equilibrium when the learned graph inference rationale allows each graph node to find what is the best feature representations for not only the individual node but also the entire graph. Following this spirit, we formulate the search for novel GNN mechanism into a variational framework of *mean-field control* (MFC) problem, where the optimal relational inductive bias is essentially the critical point of mean-field information dynamics. Specifically, we seek for the best characteristic MFC functions of transportation mobility (controlling information exchange throughout the graph) and reaction mobility (controlling feature representation learning on each node), on the fly, that uncover the most suitable learning mechanism for...
  - ZH:
    > 在当前的图神经网络 (GNNs) 中，对所有图数据应用预定义的消息传递启发式方法 (message passing heuristics) 是一种常见做法，即使刻板的关系归纳偏置 (relational inductive bias)（例如，图热扩散）可能并不适合未见的图拓扑。这种严重的简化可能是导致缺乏对图学习原理深入理解的原因，这挑战我们将边界从制作特定于应用的 GNNs 推进到拥抱“元学习” ("meta-learning") 范式。在这项工作中，我们通过将 GNN 公式化为*平均场博弈* (*mean field game*)，将 GNN 的齿轮向前拨动了一格，也就是说，当学习到的图推断基本原理 (inference rationale) 允许每个图节点不仅为单个节点而且为整个图找到什么是最佳特征表示时，最佳学习结果出现在*纳什* (*Nash*)-均衡处。遵循这种精神，我们将对新型 GNN 机制的搜索公式化为*平均场控制* (*mean-field control*, MFC) 问题的变分框架 (variational framework)，其中最佳的关系归纳偏置本质上是平均场信息动力学的临界点。具体而言，我们即时地 (on the fly) 寻找传输移动性 (transportation mobility)（控制整个图的信息交换）和反应移动性 (reaction mobility)（控制每个节点上的特征表示学习）的最佳特征 MFC 函数，从而揭示出用于...的最合适的学习机制
- Key contribution / 关键贡献:
  - EN:
    > This paper proposes a variational framework for abstract learning in Graph Neural Networks (GNNs) from a mean-field control perspective.
  - ZH:
    > 本文从平均场控制 (mean-field control) 的角度提出了一个用于图神经网络 (GNNs) 中抽象学习的变分框架 (variational framework)。
- Limitation / 局限:
  - EN:
    > While the proposed framework is intriguing, it does not address several important challenges such as over-smoothing, over-squashing, and the ability to capture long-range dependencies in graphs.
  - ZH:
    > 虽然提出的框架很有趣，但它没有解决几个重要的挑战，例如过度平滑 (over-smoothing)、过度挤压 (over-squashing) 以及捕获图中长程依赖 (long-range dependencies) 的能力。
- Important result / 重要结果:
  - EN:
    > In this work, we ratchet the gear of GNN another notch forward by formulating GNN as a *mean field game*, that is, the best learning outcome occurs at the *Nash*-equilibrium when the learned graph inference rationale allows each graph node to find what is the best feature representations for not only the individual node but also the entire graph.
  - ZH:
    > 在这项工作中，我们通过将 GNN 公式化为*平均场博弈* (*mean field game*)，将 GNN 的齿轮向前拨动了一格，也就是说，当学习到的图推断基本原理 (inference rationale) 允许每个图节点不仅为单个节点而且为整个图找到什么是最佳特征表示时，最佳学习结果出现在*纳什* (*Nash*)-均衡处。

#### Paper 4

- Paper ID: `fyCPspuM5L`
- URL: https://openreview.net/forum?id=fyCPspuM5L
- Title / 标题:
  - EN:
    > PowerGraph: A power grid benchmark dataset for graph neural networks
  - ZH:
    > PowerGraph：一个用于图神经网络的电网基准数据集
- Abstract / 摘要:
  - EN:
    > Public Graph Neural Networks (GNN) benchmark datasets facilitate the use of GNN and enhance GNN applicability to diverse disciplines. The community currently lacks public datasets of electrical power grids for GNN applications. Indeed, GNNs have the potential for capturing complex power grid phenomena over alternative machine learning techniques. Power grids are complex engineered networks that are naturally amenable to graph representations. Therefore, GNN have the potential for capturing the behaviour of power grids over alternative machine learning techniques. To this aim, we develop a graph dataset for cascading failure events, which are the major cause of blackouts in electric power grids. Historical blackout datasets are scarce and incomplete. The assessment of vulnerability and the identification of critical components are usually conducted via computationally expensive offline simulations of cascading failures. Instead, we propose the use of machine learning models for the online detection of cascading failures leveraging the knowledge of the system state at the onset of the cascade. We develop PowerGraph, a graph dataset modelling cascading failures in power grids, designed for two purposes, namely, i) training GNN models for different graph-level tasks including multi-class classification, binary classification, and regression, and ii) explaining GNN models. The da...
  - ZH:
    > 公开的图神经网络（Graph Neural Networks, GNN）基准数据集促进了GNN的使用，并增强了GNN对不同学科的适用性。社区目前缺乏用于GNN应用的电网公开数据集。事实上，与替代的机器学习技术相比，GNN具有捕捉复杂电网现象的潜力。电网是复杂的工程网络，自然适合图表示。因此，与替代的机器学习技术相比，GNN具有捕捉电网行为的潜力。为此，我们开发了一个用于级联故障（cascading failure）事件的图数据集，这是导致电网停电的主要原因。历史停电数据集稀缺且不完整。脆弱性评估和关键组件的识别通常是通过计算成本高昂的级联故障离线模拟来进行的。相反，我们建议利用级联开始时的系统状态知识，使用机器学习模型在线检测级联故障。我们开发了PowerGraph，这是一个对电网中级联故障进行建模的图数据集，专为两个目的而设计，即：i) 训练GNN模型以执行不同的图级（graph-level）任务，包括多类分类、二元分类和回归，以及 ii) 解释GNN模型。该数...
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces "PowerGraph," a GNN dataset for power grid analysis.
  - ZH:
    > 本文介绍了“PowerGraph”，这是一个用于电网分析的GNN数据集。
- Limitation / 局限:
  - EN:
    > The dataset generation method is limited.
  - ZH:
    > 数据集生成方法具有局限性。
- Important result / 重要结果:
  - EN:
    > The motivation is clear.
  - ZH:
    > 动机明确。

## t1_formal_013

- Batch: `fourth40`
- Context ID: `smallari_fourth40_004_conformal_uncertainty_prediction_control_predict__v02_fourth40`
- Area: `alignment, safety, fairness, and privacy`
- Top terms: `conformal, uncertainty, prediction, control, predictors`
- Mean pairwise cosine: `0.0934`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fourth40 neighborhood around alignment, safety, fairness, and privacy: conformal, uncertainty, prediction, control, predictors. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文在对齐 (alignment)、安全 (safety)、公平 (fairness) 和隐私 (privacy) 周围形成了一个新的 fourth40 邻域：共形 (conformal)、不确定性 (uncertainty)、预测 (prediction)、控制 (control)、预测器 (predictors)。该上下文基于论文标题、摘要和审稿人的局限性信号。它测试模型能否从一个紧密的局部文献聚类中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fourth40 neighborhood around alignment, safety, fairness, and privacy: conformal, uncertainty, prediction, control, predictors, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕对齐、安全、公平和隐私的 fourth40 邻域：共形、不确定性、预测、控制、预测器，针对在提供的审稿意见和摘要中可见的局限性或评估空白。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；最小验证 <=8 A100 GPU-days；无专有模型权重；无未来论文答案键 (future-paper answer keys)；包含一个来自所提供论文的基线 (baseline) 和一个失败模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的可证伪的 (falsifiable) 下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `xiQNfYl33p`
- URL: https://openreview.net/forum?id=xiQNfYl33p
- Title / 标题:
  - EN:
    > A Generic Framework for Conformal Fairness
  - ZH:
    > 一个用于共形公平（Conformal Fairness）的通用框架
- Abstract / 摘要:
  - EN:
    > Conformal Prediction (CP) is a popular method for uncertainty quantification with machine learning models. While conformal prediction provides probabilistic guarantees regarding the coverage of the true label, these guarantees are agnostic to the presence of sensitive attributes within the dataset. In this work, we formalize \textit{Conformal Fairness}, a notion of fairness using conformal predictors, and provide a theoretically well-founded algorithm and associated framework to control for the gaps in coverage between different sensitive groups. Our framework leverages the exchangeability assumption (implicit to CP) rather than the typical IID assumption, allowing us to apply the notion of Conformal Fairness to data types and tasks that are not IID, such as graph data. Experiments were conducted on graph and tabular datasets to demonstrate that the algorithm can control fairness-related gaps in addition to coverage aligned with theoretical expectations.
  - ZH:
    > 共形预测（Conformal Prediction, CP）是一种使用机器学习模型进行不确定性量化的流行方法。虽然共形预测提供了关于真实标签覆盖率（coverage）的概率保证，但这些保证对数据集中存在的敏感属性是不可知的。在这项工作中，我们形式化了 \textit{Conformal Fairness}（共形公平），这是一种使用共形预测器的公平性概念，并提供了一个理论基础完善的算法及相关框架，以控制不同敏感群体之间的覆盖率差距。我们的框架利用了可交换性假设（exchangeability assumption，CP中隐含的假设）而不是典型的IID假设，允许我们将共形公平的概念应用于非IID的数据类型和任务，例如图数据。在图和表格数据集上进行了实验，以证明该算法除了实现与理论预期一致的覆盖率外，还能控制与公平性相关的差距。
- Key contribution / 关键贡献:
  - EN:
    > The manuscript introduces and studies a general-purpose conformal fairness framework.
  - ZH:
    > 该手稿介绍并研究了一个通用的共形公平框架。
- Limitation / 局限:
  - EN:
    > The main weakness and bottleneck at this point is the writing of the manuscript.
  - ZH:
    > 目前主要的弱点和瓶颈是手稿的写作。
- Important result / 重要结果:
  - EN:
    > Experiments were conducted on graph and tabular datasets to demonstrate that the algorithm can control fairness-related gaps in addition to coverage aligned with theoretical expectations.
  - ZH:
    > 在图和表格数据集上进行了实验，以证明该算法除了实现与理论预期一致的覆盖率外，还能控制与公平性相关的差距。

#### Paper 2

- Paper ID: `yINucFNbcZ`
- URL: https://openreview.net/forum?id=yINucFNbcZ
- Title / 标题:
  - EN:
    > Improving the efficiency of conformal predictors via test-time augmentation
  - ZH:
    > 通过测试时数据增强 (test-time augmentation) 提高共形预测器 (conformal predictors) 的效率
- Abstract / 摘要:
  - EN:
    > In conformal classification, the goal is to output a _set_ of predicted classes, accompanied by a probabilistic guarantee that the set includes the true class. Conformal approaches have gained widespread traction across domains because they can be composed with existing classifiers to generate predictions with probabilistically valid uncertainty estimates. In practice, however, the utility of conformal prediction is limited by its tendency to yield large prediction sets. We study this phenomenon and provide insights into why large set sizes persist, even for conformal methods designed to produce small sets. Using these insights, we propose a method to reduce prediction set size while maintaining coverage. We use test-time augmentation to replace a classifier's predicted probabilities with probabilites aggregated over a set of augmentations. Our approach is flexible, computationally efficient, and effective. It can be combined with any conformal score, requires no model retraining, and reduces prediction set sizes by up to 30\%. We conduct an evaluation of the approach spanning three datasets, three models, two established conformal scoring methods, and multiple coverage values to show when and why test-time augmentation is a useful addition to the conformal pipeline.
  - ZH:
    > 在共形分类 (conformal classification) 中，目标是输出一个预测类别的_集合_，并附带该集合包含真实类别的概率保证。共形方法在各个领域获得了广泛的关注，因为它们可以与现有的分类器组合，以生成具有概率上有效的不确定性估计的预测。然而在实践中，共形预测 (conformal prediction) 的实用性受到其倾向于产生较大预测集合的限制。我们研究了这一现象，并提供关于为什么即使是旨在产生小集合的共形方法，大集合规模仍然持续存在的见解。利用这些见解，我们提出了一种在保持覆盖率 (coverage) 的同时减小预测集合大小的方法。我们使用测试时数据增强 (test-time augmentation) ，用在一组增强上聚合的概率来替换分类器的预测概率。我们的方法灵活、计算高效且有效。它可以与任何共形分数 (conformal score) 结合使用，无需模型重新训练，并且可将预测集合大小减小多达 30\%。我们对该方法进行了涵盖三个数据集、三个模型、两种已确立的共形评分方法和多个覆盖率值的评估，以展示何时以及为什么测试时数据增强是共形流水线 (conformal pipeline) 的有用补充。
- Key contribution / 关键贡献:
  - EN:
    > This paper adresses the problem of producing large prediction sets commonly seen in current approaches of conformal prediction, by applying test-time augmentation to the computation of conformal scores.
  - ZH:
    > 本文通过将测试时数据增强应用于共形分数的计算，解决了在当前共形预测方法中常见的产生大预测集合的问题。
- Limitation / 局限:
  - EN:
    > Some of the technical claims might need further explanation (see Questions).
  - ZH:
    > 一些技术主张可能需要进一步的解释（见 Questions）。
- Important result / 重要结果:
  - EN:
    > We conduct an evaluation of the approach spanning three datasets, three models, two established conformal scoring methods, and multiple coverage values to show when and why test-time augmentation is a useful addition to the conformal pipeline.
  - ZH:
    > 我们对该方法进行了涵盖三个数据集、三个模型、两种已确立的共形评分方法和多个覆盖率值的评估，以展示何时以及为什么测试时数据增强是共形流水线的有用补充。

#### Paper 3

- Paper ID: `Vf5ZUalFk8`
- URL: https://openreview.net/forum?id=Vf5ZUalFk8
- Title / 标题:
  - EN:
    > Conformal Reasoning: Uncertainty Estimation in Interactive Environments
  - ZH:
    > 共形推理 (Conformal Reasoning)：交互式环境中的不确定性估计
- Abstract / 摘要:
  - EN:
    > We introduce conformal reasoning, a principled method for models in interactive environments to reason about their uncertainty and decide whether to seek out more information or to return a prediction. The challenge with standard conformal prediction---a popular statistical framework for uncertainty estimation that constructs prediction sets with formal coverage guarantees---is that it relies on a fixed set of calibration data points. In interactive environments, however, the calibration trajectories require certain termination criteria determined a priori, introducing heuristic bias and/or circular dependency that break the assumptions needed for coverage guarantees. We address this issue by building on adaptive conformal inference techniques. On two real-world tasks on medical diagnosis and embodied question answering, we show that conformal reasoning empirically achieves its theoretical coverage guarantees---in contrast with standard conformal prediction approaches that can significantly over- or under-cover---while improving exploration efficiency by approximately 20% on both tasks.
  - ZH:
    > 我们引入了共形推理 (conformal reasoning)，这是一种有原则的方法，用于交互式环境中的模型推理其不确定性，并决定是寻求更多信息还是返回预测。标准共形预测 (conformal prediction)——一种用于不确定性估计的流行统计框架，它构建具有正式覆盖保证的预测集——面临的挑战在于，它依赖于一组固定的校准数据点。然而，在交互式环境中，校准轨迹需要先验确定的特定终止标准，这引入了启发式偏差和/或循环依赖，打破了覆盖保证所需的假设。我们通过基于自适应共形推断 (adaptive conformal inference) 技术来解决这个问题。在医疗诊断和具身问答 (embodied question answering) 这两个真实世界的任务上，我们展示了共形推理在经验上实现了其理论覆盖保证——相比之下，标准共形预测方法可能会显著地过度覆盖或覆盖不足——同时在两项任务上将探索效率提高了约 20%。
- Key contribution / 关键贡献:
  - EN:
    > The paper introduces a method called conformal reasoning.
  - ZH:
    > 该论文介绍了一种称为共形推理 (conformal reasoning) 的方法。
- Limitation / 局限:
  - EN:
    > (1) There are fundamental and serious issues with the idea of terminating when |C| = 1, as proposed in Figure 1.
  - ZH:
    > (1) 如图 1 所提出，在 |C| = 1 时终止的想法存在根本且严重的问题。
- Important result / 重要结果:
  - EN:
    > On two real-world tasks on medical diagnosis and embodied question answering, we show that conformal reasoning empirically achieves its theoretical coverage guarantees---in contrast with standard conformal prediction approaches that can significantly over- or under-cover---while improving exploration efficiency by approximately 20% on both tasks.
  - ZH:
    > 在医疗诊断和具身问答这两个真实世界的任务上，我们展示了共形推理在经验上实现了其理论覆盖保证——相比之下，标准共形预测方法可能会显著地过度覆盖或覆盖不足——同时在两项任务上将探索效率提高了约 20%。

#### Paper 4

- Paper ID: `33XGfHLtZg`
- URL: https://openreview.net/forum?id=33XGfHLtZg
- Title / 标题:
  - EN:
    > Conformal Risk Control
  - ZH:
    > 共形风险控制 (Conformal Risk Control)
- Abstract / 摘要:
  - EN:
    > We extend conformal prediction to control the expected value of any monotone loss function. The algorithm generalizes split conformal prediction together with its coverage guarantee. Like conformal prediction, the conformal risk control procedure is tight up to an $\mathcal{O}(1/n)$ factor. We also introduce extensions of the idea to distribution shift, quantile risk control, multiple and adversarial risk control, and expectations of U-statistics. Worked examples from computer vision and natural language processing demonstrate the usage of our algorithm to bound the false negative rate, graph distance, and token-level F1-score.
  - ZH:
    > 我们将共形预测 (conformal prediction) 扩展以控制任何单调损失函数的期望值。该算法推广了分割共形预测 (split conformal prediction) 连同其覆盖保证 (coverage guarantee)。像共形预测一样，共形风险控制过程在一个 $\mathcal{O}(1/n)$ 因子内是紧致的 (tight)。我们还介绍了该思想向分布偏移 (distribution shift)、分位数风险控制 (quantile risk control)、多重和对抗性风险控制 (multiple and adversarial risk control) 以及 U-统计量 (U-statistics) 的期望的扩展。来自计算机视觉和自然语言处理的计算实例 (worked examples) 展示了我们算法在界定假阴性率 (false negative rate)、图距离 (graph distance) 和 token-level F1-score 方面的用法。
- Key contribution / 关键贡献:
  - EN:
    > The paper extends CP coverage guarantees to risk upper bounds.
  - ZH:
    > 该论文将 CP 覆盖保证扩展到了风险上限 (risk upper bounds)。
- Limitation / 局限:
  - EN:
    > The relevance and novelty of the theoretical parts may be stated better in the introduction.
  - ZH:
    > 理论部分的相关性和新颖性可以在引言中得到更好的陈述。
- Important result / 重要结果:
  - EN:
    > Worked examples from computer vision and natural language processing demonstrate the usage of our algorithm to bound the false negative rate, graph distance, and token-level F1-score.
  - ZH:
    > 来自计算机视觉和自然语言处理的计算实例展示了我们算法在界定假阴性率、图距离和 token-level F1-score 方面的用法。

## t1_formal_014

- Batch: `fourth40`
- Context ID: `smallari_fourth40_006_skill_discovery_long_horizon_diverse_skills__v02_fourth40`
- Area: `reinforcement learning and agents`
- Top terms: `skill, discovery, long-horizon, diverse, skills`
- Mean pairwise cosine: `0.0903`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fourth40 neighborhood around reinforcement learning and agents: skill, discovery, long-horizon, diverse, skills. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文在强化学习（reinforcement learning）和智能体（agents）周围形成了一个新的 fourth40 邻域：技能（skill）、发现（discovery）、长时程（long-horizon）、多样化（diverse）、技能（skills）。该背景基于论文标题、摘要以及审稿人的局限性信号。它测试一个模型能否从紧密的局部文献簇中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fourth40 neighborhood around reinforcement learning and agents: skill, discovery, long-horizon, diverse, skills, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕强化学习和智能体的 fourth40 邻域：技能、发现、长时程、多样化、技能，并针对在提供的审稿意见和摘要中可见的局限性或评估空白。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；对于最小验证 <=8 A100 GPU-days；无专有模型权重；无未来论文答案密钥（future-paper answer keys）；包含一个来自所提供论文的基线（baseline）以及一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪的下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `rF0wXBpFRT`
- URL: https://openreview.net/forum?id=rF0wXBpFRT
- Title / 标题:
  - EN:
    > Playbook: Scalable Discrete Skill Discovery from Unstructured Datasets for Long-Horizon Decision-Making Problems
  - ZH:
    > Playbook：用于长视野决策问题的从非结构化数据集中进行可扩展离散技能发现
- Abstract / 摘要:
  - EN:
    > Skill discovery methods equip an agent with diverse skills necessary for solving challenging tasks through an unsupervised learning manner. However, making the pre-learned skills expandable for new tasks remains a challenge in existing research. To handle this limitation, we propose a scalable skill discovery algorithm, a playbook, which can accommodate unseen tasks by training new skills while maintaining previously learned ones. The playbook, characterized by discrete skills and an extendable structure, enables the extension of the skill set to cover new datasets. Since we design the playbook to have a finite number of skills, we can interpret a decision-making problem as a sequential skill classification problem, so we aim to learn additional skills of the playbook by applying the techniques of class-incremental learning. In addition, we also introduce skill planning schemes that can leverage both previously and newly learned skills to solve challenging tasks compounded by multiple sub-tasks. The proposed method is evaluated in the complex robotic manipulation benchmarks, and the results show that the playbook outperforms existing state-of-the-art methods that learn continuous skills.
  - ZH:
    > 技能发现方法通过无监督学习 (unsupervised learning) 方式为智能体 (agent) 配备解决具有挑战性的任务所需的各种技能。然而，在现有研究中，使预先学习的技能能够针对新任务进行扩展仍然是一个挑战。为了处理这一局限性，我们提出了一种可扩展的技能发现算法，即一个 playbook，它可以通过训练新技能同时保持先前学习的技能来适应未见过的任务。该 playbook 以离散技能和可扩展结构为特征，使得能够扩展技能集以覆盖新的数据集。由于我们将 playbook 设计为具有有限数量的技能，我们可以将决策问题解释为一个序列技能分类问题，因此我们的目标是通过应用类增量学习 (class-incremental learning) 的技术来学习 playbook 的额外技能。此外，我们还引入了技能规划方案，可以利用先前和新学习的技能来解决由多个子任务复合而成的具有挑战性的任务。所提出的方法在复杂的机器人操作基准中进行了评估，结果表明 playbook 优于学习连续技能的现有最先进 (state-of-the-art) 方法。
- Key contribution / 关键贡献:
  - EN:
    > In this work, the authors present _Playbook_, which is an algorithm for discovering "skills" from offline, unlabeled behavior datasets.
  - ZH:
    > 在这项工作中，作者提出了 _Playbook_，这是一个从离线的、未标记的行为数据集中发现“技能”的算法。
- Limitation / 局限:
  - EN:
    > However, there are many points where the work can improve.
  - ZH:
    > 然而，这项工作有许多可以改进的地方。
- Important result / 重要结果:
  - EN:
    > The proposed method is evaluated in the complex robotic manipulation benchmarks, and the results show that the playbook outperforms existing state-of-the-art methods that learn continuous skills.
  - ZH:
    > 所提出的方法在复杂的机器人操作基准中进行了评估，结果表明 playbook 优于学习连续技能的现有最先进方法。

#### Paper 2

- Paper ID: `i3e92uSZCp`
- URL: https://openreview.net/forum?id=i3e92uSZCp
- Title / 标题:
  - EN:
    > Language Guided Skill Discovery
  - ZH:
    > 语言引导的技能发现
- Abstract / 摘要:
  - EN:
    > Skill discovery methods enable agents to learn diverse emergent behaviors without explicit rewards. To make learned skills useful for downstream tasks, obtaining a semantically diverse repertoire of skills is crucial. While some approaches use discriminators to acquire distinguishable skills and others focus on increasing state coverage, the direct pursuit of ‘semantic diversity’ in skills remains underexplored. We hypothesize that leveraging the semantic knowledge of large language models (LLM) can lead us to improve semantic diversity of resulting behaviors. In this sense, we introduce Language Guided Skill Discovery (LGSD), a skill discovery framework that aims to directly maximize the semantic diversity between skills. LGSD takes user prompts as input and outputs a set of semantically distinctive skills. The prompts serve as a means to constrain the search space into a semantically desired subspace, and the generated LLM outputs guide the agent to visit semantically diverse states within the subspace. We demonstrate that LGSD enables legged robots to visit different user-intended areas on a plane by simply changing the prompt. Furthermore, we show that language guidance aids in discovering more diverse skills compared to five existing skill discovery methods in robot-arm manipulation environments. Lastly, LGSD provides a simple way of utilizing learned skills via natural...
  - ZH:
    > 技能发现 (Skill discovery) 方法使智能体能够在没有显式奖励的情况下学习多样的涌现行为。为了使学到的技能对下游任务有用，获得语义上多样的技能库是至关重要的。虽然一些方法使用判别器来获取可区分的技能，而另一些方法侧重于增加状态覆盖率，但对技能中“语义多样性”的直接追求仍然探索不足。我们假设利用大型语言模型 (LLM) 的语义知识可以引导我们提高最终行为的语义多样性。从这个意义上说，我们引入了语言引导的技能发现 (Language Guided Skill Discovery, LGSD)，这是一个旨在直接最大化技能之间语义多样性的技能发现框架。LGSD 将用户提示 (prompts) 作为输入并输出一组语义上独特的技能。提示作为一种手段，将搜索空间约束到语义上期望的子空间中，而生成的 LLM 输出引导智能体访问该子空间内语义多样的状态。我们证明，LGSD 能够使腿足机器人只需简单地更改提示即可访问平面上不同的用户预期区域。此外，我们展示了在机械臂操作环境中，与现有的五种技能发现方法相比，语言引导有助于发现更多样的技能。最后，LGSD 提供了一种通过自然...利用所学技能的简单方法
- Key contribution / 关键贡献:
  - EN:
    > This paper proposed to incorporate semantic diversity in skill discovery.
  - ZH:
    > 本文提出在技能发现中引入语义多样性。
- Limitation / 局限:
  - EN:
    > More complex scenarios should be designed to make the use of LLMs necessary rather than simple positions.
  - ZH:
    > 应该设计更复杂的场景以使得使用 LLM 成为必要，而不是简单的位置。
- Important result / 重要结果:
  - EN:
    > We hypothesize that leveraging the semantic knowledge of large language models (LLM) can lead us to improve semantic diversity of resulting behaviors.
  - ZH:
    > 我们假设利用大型语言模型 (LLM) 的语义知识可以引导我们提高最终行为的语义多样性。

#### Paper 3

- Paper ID: `NY3HzOOL3u`
- URL: https://openreview.net/forum?id=NY3HzOOL3u
- Title / 标题:
  - EN:
    > Skill Reinforcement Learning and Planning for Open-World Long-Horizon Tasks
  - ZH:
    > 开放世界长视野任务的技能强化学习与规划
- Abstract / 摘要:
  - EN:
    > We study building an agent that solves diverse long-horizon tasks in open-world environments. Without human demonstrations, learning to accomplish tasks in a large open-world environment with reinforcement learning (RL) is extremely inefficient. To tackle this challenge, we convert the multi-task learning problem into learning basic skills and planning over the skills, and propose a Finding-skill to improve the sample efficiency for training all the skills. Using the popular open-world game Minecraft as the testbed, we propose three types of fine-grained basic skills, and use RL with intrinsic rewards to acquire skills with high success rates. For skill planning, we leverage the prior knowledge in Large Language Models to find the relationships between skills and build a skill graph. When the agent is solving a task, our skill search algorithm walks on the skill graph and generates the proper skill plans for the agent. In experiments, our method accomplishes 40 diverse Minecraft tasks, where many tasks require sequentially executing for more than 10 skills. Our method outperforms baselines by a large margin and is the most sample-efficient demonstration-free RL method to solve Minecraft Tech Tree tasks.
  - ZH:
    > 我们研究构建一个在开放世界环境中解决多种长视野任务（long-horizon tasks）的智能体（agent）。在没有人类演示的情况下，使用强化学习（RL）在大型开放世界环境中学习完成任务是极其低效的。为了应对这一挑战，我们将多任务学习问题转化为学习基本技能并在技能之上进行规划，并提出了一种寻找技能（Finding-skill）以提高训练所有技能的样本效率。使用流行的开放世界游戏 Minecraft 作为测试平台，我们提出了三种类型的细粒度（fine-grained）基本技能，并使用带有内在奖励的 RL 来获取高成功率的技能。对于技能规划，我们利用大型语言模型（Large Language Models）中的先验知识来寻找技能之间的关系并构建技能图（skill graph）。当智能体解决任务时，我们的技能搜索算法在技能图上游走，并为智能体生成合适的技能计划。在实验中，我们的方法完成了40个多样的 Minecraft 任务，其中许多任务需要顺序执行超过10个技能。我们的方法大幅超越了基线（baselines），并且是解决 Minecraft Tech Tree 任务最具样本效率的无演示 RL 方法。
- Key contribution / 关键贡献:
  - EN:
    > The authors use hierarchical policies to solve tasks in the Minecraft game.
  - ZH:
    > 作者使用分层策略（hierarchical policies）来解决 Minecraft 游戏中的任务。
- Limitation / 局限:
  - EN:
    > The method seems very cobbled together.
  - ZH:
    > 该方法似乎非常东拼西凑。
- Important result / 重要结果:
  - EN:
    > To tackle this challenge, we convert the multi-task learning problem into learning basic skills and planning over the skills, and propose a Finding-skill to improve the sample efficiency for training all the skills.
  - ZH:
    > 为了应对这一挑战，我们将多任务学习问题转化为学习基本技能并在技能之上进行规划，并提出了一种寻找技能（Finding-skill）以提高训练所有技能的样本效率。

#### Paper 4

- Paper ID: `nZBUtzJhf8`
- URL: https://openreview.net/forum?id=nZBUtzJhf8
- Title / 标题:
  - EN:
    > Guiding Skill Discovery with Foundation Models
  - ZH:
    > 使用基础模型指导技能发现
- Abstract / 摘要:
  - EN:
    > Learning diverse skills without hand-crafted reward functions could potentially accelerate reinforcement learning in downstream tasks. However, existing skill discovery methods focus solely on maximizing the diversity of skills without considering human preferences, which leads to undesirable behaviors and possibly dangerous skills. For instance, a cheetah robot trained using previous methods learns to roll in all directions to maximize skill diversity, whereas we would prefer it to run without flipping or entering hazardous areas. In this work, we propose a **Fo**undation model **G**uided (FoG) skill discovery method, which incorporates human intentions into skill discovery through foundation models. Specifically, FoG extracts a score function from foundation models to evaluate states based on human intentions, assigning higher values to desirable states and lower to undesirable ones. These scores are then used to re-weight the rewards of skill discovery algorithms. By optimizing the re-weighted skill discovery rewards, FoG successfully learns to eliminate undesirable behaviors, such as flipping or rolling, and to avoid hazardous areas in both state-based and pixel-based tasks. Interestingly, we show that FoG can discover skills involving behaviors that are difficult to define. Interactive visualisations are available from: https://sites.google.com/view/iclr-fog
  - ZH:
    > 在没有手工制作的奖励函数的情况下学习多样化的技能，有可能加速下游任务中的强化学习（reinforcement learning）。然而，现有的技能发现（skill discovery）方法仅专注于最大化技能的多样性，而不考虑人类的偏好，这导致了不受欢迎的行为和可能危险的技能。例如，使用以前的方法训练的猎豹机器人学会了向各个方向滚动以最大化技能多样性，而我们更希望它在不翻转或进入危险区域的情况下奔跑。在这项工作中，我们提出了一种**Fo**undation model **G**uided (FoG)（基础模型指导的）技能发现方法，该方法通过基础模型将人类意图纳入技能发现中。具体而言，FoG从基础模型中提取一个评分函数，以根据人类意图评估状态，为理想的状态分配较高的值，为不理想的状态分配较低的值。然后，这些分数被用于对技能发现算法的奖励进行重新加权。通过优化重新加权的技能发现奖励，FoG成功地学会了在基于状态和基于像素的任务中消除不受欢迎的行为（如翻转或滚动），并避免进入危险区域。有趣的是，我们展示了FoG可以发现涉及难以定义的行为的技能。交互式可视化可从以下网址获得：https://sites.google.com/view/iclr-fog
- Key contribution / 关键贡献:
  - EN:
    > The paper presents a foundation model-based approach for guiding unsupervised skill discovery to discover desirable skills and avoid undesirable skills.
  - ZH:
    > 本文提出了一种基于基础模型的方法，用于指导无监督技能发现，以发现理想的技能并避免不受欢迎的技能。
- Limitation / 局限:
  - EN:
    > In terms of the claimed novelties, one of them is that FoG can learn behaviors that are challenging to define.
  - ZH:
    > 就所声称的新颖性而言，其中之一是FoG能够学习难以定义的行为。
- Important result / 重要结果:
  - EN:
    > Interestingly, we show that FoG can discover skills involving behaviors that are difficult to define.
  - ZH:
    > 有趣的是，我们展示了FoG可以发现涉及难以定义的行为的技能。

## t1_formal_015

- Batch: `fourth40`
- Context ID: `smallari_fourth40_034_regression_symbolic_expressions_language_demonst__v02_fourth40`
- Area: `retrieval and long-context systems`
- Top terms: `regression, symbolic, expressions, language, demonstrate`
- Mean pairwise cosine: `0.0915`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fourth40 neighborhood around retrieval and long-context systems: regression, symbolic, expressions, language, demonstrate. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕检索和长上下文系统（retrieval and long-context systems）形成了一个全新的 fourth40 邻域：回归、符号、表达式、语言、演示。该上下文以论文标题、摘要和审稿人局限性信号（reviewer limitation signals）为基础。它测试模型能否从紧密的局部文献簇中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fourth40 neighborhood around retrieval and long-context systems: regression, symbolic, expressions, language, demonstrate, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕检索和长上下文系统的 fourth40 邻域：回归、符号、表达式、语言、演示，针对在提供的审稿意见和摘要中可见的局限性或评估空白（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；最小验证需要 <=8 A100 GPU天（GPU-days）；无专有模型权重；无未来论文答案密钥（future-paper answer keys）；包含一个来自所提供论文的基线（baseline）以及一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小可证伪的下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `NdHka08uWn`
- URL: https://openreview.net/forum?id=NdHka08uWn
- Title / 标题:
  - EN:
    > RAG-SR: Retrieval-Augmented Generation for Neural Symbolic Regression
  - ZH:
    > RAG-SR：用于神经符号回归 (Neural Symbolic Regression) 的检索增强生成 (Retrieval-Augmented Generation)
- Abstract / 摘要:
  - EN:
    > Symbolic regression is a key task in machine learning, aiming to discover mathematical expressions that best describe a dataset. While deep learning has increased interest in using neural networks for symbolic regression, many existing approaches rely on pre-trained models. These models require significant computational resources and struggle with regression tasks involving unseen functions and variables. A pre-training-free paradigm is needed to better integrate with search-based symbolic regression algorithms. To address these limitations, we propose a novel framework for symbolic regression that integrates evolutionary feature construction with a neural network, without the need for pre-training. Our approach adaptively generates symbolic trees that align with the desired semantics in real-time using a language model trained via online supervised learning, providing effective building blocks for feature construction. To mitigate hallucinations from the language model, we design a retrieval-augmented generation mechanism that explicitly leverages searched symbolic expressions. Additionally, we introduce a scale-invariant data augmentation technique that further improves the robustness and generalization of the model. Experimental results demonstrate that our framework achieves state-of-the-art accuracy across 25 regression algorithms and 120 regression tasks.
  - ZH:
    > 符号回归 (Symbolic regression) 是机器学习中的一项关键任务，旨在发现最能描述数据集的数学表达式。虽然深度学习增加了对使用神经网络进行符号回归的兴趣，但许多现有方法依赖于预训练模型 (pre-trained models)。这些模型需要显著的计算资源，并且在处理涉及未见函数和变量的回归任务时遇到困难。需要一种无预训练范式来更好地与基于搜索的符号回归算法相结合。为了解决这些局限性，我们提出了一种用于符号回归的新颖框架，该框架将进化特征构造 (evolutionary feature construction) 与神经网络集成，而无需预训练。我们的方法使用通过在线监督学习训练的语言模型，实时自适应地生成与期望语义对齐的符号树，为特征构造提供有效的构建块。为了减轻语言模型的幻觉 (hallucinations)，我们设计了一种检索增强生成机制，显式地利用搜索到的符号表达式。此外，我们引入了一种尺度不变的数据增强 (scale-invariant data augmentation) 技术，进一步提高了模型的鲁棒性和泛化性。实验结果证明，我们的框架在25种回归算法和120个回归任务中实现了最先进的 (state-of-the-art) 准确率。
- Key contribution / 关键贡献:
  - EN:
    > The paper proposes a novel approach to symbolic regression based on neural-network based Retrieval Augmented Generation (RAG) and semantic descent (SD).
  - ZH:
    > 该论文提出了一种基于基于神经网络的检索增强生成 (Retrieval Augmented Generation, RAG) 和语义下降 (semantic descent, SD) 的符号回归新方法。
- Limitation / 局限:
  - EN:
    > Clarity of presentation could be improved**: I believe that the way the approach is presented should be made clearer.
  - ZH:
    > 呈现的清晰度可以提高**：我认为呈现该方法的方式应该变得更加清晰。
- Important result / 重要结果:
  - EN:
    > Additionally, we introduce a scale-invariant data augmentation technique that further improves the robustness and generalization of the model.
  - ZH:
    > 此外，我们引入了一种尺度不变的数据增强技术，进一步提高了模型的鲁棒性和泛化性。

#### Paper 2

- Paper ID: `TqzNI4v9DT`
- URL: https://openreview.net/forum?id=TqzNI4v9DT
- Title / 标题:
  - EN:
    > GeoBench: A new benchmark on Symbolic Regression with Geometric Expressions
  - ZH:
    > GeoBench：关于具有几何表达式的符号回归（Symbolic Regression）的新基准
- Abstract / 摘要:
  - EN:
    > Symbolic regression (SR) is a powerful technique for deriving mathematical expressions from data. With the emergence of numerous SR methods, SRBench made a significant contribution by providing a standardized testing platform that includes 130 SR datasets and evaluates 14 SR methods. However, the methods included in SRBench are outdated, and the dataset does not feature results from more recent approaches such as TPSR. Additionally, the metrics used in SRBench do not adequately capture the full capabilities of symbolic regression methods, and the benchmark data has scientific problems. Although Matsubara et al. (2022) address some of these issues, their approach remains incomplete. In response, we propose a new benchmark consisting of 71 expressions derived from geometric contexts, categorized into three difficulty levels: easy, medium, and hard. We evaluate 20 SR methods on these expressions, focusing exclusively on the symbolic regression capability of each model, assessed through recovery rates across the different levels and overall. We provide a detailed methodology for reproducing the experiments and include results for newly developed SR methods within this updated benchmark. The results demonstrate significant variation in symbolic regression ability across models.
  - ZH:
    > 符号回归（Symbolic regression，SR）是一种从数据中推导数学表达式的强大技术。随着大量SR方法的出现，SRBench通过提供一个包含130个SR数据集并评估14种SR方法的标准化测试平台，做出了重大贡献。然而，SRBench中包含的方法已经过时，并且该数据集未包含来自诸如TPSR等更近期方法的结果。此外，SRBench中使用的指标未能充分捕捉符号回归方法的全部能力，并且该基准数据存在科学问题。尽管Matsubara等人（2022）解决了其中的一些问题，但他们的方法仍然不完整。作为回应，我们提出了一个新的基准，包含71个源自几何背景的表达式，分为三个难度级别：简单、中等和困难。我们在这些表达式上评估了20种SR方法，专门关注每个模型的符号回归能力，通过跨不同级别和整体的恢复率（recovery rates）进行评估。我们提供了重现实验的详细方法，并在此更新的基准中包含了新开发的SR方法的结果。结果表明模型之间的符号回归能力存在显著差异。
- Key contribution / 关键贡献:
  - EN:
    > This paper contributes a benchmark of symbolic regression methods using synthetic problems derived from 2D and 3d geometry.
  - ZH:
    > 本文贡献了一个符号回归方法的基准，该基准使用源自2D和3d几何的合成问题。
- Limitation / 局限:
  - EN:
    > While the paper has many strengths, one of the main weaknesses is that it does not make it clear to the reader why this set of synthetic benchmark problems is a good assessment of the efficacy of these methods in any real-world applications.
  - ZH:
    > 虽然本文有许多优点，但主要弱点之一是它没有向读者阐明为什么这套合成基准问题是在任何现实世界应用中评估这些方法效能的良好标准。
- Important result / 重要结果:
  - EN:
    > The results demonstrate significant variation in symbolic regression ability across models.
  - ZH:
    > 结果表明模型之间的符号回归能力存在显著差异。

#### Paper 3

- Paper ID: `FwjEZZ3j91`
- URL: https://openreview.net/forum?id=FwjEZZ3j91
- Title / 标题:
  - EN:
    > Parsing the Language of Expressions: Enhancing Symbolic Regression with Domain-Aware Symbolic Priors
  - ZH:
    > 解析表达式的语言：利用领域感知的符号先验增强符号回归
- Abstract / 摘要:
  - EN:
    > Symbolic regression is pivotal for discovering interpretable expressions that unravel complex phenomena by revealing underlying mathematical and physical relationships within data. In this paper, we introduce an enhanced symbolic regression method that integrates symbol priors derived from diverse scientific domains—including physics, biology, chemistry, and engineering—into the regression process. By organizing and analyzing domain-specific expressions, we examine the probability distributions of symbols across different topics. We introduce a novel tree-structured recurrent neural networks (RNNs) infused with these symbol priors to guide the learning process using domain knowledge. In our approach, we introduce a new tree structure to represent expressions, where unary operators connected by the same binary operator are positioned at the same hierarchical level. By analyzing the combinations of symbols at different heights and levels within the tree, we are able to examine symbol priors across the entire hierarchical structure. This effectively incorporates the structural information of expressions into the regression process. Additionally, we compile characteristic expression blocks from each domain and incorporate them into the operator dictionary during training, expediting learning by providing relevant building blocks. Experimental results demonstrate that incorporati...
  - ZH:
    > 符号回归（symbolic regression）对于发现可解释的表达式至关重要，这些表达式通过揭示数据中潜在的数学和物理关系来解开复杂现象。在本文中，我们引入了一种增强的符号回归方法，该方法将源自不同科学领域（包括物理学、生物学、化学和工程学）的符号先验（symbol priors）融入回归过程中。通过组织和分析特定领域的表达式，我们检查了符号在不同主题上的概率分布。我们引入了一种新颖的树结构循环神经网络（recurrent neural networks, RNNs），其中注入了这些符号先验，以利用领域知识指导学习过程。在我们的方法中，我们引入了一种新的树结构来表示表达式，其中由相同二元运算符连接的一元运算符位于相同的层级。通过分析树中不同高度和层级的符号组合，我们能够检查跨越整个层次结构的符号先验。这有效地将表达式的结构信息整合到了回归过程中。此外，我们从各个领域汇编了特征表达式块，并在训练期间将它们整合到运算符字典中，通过提供相关的构建块来加速学习。实验结果表明，incorporati...
- Key contribution / 关键贡献:
  - EN:
    > This paper studies the problem of *symbolic regression*, uncovering interpretable symbolic expressions that elucidate massive amounts of data.
  - ZH:
    > 本文研究了*符号回归*（symbolic regression）问题，揭示了能够阐明海量数据的可解释符号表达式。
- Limitation / 局限:
  - EN:
    > I had a hard time reading the paper, and believe that the writing and organization could be made a lot clearer.
  - ZH:
    > 我在阅读这篇论文时感到很困难，并且认为其写作和组织可以变得更加清晰。
- Important result / 重要结果:
  - EN:
    > Experimental results demonstrate that incorporating symbol priors significantly boosts the performance of symbolic regression methods.
  - ZH:
    > 实验结果表明，结合符号先验显著提升了符号回归方法的性能。

#### Paper 4

- Paper ID: `zsVZCiYG2r`
- URL: https://openreview.net/forum?id=zsVZCiYG2r
- Title / 标题:
  - EN:
    > ChatSR: Conversational Symbolic Regression
  - ZH:
    > ChatSR：对话式符号回归
- Abstract / 摘要:
  - EN:
    > Formulas are the language of communication between humans and nature. It is an important research topic of artificial intelligence to find expressions from observed data to reflect the relationship between each variable in the data, which is called a symbolic regression problem. The existing symbolic regression methods directly generate expressions according to the given observation data, but we cannot require the algorithm to generate expressions that meet specific requirements according to the known prior knowledge. For example, the expression needs to contain the symbol `$\sin$' or be periodicity, and so on. Even if it can, it often requires very complex operations, which is very inconvenient. In this paper, based on multi-modal large language models, we propose ChatSR, a conversational symbolic regression method that can generate expressions that meet the requirements simply by describing the requirements with natural language instructions. By experimenting on the test datasets, we can demonstrate that ChatSR leads the state-of-the-art baselines in fitting performance. More notably, ChatSR can well understand the prior knowledge contained in natural language prompts, and can further improve the quality of generated expressions according to the prior knowledge. In addition, it is exciting that ChatSR has good zero-shot capability.
  - ZH:
    > 公式是人类与自然之间交流的语言。从观测数据中寻找表达式以反映数据中每个变量之间的关系，是人工智能的一个重要研究课题，这被称为符号回归（symbolic regression）问题。现有的符号回归方法直接根据给定的观测数据生成表达式，但我们无法要求算法根据已知的先验知识生成满足特定要求的表达式。例如，表达式需要包含符号 `$\sin$' 或具有周期性，等等。即使可以，它通常也需要非常复杂的操作，这非常不方便。在本文中，基于多模态大语言模型（multi-modal large language models），我们提出了ChatSR，这是一种对话式符号回归方法，只需用自然语言指令描述需求，即可生成满足要求的表达式。通过在测试数据集上进行实验，我们可以证明ChatSR在拟合性能上领先于最先进的基线方法（state-of-the-art baselines）。更值得注意的是，ChatSR能够很好地理解自然语言提示中包含的先验知识，并且能够根据先验知识进一步提高生成表达式的质量。此外，令人兴奋的是，ChatSR具有良好的零样本（zero-shot）能力。
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces a symbolic regression method based on multimodal LLMs.
  - ZH:
    > 本文介绍了一种基于多模态大语言模型（multimodal LLMs）的符号回归方法。
- Limitation / 局限:
  - EN:
    > The types of symbols considered are relatively limited (Line 212).
  - ZH:
    > 考虑的符号类型相对有限 (Line 212)。
- Important result / 重要结果:
  - EN:
    > It is an important research topic of artificial intelligence to find expressions from observed data to reflect the relationship between each variable in the data, which is called a symbolic regression problem.
  - ZH:
    > 从观测数据中寻找表达式以反映数据中每个变量之间的关系，是人工智能的一个重要研究课题，这被称为符号回归问题。

## t1_formal_016

- Batch: `fourth40`
- Context ID: `smallari_fourth40_036_against_attacks_adversarial_black_box_robustness__v02_fourth40`
- Area: `diffusion and generative modeling`
- Top terms: `against, attacks, adversarial, black-box, robustness`
- Mean pairwise cosine: `0.1433`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fourth40 neighborhood around diffusion and generative modeling: against, attacks, adversarial, black-box, robustness. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕扩散和生成建模（diffusion and generative modeling）形成了一个全新的 fourth40 邻域（neighborhood）：对抗（against）、攻击（attacks）、对抗性（adversarial）、黑盒（black-box）、鲁棒性（robustness）。该背景基于论文标题、摘要和审稿人的局限性信号。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fourth40 neighborhood around diffusion and generative modeling: against, attacks, adversarial, black-box, robustness, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕扩散和生成建模的 fourth40 邻域：对抗、攻击、对抗性、黑盒、鲁棒性，针对在提供的审稿意见和摘要中可见的局限性或评估差距（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；用于最小化验证的时间 <=8 A100 GPU-days；无专有模型权重；无未来论文答案密钥（future-paper answer keys）；包括一个来自所提供论文的基线（baseline），以及一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪的（falsifiable）下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `mJzOHRSpSa`
- URL: https://openreview.net/forum?id=mJzOHRSpSa
- Title / 标题:
  - EN:
    > Random Logit Scaling: Defending Deep Neural Networks Against Black-Box Score-Based Adversarial Example Attacks
  - ZH:
    > 随机 Logit 缩放（Random Logit Scaling）：防御深度神经网络免受黑盒基于分数的对抗样本攻击
- Abstract / 摘要:
  - EN:
    > Machine learning models are increasingly adapted in various domains, such as autonomous driving, facial recognition, and malware detection, achieving state-of-the-art results. However, adversarial example attacks pose a significant threat to the reliable deployment of machine learning models in such applications. In recent years, some powerful adversarial example attacks have been proposed for the fast and query-efficient generation of adversarial examples, even in black-box scenarios where attackers only have an oracle access to the target model, highlighting the need for scalable, low-cost, and powerful defenses. In this work, we present two contributions to the domain of black-box attacks and defenses. First, we propose Random Logit Scaling (RLS), a randomization-based defense against black-box score-based adversarial example attacks. RLS is a plug-and-play, post-processing defense that can be implemented on top of any existing ML model with minimal effort. The idea behind RLS is to confuse an attacker by outputting falsified scores resulting from randomly scaled logits while maintaining the model accuracy. We show that RLS significantly reduces the success rate of state-of-the-art black-box score-based attacks while preserving the accuracy and minimizing confidence score distortion compared to state-of-the-art randomization-based defenses. Second, we introduce a novel ad...
  - ZH:
    > 机器学习模型越来越多地被应用于各个领域，如自动驾驶、面部识别和恶意软件检测，取得了最先进的（state-of-the-art）结果。然而，对抗样本攻击对机器学习模型在这些应用中的可靠部署构成了重大威胁。近年来，人们提出了一些强大的对抗样本攻击，用于快速且查询高效地生成对抗样本，即使在攻击者仅对目标模型拥有预言机访问权限（oracle access）的黑盒场景中也是如此，突显了对可扩展、低成本和强大防御的需求。在这项工作中，我们对黑盒攻击和防御领域做出了两项贡献。首先，我们提出了随机 Logit 缩放（Random Logit Scaling, RLS），这是一种基于随机化的防御机制，旨在对抗黑盒基于分数的对抗样本攻击。RLS 是一种即插即用的后处理防御，可以以最少的努力在任何现有的 ML 模型上实现。RLS 背后的思想是通过输出由随机缩放的 logits 产生的伪造分数来迷惑攻击者，同时保持模型准确性。我们表明，与最先进的基于随机化的防御相比，RLS 显著降低了最先进的黑盒基于分数的攻击的成功率，同时保留了准确性并最大限度地减少了置信度分数失真。其次，我们引入了一种新颖的ad...
- Key contribution / 关键贡献:
  - EN:
    > Existing works show that randomizing the prediction mitigates the threat of query-based attacks.
  - ZH:
    > 现有工作表明，随机化预测可以缓解基于查询的攻击的威胁。
- Limitation / 局限:
  - EN:
    > Since RLS does not change the prediction, it will not be effective against decision-based attacks.
  - ZH:
    > 由于 RLS 不改变预测，因此它对基于决策的攻击无效。
- Important result / 重要结果:
  - EN:
    > We show that RLS significantly reduces the success rate of state-of-the-art black-box score-based attacks while preserving the accuracy and minimizing confidence score distortion compared to state-of-the-art randomization-based defenses.
  - ZH:
    > 我们表明，与最先进的基于随机化的防御相比，RLS 显著降低了最先进的黑盒基于分数的攻击的成功率，同时保留了准确性并最大限度地减少了置信度分数失真。

#### Paper 2

- Paper ID: `DpnY7VOktT`
- URL: https://openreview.net/forum?id=DpnY7VOktT
- Title / 标题:
  - EN:
    > Can Model Randomization Offer Robustness Against Query-Based Black-Box Attacks?
  - ZH:
    > 模型随机化能否提供针对基于查询的黑盒攻击的鲁棒性？
- Abstract / 摘要:
  - EN:
    > Deep neural networks are misguided by simple-to-craft, imperceptible adversarial perturbations to inputs. Now, it is possible to craft such perturbations solely using model outputs and black-box attack algorithms. These algorithms compute adversarial examples by iteratively querying a model and inspecting responses. Attacks success in near information vacuums pose a significant challenge for developing mitigations. We investigate a new idea for a defense driven by a fundamental insight—to compute an adversarial example, attacks depend on the relationship between successive responses to queries to optimize a perturbation. Therefore, to obfuscate this relationship, we investigate randomly sampling a model from a set to generate a response to a query. Effectively, this model randomization violates the attacker's expectation of the unknown parameters of a model to remain static between queries to extract information to guide the search toward an adversarial example. It is not immediately clear if model randomization can lead to sufficient obfuscation to confuse query-based black-box attacks or how such a method could be built. Our theoretical analysis proves model randomization always increases resilience to query-based black-box attacks. We demonstrate with extensive empirical studies using 6 state-of-the-art attacks under all three perturbation objectives ($l_\infty, l_2, l_0$...
  - ZH:
    > 深度神经网络被易于构建的、难以察觉的输入对抗扰动（adversarial perturbations）所误导。现在，仅使用模型输出和黑盒攻击算法就可以构建此类扰动。这些算法通过迭代查询模型并检查响应来计算对抗样本（adversarial examples）。在近乎信息真空中的攻击成功，为开发缓解措施带来了重大挑战。我们研究了一种基于基本见解驱动的防御新思路——为了计算对抗样本，攻击依赖于对查询的连续响应之间的关系来优化扰动。因此，为了混淆这种关系，我们研究从集合中随机采样一个模型来生成对查询的响应。实际上，这种模型随机化违背了攻击者的期望，即模型的未知参数在查询之间保持静态以提取信息来引导寻找对抗样本的搜索。目前尚不清楚模型随机化是否能导致足够的混淆以迷惑基于查询的黑盒攻击，或者如何构建这样的方法。我们的理论分析证明，模型随机化总是能增加对基于查询的黑盒攻击的弹性。我们通过广泛的实证研究进行证明，在所有三种扰动目标（$l_\infty, l_2, l_0$...
- Key contribution / 关键贡献:
  - EN:
    > The paper proposes a defense mechanism against query-based black-box attacks relying on model randomization.
  - ZH:
    > 本文提出了一种依赖模型随机化的针对基于查询的黑盒攻击的防御机制。
- Limitation / 局限:
  - EN:
    > Compared to other randomization-based strategy, training and storing a diverse set of models can be computationally demanding, especially for large models and training datasets.
  - ZH:
    > 与其他基于随机化的策略相比，训练和存储多样的模型集合在计算上可能要求很高，尤其是对于大型模型和训练数据集。
- Important result / 重要结果:
  - EN:
    > We demonstrate with extensive empirical studies using 6 state-of-the-art attacks under all three perturbation objectives ($l_\infty, l_2, l_0$) and adaptive attacks, our proposed method injects sufficient uncertainty through obfuscation to yield a highly effective defense.
  - ZH:
    > 我们通过广泛的实证研究证明，在所有三种扰动目标（$l_\infty, l_2, l_0$）下使用6种最先进的攻击和自适应攻击，我们提出的方法通过混淆注入了足够的不确定性，从而产生了一种高度有效的防御。

#### Paper 3

- Paper ID: `vZ6r9GMT1n`
- URL: https://openreview.net/forum?id=vZ6r9GMT1n
- Title / 标题:
  - EN:
    > Understanding the Robustness of Randomized Feature Defense Against Query-Based Adversarial Attacks
  - ZH:
    > 理解随机特征防御（Randomized Feature Defense）抵御基于查询的对抗攻击（Query-Based Adversarial Attacks）的鲁棒性
- Abstract / 摘要:
  - EN:
    > Recent works have shown that deep neural networks are vulnerable to adversarial examples that find samples close to the original image but can make the model misclassify. Even with access only to the model's output, an attacker can employ black-box attacks to generate such adversarial examples. In this work, we propose a simple and lightweight defense against black-box attacks by adding random noise to hidden features at intermediate layers of the model at inference time. Our theoretical analysis confirms that this method effectively enhances the model's resilience against both score-based and decision-based black-box attacks. Importantly, our defense does not necessitate adversarial training and has minimal impact on accuracy, rendering it applicable to any pre-trained model. Our analysis also reveals the significance of selectively adding noise to different parts of the model based on the gradient of the adversarial objective function, which can be varied during the attack. We demonstrate the robustness of our defense against multiple black-box attacks through extensive empirical experiments involving diverse models with various architectures.
  - ZH:
    > 最近的研究表明，深度神经网络（deep neural networks）容易受到对抗样本（adversarial examples）的攻击，这些对抗样本寻找接近原始图像但能使模型误分类的样本。即使只能访问模型的输出，攻击者也可以采用黑盒攻击（black-box attacks）来生成这样的对抗样本。在这项工作中，我们提出了一种简单且轻量级的防御黑盒攻击的方法，即在推理时向模型中间层的隐藏特征（hidden features）添加随机噪声。我们的理论分析证实，该方法有效地增强了模型抵御基于分数（score-based）和基于决策（decision-based）的黑盒攻击的弹性。重要的是，我们的防御不需要对抗训练（adversarial training），并且对准确率的影响极小，使其适用于任何预训练模型。我们的分析还揭示了根据对抗目标函数（adversarial objective function）的梯度选择性地向模型不同部分添加噪声的重要性，该梯度在攻击期间可能会变化。我们通过涉及具有各种架构的多种模型的广泛实证实验，证明了我们的防御抵御多种黑盒攻击的鲁棒性。
- Key contribution / 关键贡献:
  - EN:
    > This paper showed that adding noises to some parts of models could protect the models from query-based attacks.
  - ZH:
    > 本文表明，向模型的某些部分添加噪声可以保护模型免受基于查询的攻击（query-based attacks）。
- Limitation / 局限:
  - EN:
    > I understand that the paper focuses on black-box attacks, but in the experiment section, the authors may try evaluating models with white-box attacks as well.
  - ZH:
    > 我理解这篇论文侧重于黑盒攻击，但在实验部分，作者也许可以尝试用白盒攻击（white-box attacks）来评估模型。
- Important result / 重要结果:
  - EN:
    > Recent works have shown that deep neural networks are vulnerable to adversarial examples that find samples close to the original image but can make the model misclassify.
  - ZH:
    > 最近的研究表明，深度神经网络容易受到对抗样本的攻击，这些对抗样本寻找接近原始图像但能使模型误分类的样本。

#### Paper 4

- Paper ID: `ge5PasXuJ6`
- URL: https://openreview.net/forum?id=ge5PasXuJ6
- Title / 标题:
  - EN:
    > Error Correcting by Agreement Checking for Adversarial Robustness against Black-box Attacks
  - ZH:
    > 通过一致性检查进行纠错以增强针对黑盒攻击的对抗鲁棒性
- Abstract / 摘要:
  - EN:
    > Drawing inspiration from the vulnerability of the initial feed-forward phase of biological perception in humans and primates to adversarial attacks, we propose a novel defense strategy named Error Correcting by Agreement Checking (ECAC). This strategy is designed to mitigate realistic \emph{black-box} threats where attackers don't have full access to the model. We exploit the fact that natural and adversarially trained models rely on distinct feature sets for classification. Notably, naturally trained models retain commendable accuracy against adversarial examples generated using adversarially trained models. Leveraging this disparity, ECAC moves the input toward the prediction of the naturally trained model unless it leads to disagreement in prediction between the two models, before making the prediction. This simple error correction mechanism is highly effective against leading SQA (Score-based Query Attacks) black-box attacks as well as decision-based and transfer-based black-box attacks. We also verify that, unlike other black-box defense, ECAC maintains significant robustness even when adversary has full access to the model. We demonstrate its effectiveness through comprehensive experiments across various datasets (CIFAR and ImageNet) and architectures (ResNet as well as ViT).
  - ZH:
    > 从人类和灵长类动物生物感知的初始前馈（feed-forward）阶段对对抗攻击的脆弱性中汲取灵感，我们提出了一种名为通过一致性检查进行纠错（Error Correcting by Agreement Checking, ECAC）的新型防御策略。该策略旨在缓解现实中的\emph{黑盒}（black-box）威胁，在这种威胁中，攻击者无法完全访问模型。我们利用了自然训练和对抗训练模型（adversarially trained models）在分类时依赖不同特征集这一事实。值得注意的是，自然训练的模型对使用对抗训练模型生成的对抗样本保留了令人称赞的准确率。利用这种差异，在做出预测之前，ECAC将输入向自然训练模型的预测方向移动，除非这会导致两个模型在预测上产生分歧。这种简单的纠错机制对领先的SQA（基于分数的查询攻击，Score-based Query Attacks）黑盒攻击，以及基于决策（decision-based）和基于迁移（transfer-based）的黑盒攻击非常有效。我们还验证了，与其他黑盒防御不同，即使对手完全访问模型，ECAC也能保持显著的鲁棒性。我们通过跨各种数据集（CIFAR和ImageNet）以及架构（ResNet以及ViT）的综合实验证明了其有效性。
- Key contribution / 关键贡献:
  - EN:
    > The paper introduces Error Correcting by Agreement Checking (ECAC), a novel defense method aimed at countering black-box adversarial attacks on machine learning models, inspired by the vulnerability of the initial feed-forward phase in biological perception.
  - ZH:
    > 本文引入了通过一致性检查进行纠错（ECAC），这是一种旨在对抗机器学习模型上的黑盒对抗攻击的新型防御方法，其灵感来自于生物感知中初始前馈阶段的脆弱性。
- Limitation / 局限:
  - EN:
    > While authors have expended adequate efforts towards designing an adaptive attacks against their defense, the execution of the attacks is lacking.
  - ZH:
    > 虽然作者在设计针对其防御的自适应攻击（adaptive attacks）方面投入了充分的努力，但攻击的执行却有所欠缺。
- Important result / 重要结果:
  - EN:
    > We demonstrate its effectiveness through comprehensive experiments across various datasets (CIFAR and ImageNet) and architectures (ResNet as well as ViT).
  - ZH:
    > 我们通过跨各种数据集（CIFAR和ImageNet）以及架构（ResNet以及ViT）的综合实验证明了其有效性。

## t1_formal_017

- Batch: `fifth40`
- Context ID: `smallari_fifth40_014_graph_fairness_fairness_aware_networks_group__v02_fifth40`
- Area: `alignment, safety, fairness, and privacy`
- Top terms: `graph, fairness, fairness-aware, networks, group`
- Mean pairwise cosine: `0.0926`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fifth40 neighborhood around alignment, safety, fairness, and privacy: graph, fairness, fairness-aware, networks, group. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文构成了一个围绕对齐（alignment）、安全（safety）、公平（fairness）和隐私（privacy）的新的 fifth40 邻域（neighborhood）：图（graph）、公平（fairness）、公平感知（fairness-aware）、网络（networks）、组（group）。该背景（context）基于论文标题、摘要和审稿人的局限性信号（limitation signals）。它测试模型是否能从一个紧密的局部文献集群（literature cluster）中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fifth40 neighborhood around alignment, safety, fairness, and privacy: graph, fairness, fairness-aware, networks, group, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合（synthesizes）这个围绕对齐、安全、公平和隐私的 fifth40 邻域：图、公平、公平感知、网络、组，针对在提供的审稿和摘要中可见的局限性或评估差距（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重（open-weight）模型；最小验证（minimal validation）需 <=8 A100 GPU-days；没有专有模型权重；没有未来论文的答案密钥（answer keys）；包含一个来自所提供论文的基线（baseline）和一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪（falsifiable）的下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `q3KNrmW6Ql`
- URL: https://openreview.net/forum?id=q3KNrmW6Ql
- Title / 标题:
  - EN:
    > Adversarial Attacks on Fairness of Graph Neural Networks
  - ZH:
    > 对图神经网络公平性的对抗攻击
- Abstract / 摘要:
  - EN:
    > Fairness-aware graph neural networks (GNNs) have gained a surge of attention as they can reduce the bias of predictions on any demographic group (e.g., female) in graph-based applications. Although these methods greatly improve the algorithmic fairness of GNNs, the fairness can be easily corrupted by carefully designed adversarial attacks. In this paper, we investigate the problem of adversarial attacks on fairness of GNNs and propose G-FairAttack, a general framework for attacking various types of fairness-aware GNNs in terms of fairness with an unnoticeable effect on prediction utility. In addition, we propose a fast computation technique to reduce the time complexity of G-FairAttack. The experimental study demonstrates that G-FairAttack successfully corrupts the fairness of different types of GNNs while keeping the attack unnoticeable. Our study on fairness attacks sheds light on potential vulnerabilities in fairness-aware GNNs and guides further research on the robustness of GNNs in terms of fairness.
  - ZH:
    > 感知公平性的图神经网络（GNNs）引起了激增的关注，因为它们可以减少基于图的应用中对任何人口群体（例如女性）的预测偏差。尽管这些方法极大地改善了GNNs的算法公平性，但这种公平性很容易被精心设计的对抗攻击所破坏。在本文中，我们研究了对GNNs公平性的对抗攻击问题，并提出了G-FairAttack，这是一个通用框架，用于在公平性方面攻击各类感知公平性的GNNs，同时对预测效用产生不可察觉的影响。此外，我们提出了一种快速计算技术以降低G-FairAttack的时间复杂度。实验研究表明，G-FairAttack成功地破坏了不同类型GNNs的公平性，同时保持攻击不被察觉。我们对公平性攻击的研究揭示了感知公平性的GNNs中潜在的脆弱性，并指导了在公平性方面对GNNs鲁棒性的进一步研究。
- Key contribution / 关键贡献:
  - EN:
    > The paper studies the problem of adversarial attacks on fairness of GNNs.
  - ZH:
    > 本文研究了对GNNs公平性的对抗攻击问题。
- Limitation / 局限:
  - EN:
    > Grey-box attack scenarios are relatively uncommon in real-world applications.
  - ZH:
    > 灰盒攻击场景在现实世界应用中相对罕见。
- Important result / 重要结果:
  - EN:
    > Although these methods greatly improve the algorithmic fairness of GNNs, the fairness can be easily corrupted by carefully designed adversarial attacks.
  - ZH:
    > 尽管这些方法极大地改善了GNNs的算法公平性，但这种公平性很容易被精心设计的对抗攻击所破坏。

#### Paper 2

- Paper ID: `M4RhGr2lAy`
- URL: https://openreview.net/forum?id=M4RhGr2lAy
- Title / 标题:
  - EN:
    > Fairness-Aware Graph Learning: A Benchmark
  - ZH:
    > 公平性感知图学习 (Fairness-Aware Graph Learning)：一个基准
- Abstract / 摘要:
  - EN:
    > Fairness-aware graph learning has gained increasing attention in recent years. Nevertheless, there lacks a comprehensive benchmark to evaluate and compare different fairness-aware graph learning methods, which blocks practitioners from choosing appropriate ones for broader real-world applications. In this paper, we present an extensive benchmark on ten representative fairness-aware graph learning methods. Specifically, we design a systematic evaluation protocol and conduct experiments on seven real-world datasets to evaluate these methods from multiple perspectives, including group fairness, individual fairness, the balance between different fairness criteria, and computational efficiency. Our in-depth analysis reveals key insights into the strengths and limitations of existing methods. Additionally, we provide practical guidance for applying fairness-aware graph learning methods in applications. To the best of our knowledge, this work serves as an initial step towards comprehensively understanding representative fairness-aware graph learning methods to facilitate future advancements in this area.
  - ZH:
    > 近年来，公平性感知图学习 (fairness-aware graph learning) 受到了越来越多的关注。然而，缺乏一个全面的基准来评估和比较不同的公平性感知图学习方法，这阻碍了从业者为更广泛的现实世界应用选择合适的方法。在本文中，我们提出了一个针对十种具有代表性的公平性感知图学习方法的广泛基准。具体而言，我们设计了一个系统的评估协议，并在七个真实世界数据集上进行了实验，从多个角度评估这些方法，包括群体公平性 (group fairness)、个体公平性 (individual fairness)、不同公平性标准之间的平衡以及计算效率。我们的深入分析揭示了对现有方法的优势和局限性的关键见解。此外，我们为在应用中应用公平性感知图学习方法提供了实践指导。据我们所知，这项工作是迈向全面理解具有代表性的公平性感知图学习方法的初始步骤，以促进该领域的未来发展。
- Key contribution / 关键贡献:
  - EN:
    > This paper provided a comprehensive protocol to evaluate the performance of fairness-aware graph learning methods.
  - ZH:
    > 本文提供了一个全面的协议来评估公平性感知图学习方法的性能。
- Limitation / 局限:
  - EN:
    > The discussion mostly focused on stating the observations that different methods have different performances on different metrics.
  - ZH:
    > 讨论主要集中在陈述观察结果，即不同的方法在不同的指标上有不同的性能。
- Important result / 重要结果:
  - EN:
    > This paper provided a comprehensive benchmark over ten very recent fairness-aware graph learning methods, including both group fairness and individual fairness.
  - ZH:
    > 本文提供了一个涵盖十种非常近期的公平性感知图学习方法的全面基准，包括群体公平性和个体公平性。

#### Paper 3

- Paper ID: `yYjsH5wktr`
- URL: https://openreview.net/forum?id=yYjsH5wktr
- Title / 标题:
  - EN:
    > Fairness-aware Message Passing for Graph Neural Networks
  - ZH:
    > 图神经网络的公平性感知消息传递
- Abstract / 摘要:
  - EN:
    > Graph Neural Networks (GNNs) have shown great power in various domains. However, their predictions may inherit societal biases on sensitive attributes, limiting their adoption in real-world applications. Although many efforts have been taken for fair GNNs, most existing works just adopt widely used fairness techniques in machine learning to graph domains and ignore or don't have a thorough understanding of the message passing mechanism with fairness constraints, which is a distinctive feature of GNNs. To fill the gap, we propose a novel fairness-aware message passing framework GMMD, which is derived from an optimization problem that considers both graph smoothness and representation fairness. GMMD can be intuitively interpreted as encouraging a node to aggregate representations of other nodes from different sensitive groups while subtracting representations of other nodes from the same sensitive group, resulting in fair representations. We also provide a theoretical analysis to justify that GMMD can guarantee fairness, which leads to a simpler and theory-guided variant GMMD-S. Extensive experiments on graph benchmarks show that our proposed framework can significantly improve the fairness of various backbone GNN models while maintaining high accuracy.
  - ZH:
    > 图神经网络（GNNs）在各个领域展现出了巨大的力量。然而，它们的预测可能会继承关于敏感属性的社会偏见，限制了它们在现实世界应用中的采用。尽管为了公平的GNNs已经付出了许多努力，大多数现有工作只是将机器学习中广泛使用的公平性技术应用于图领域，并且忽略或没有透彻理解带有公平性约束的消息传递机制，这是GNNs的一个显著特征。为了填补这一空白，我们提出了一种新颖的公平性感知消息传递框架GMMD，它衍生自一个同时考虑图平滑度（graph smoothness）和表示公平性（representation fairness）的优化问题。GMMD可以被直观地解释为鼓励一个节点聚合来自不同敏感组的其他节点的表示，同时减去来自相同敏感组的其他节点的表示，从而产生公平的表示。我们还提供了一个理论分析来证明GMMD可以保证公平性，这引出了一个更简单且受理论指导的变体GMMD-S。在图基准测试上的广泛实验表明，我们提出的框架可以显著提高各种骨干GNN模型的公平性，同时保持高准确性。
- Key contribution / 关键贡献:
  - EN:
    > The paper considers the goals of achieving both graph smoothness and fairness in message-passing at the same time.
  - ZH:
    > 该论文考虑了在消息传递中同时实现图平滑度和公平性的目标。
- Limitation / 局限:
  - EN:
    > The paper is not easy to follow from time to time.
  - ZH:
    > 该论文有时不容易读懂。
- Important result / 重要结果:
  - EN:
    > Graph Neural Networks (GNNs) have shown great power in various domains.
  - ZH:
    > 图神经网络（GNNs）在各个领域展现出了巨大的力量。

#### Paper 4

- Paper ID: `uxurbfWwRr`
- URL: https://openreview.net/forum?id=uxurbfWwRr
- Title / 标题:
  - EN:
    > Learning Time-Varying Convexifications of Multiple Fairness Measures
  - ZH:
    > 学习多重公平性度量（fairness measures）的时变凸化（convexifications）
- Abstract / 摘要:
  - EN:
    > There is an increasing appreciation that one may need to consider multiple measures of fairness, e.g., considering multiple group and individual fairness notions. The relative weights of the fairness regularisers are a priori unknown, may be time varying, and need to be learned on the fly. We consider the learning of time-varying convexifications of multiple fairness measures with traditional full-information feedback and with limited graph-structured feedback.
  - ZH:
    > 人们越来越认识到可能需要考虑多重公平性度量，例如，考虑多个群体和个人的公平性概念。公平性正则化项（fairness regularisers）的相对权重是先验未知的，可能是时变的，并且需要动态学习。我们考虑在传统的全信息反馈和有限的图结构反馈下，学习多重公平性度量的时变凸化。
- Key contribution / 关键贡献:
  - EN:
    > This paper proposes a general framework for integrating conflicting fairness measures into decision-making algorithms, recognizing the increasing importance of balancing them.
  - ZH:
    > 本文提出了一个通用框架，用于将相互冲突的公平性度量整合到决策算法中，认识到了平衡它们的重要性日益增加。
- Limitation / 局限:
  - EN:
    > Although the paper is understandable, the structure/organization of the presentation could be improved.
  - ZH:
    > 尽管本文可以理解，但陈述的结构/组织可以改进。
- Important result / 重要结果:
  - EN:
    > As demonstrated in the advertising example presented in the paper, considering the balance between various fairness regularizers in decision-making is crucial for devising a fair decision-making algorithm.
  - ZH:
    > 正如本文提出的广告示例所证明的，在决策中考虑各种公平性正则化项之间的平衡对于设计一个公平的决策算法是至关重要的。

## t1_formal_018

- Batch: `fifth40`
- Context ID: `smallari_fifth40_019_series_time_forecasting_long_term_multivariate__v02_fifth40`
- Area: `time series and dynamical systems`
- Top terms: `series, time, forecasting, long-term, multivariate`
- Mean pairwise cosine: `0.0721`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fifth40 neighborhood around time series and dynamical systems: series, time, forecasting, long-term, multivariate. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文构成了一个围绕时间序列和动力系统的新鲜 fifth40 邻域（neighborhood）：系列、时间、预测、长期、多变量。该上下文立足于论文标题、摘要和审稿人局限性信号。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验（next-step experiment）。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fifth40 neighborhood around time series and dynamical systems: series, time, forecasting, long-term, multivariate, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕时间序列和动力系统的 fifth40 邻域：系列、时间、预测、长期、多变量，目标是针对在提供的审稿意见和摘要中可见的局限性或评估空白（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公共数据集和开放权重（open-weight）模型；最小验证所需的算力 <=8 A100 GPU-days；无专有模型权重；无未来论文的答案密钥（future-paper answer keys）；包含一个来自所提供论文的基线（baseline），以及一个失效模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的、可证伪的（falsifiable）下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `4f4HDfbwY5`
- URL: https://openreview.net/forum?id=4f4HDfbwY5
- Title / 标题:
  - EN:
    > CPDD: Generalized Compressed Representation for Multivariate Long-term Time Series Generation
  - ZH:
    > CPDD：用于多变量长期时间序列生成的广义压缩表示
- Abstract / 摘要:
  - EN:
    > The generation of time series has increasingly wide applications in many fields, such as electricity and energy. Generating realistic multivariate long time series is a crucial step towards making time series generative models practical, with the challenge being the balance between long-term dependencies and short-term feature learning. Towards this end, we propose a novel time series generative model named Compressed Patch Denoising Diffusion-model (CPDD). Concretely, CPDD first employs the Time-series Patch Compressed (TPC) module based on the patch mode decomposition method to obtain the latent encoding of multi-scale feature fusion. Subsequently, it utilizes a diffusion-based model to learn the latent distribution and decode the resulting samples, thereby achieving high-quality multivariate long-time series generation. Through extensive experiments, results show that CPDD achieves state-of-the-art performance in the generation task of multivariate long-time series. Furthermore, TPC also exhibits remarkable efficiency in terms of robustness and generalization in time series reconstruction.
  - ZH:
    > 时间序列的生成在电力和能源等许多领域有着越来越广泛的应用。生成逼真的多变量长时间序列是使时间序列生成模型实用化的关键一步，其挑战在于长期依赖和短期特征学习之间的平衡。为此，我们提出了一种名为压缩分块去噪扩散模型 (Compressed Patch Denoising Diffusion-model, CPDD) 的新型时间序列生成模型。具体而言，CPDD首先采用基于分块模式分解 (patch mode decomposition) 方法的时间序列分块压缩 (Time-series Patch Compressed, TPC) 模块来获得多尺度特征融合的潜在编码。随后，它利用基于扩散的模型来学习潜在分布并解码所得样本，从而实现高质量的多变量长时间序列生成。通过大量实验，结果表明CPDD在多变量长时间序列的生成任务中取得了最先进的 (state-of-the-art) 性能。此外，TPC在时间序列重建中的鲁棒性和泛化性方面也表现出显著的效率。
- Key contribution / 关键贡献:
  - EN:
    > This paper aims to address the challenge of balancing the long-term dependencies and short-term features in time series generation and proposes a novel model named Compressed Patch Denoising Diffusion-model (CPDD).
  - ZH:
    > 本文旨在解决时间序列生成中平衡长期依赖和短期特征的挑战，并提出了一种名为压缩分块去噪扩散模型 (Compressed Patch Denoising Diffusion-model, CPDD) 的新型模型。
- Limitation / 局限:
  - EN:
    > This paper identifies high computational demands as a limitation of existing methods, but the proposed approach also employs a computationally intensive Transformer-based architecture.
  - ZH:
    > 本文将高计算需求确定为现有方法的一个局限性，但所提出的方法也采用了计算密集型的基于Transformer的架构。
- Important result / 重要结果:
  - EN:
    > Through extensive experiments, results show that CPDD achieves state-of-the-art performance in the generation task of multivariate long-time series.
  - ZH:
    > 通过大量实验，结果表明CPDD在多变量长时间序列的生成任务中取得了最先进的 (state-of-the-art) 性能。

#### Paper 2

- Paper ID: `lmShn57DRD`
- URL: https://openreview.net/forum?id=lmShn57DRD
- Title / 标题:
  - EN:
    > Connecting the Patches: Multivariate Long-term Forecasting using Graph and Recurrent Neural Network
  - ZH:
    > 连接补丁：使用图和循环神经网络进行多元长期预测
- Abstract / 摘要:
  - EN:
    > Many Transformer-based models have achieved great performance on multivariate long-term time series forecasting (MLTSF) tasks in the past few years, but they are ineffective in capturing cross-channel dependencies and temporal order information. In multivariate time series analysis, the cross-channel dependencies can help the model understand the correlations between multivariate time series, and the consistency of time series is also essential for more accurate predictions. Therefore, we propose GRformer, adopting the Graph neural network (GNN) and position encoding based on recurrent neural network (RNN) to better process multivariate time series data. We design a mix-hop propagation layer and embed it in the feedforward neural network to encourage proper interaction between different time series. To introduce temporal order information, we use a multi-layer RNN to recursively generate positional embeddings for sequence elements. Experiments on eight real-world datasets show that our model can achieve more accurate predictions on MLTSF tasks.
  - ZH:
    > 在过去几年中，许多基于Transformer的模型在多元长期时间序列预测（MLTSF）任务上取得了出色的性能，但它们在捕捉跨通道依赖和时间顺序信息方面效果不佳。在多元时间序列分析中，跨通道依赖可以帮助模型理解多元时间序列之间的相关性，并且时间序列的一致性对于更准确的预测也是必不可少的。因此，我们提出GRformer，采用图神经网络（GNN）和基于循环神经网络（RNN）的位置编码来更好地处理多元时间序列数据。我们设计了一个混合跳传播层（mix-hop propagation layer）并将其嵌入到前馈神经网络中，以鼓励不同时间序列之间的适当交互。为了引入时间顺序信息，我们使用多层RNN递归地为序列元素生成位置嵌入。在八个真实世界数据集上的实验表明，我们的模型能在MLTSF任务上取得更准确的预测。
- Key contribution / 关键贡献:
  - EN:
    > This paper proposes GRformer, a new neural architecture for multivariate long-term time series forecasting (MLTSF).
  - ZH:
    > 本文提出了GRformer，一种用于多元长期时间序列预测（MLTSF）的新神经架构。
- Limitation / 局限:
  - EN:
    > I am not sure what I am seeing in Figure 1(b), and I don’t understand how to interpret the authors' claim that cross-channel interaction is chaotic based on simply visualizing the weight matrices of the Transformer's dense layer (internal MLP).
  - ZH:
    > 我不确定我在Figure 1(b)中看到了什么，并且我不理解如何仅仅基于可视化Transformer的密集层（内部MLP）的权重矩阵来解释作者关于跨通道交互是混乱的主张。
- Important result / 重要结果:
  - EN:
    > Many Transformer-based models have achieved great performance on multivariate long-term time series forecasting (MLTSF) tasks in the past few years, but they are ineffective in capturing cross-channel dependencies and temporal order information.
  - ZH:
    > 在过去几年中，许多基于Transformer的模型在多元长期时间序列预测（MLTSF）任务上取得了出色的性能，但它们在捕捉跨通道依赖和时间顺序信息方面效果不佳。

#### Paper 3

- Paper ID: `WS7GuBDFa2`
- URL: https://openreview.net/forum?id=WS7GuBDFa2
- Title / 标题:
  - EN:
    > Learning to Embed Time Series Patches Independently
  - ZH:
    > 学习独立嵌入时间序列分块
- Abstract / 摘要:
  - EN:
    > Masked time series modeling has recently gained much attention as a self-supervised representation learning strategy for time series. Inspired by masked image modeling in computer vision, recent works first patchify and partially mask out time series, and then train Transformers to capture the dependencies between patches by predicting masked patches from unmasked patches. However, we argue that capturing such patch dependencies might not be an optimal strategy for time series representation learning; rather, learning to embed patches independently results in better time series representations. Specifically, we propose to use 1) the simple patch reconstruction task, which autoencode each patch without looking at other patches, and 2) the simple patch-wise MLP that embeds each patch independently. In addition, we introduce complementary contrastive learning to hierarchically capture adjacent time series information efficiently. Our proposed method improves time series forecasting and classification performance compared to state-of-the-art Transformer-based models, while it is more efficient in terms of the number of parameters and training time. Code is available at this repository: https://github.com/seunghan96/pits.
  - ZH:
    > 掩码时间序列建模 (Masked time series modeling) 最近作为时间序列的一种自监督表示学习策略获得了广泛关注。受计算机视觉中掩码图像建模的启发，最近的研究首先对时间序列进行分块 (patchify) 并部分掩蔽 (mask out)，然后训练 Transformers 通过从非掩码分块预测掩码分块来捕获分块之间的依赖关系。然而，我们认为捕获这种分块依赖关系可能不是时间序列表示学习的最佳策略；相反，学习独立嵌入分块会产生更好的时间序列表示。具体而言，我们提出使用 1) 简单的分块重构任务，该任务在不查看其他分块的情况下对每个分块进行自编码 (autoencode)，以及 2) 简单的逐分块 (patch-wise) MLP，它独立地嵌入每个分块。此外，我们引入了互补的对比学习 (contrastive learning) 来有效地分层捕获相邻的时间序列信息。与最先进的基于 Transformer 的模型相比，我们提出的方法提高了时间序列预测和分类性能，同时在参数数量和训练时间方面更加高效。代码可在此仓库获取：https://github.com/seunghan96/pits。
- Key contribution / 关键贡献:
  - EN:
    > Authors propose a mix of contrastive learning and masked modelling on time-series data, and a patch-independent approach to reconstruction is shown to outperform patch dependant (vanilla mask modelling) approach.
  - ZH:
    > 作者提出了在时间序列数据上混合对比学习和掩码建模，并且一种独立于分块的重构方法被证明优于依赖分块（基础掩码建模，vanilla mask modelling）的方法。
- Limitation / 局限:
  - EN:
    > Novelty is weak, their contribution auto encoding is quite established before masked modelling literature and one of the early approaches to representation learning.
  - ZH:
    > 新颖性较弱，他们的贡献自编码 (auto encoding) 在掩码建模文献之前就已经相当成熟，并且是表示学习的早期方法之一。
- Important result / 重要结果:
  - EN:
    > Our proposed method improves time series forecasting and classification performance compared to state-of-the-art Transformer-based models, while it is more efficient in terms of the number of parameters and training time.
  - ZH:
    > 与最先进的基于 Transformer 的模型相比，我们提出的方法提高了时间序列预测和分类性能，同时在参数数量和训练时间方面更加高效。

#### Paper 4

- Paper ID: `PTjKXwrVCT`
- URL: https://openreview.net/forum?id=PTjKXwrVCT
- Title / 标题:
  - EN:
    > Forecasting Needles in a Time Series Haystack
  - ZH:
    > 预测时间序列干草堆中的针
- Abstract / 摘要:
  - EN:
    > Shocks and sudden spikes are common characteristics of real-world time series data. For example, demand surges or electricity outages often occur in time series data, manifesting as spikes (“Needles”) added to the regular time series (“Haystack”). Despite their importance, it is surprising to find their absence in the benchmarking protocol at the frontier of time series research—Time Series Foundation Models (TSFMs). To address this gap, we present the Needle-in-a-Time-Series-Haystack (NiTH) Benchmark, which includes both synthetic and real-world spiky time series data from diverse domains like traffic, energy, and biomedical systems. For synthetic data, we develop a flexible framework using Poisson-based modeling to generate spiky time series, allowing us to evaluate forecast models under various conditions. To accurately assess model performance, we introduce a new metric based on Dynamic Time Warping, specifically designed for spiky data. We evaluate the zero-shot forecasting capabilities of 6 popular TSFMs over 64 million observations, identifying their limitations related to architecture, tokenization, and loss functions. Furthermore, we demonstrate that the incorporation of the proposed NiTH dataset, due to its diversity compared to the common pre-training corpus of TSFMs, results in improved performance.
  - ZH:
    > 冲击和突然的尖峰是现实世界时间序列（time series）数据的常见特征。例如，需求激增或停电经常在时间序列数据中发生，表现为添加到常规时间序列（“Haystack”）上的尖峰（“Needles”）。尽管它们很重要，但令人惊讶的是发现在时间序列研究前沿——时间序列基础模型（Time Series Foundation Models, TSFMs）的基准测试（benchmarking）协议中它们缺席了。为了解决这一空白，我们提出了 Needle-in-a-Time-Series-Haystack (NiTH) 基准，它包括来自交通、能源和生物医学系统等不同领域的合成和现实世界的尖峰时间序列数据。对于合成数据，我们开发了一个使用基于泊松（Poisson）建模的灵活框架来生成尖峰时间序列，允许我们在各种条件下评估预测模型。为了准确评估模型性能，我们引入了一种基于动态时间规整（Dynamic Time Warping）的新指标，专门为尖峰数据设计。我们在6400万个观测值上评估了6个流行的 TSFMs 的零样本（zero-shot）预测能力，识别了它们与架构、标记化（tokenization）和损失函数相关的局限性。此外，我们证明，纳入所提出的 NiTH 数据集，由于其与 TSFMs 常见预训练语料库相比的多样性，能够带来性能的提升。
- Key contribution / 关键贡献:
  - EN:
    > The authors study the problem of forecasting spiky time series.
  - ZH:
    > 作者研究了预测尖峰时间序列的问题。
- Limitation / 局限:
  - EN:
    > Clarity**: The paper introduces a lot of "novel" things, and mathematical instruments to model and evaluate time series models on spiky data.
  - ZH:
    > 清晰度**：这篇论文引入了许多“新颖”的事物，以及用来在尖峰数据上对时间序列模型进行建模和评估的数学工具。
- Important result / 重要结果:
  - EN:
    > Despite their importance, it is surprising to find their absence in the benchmarking protocol at the frontier of time series research—Time Series Foundation Models (TSFMs).
  - ZH:
    > 尽管它们很重要，但令人惊讶的是发现在时间序列研究前沿——时间序列基础模型（Time Series Foundation Models, TSFMs）的基准测试协议中它们缺席了。

## t1_formal_019

- Batch: `fifth40`
- Context ID: `smallari_fifth40_020_protein_structure_design_proteins_backbone__v02_fifth40`
- Area: `diffusion and generative modeling`
- Top terms: `protein, structure, design, proteins, backbone`
- Mean pairwise cosine: `0.109`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fifth40 neighborhood around diffusion and generative modeling: protein, structure, design, proteins, backbone. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕扩散与生成模型 (diffusion and generative modeling)：蛋白质、结构、设计、蛋白质、主链 (protein, structure, design, proteins, backbone) 形成了一个全新的 fifth40 邻域 (neighborhood)。该背景基于论文标题、摘要和审稿人局限性信号 (limitation signals)。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fifth40 neighborhood around diffusion and generative modeling: protein, structure, design, proteins, backbone, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合这个围绕扩散与生成模型：蛋白质、结构、设计、蛋白质、主链的 fifth40 邻域，针对在所提供的审稿意见和摘要中可见的局限性或评估空白 (evaluation gap)。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重 (open-weight) 模型；最小验证耗时 <=8 A100 GPU-days；无专有模型权重；无未来论文的答案标准 (answer keys)；包含一个来自所提供论文的基线 (baseline)，以及一个失败模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的可证伪的下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `TVQLu34bdw`
- URL: https://openreview.net/forum?id=TVQLu34bdw
- Title / 标题:
  - EN:
    > Proteina: Scaling Flow-based Protein Structure Generative Models
  - ZH:
    > Proteina：扩展基于流的蛋白质结构生成模型
- Abstract / 摘要:
  - EN:
    > Recently, diffusion- and flow-based generative models of protein structures have emerged as a powerful tool for de novo protein design. Here, we develop *Proteina*, a new large-scale flow-based protein backbone generator that utilizes hierarchical fold class labels for conditioning and relies on a tailored scalable transformer architecture with up to $5\times$ as many parameters as previous models. To meaningfully quantify performance, we introduce a new set of metrics that directly measure the distributional similarity of generated proteins with reference sets, complementing existing metrics. We further explore scaling training data to millions of synthetic protein structures and explore improved training and sampling recipes adapted to protein backbone generation. This includes fine-tuning strategies like LoRA for protein backbones, new guidance methods like classifier-free guidance and autoguidance for protein backbones, and new adjusted training objectives. Proteina achieves state-of-the-art performance on de novo protein backbone design and produces diverse and designable proteins at unprecedented length, up to 800 residues. The hierarchical conditioning offers novel control, enabling high-level secondary-structure guidance as well as low-level fold-specific generation.
  - ZH:
    > 最近，基于扩散（diffusion）和流（flow）的蛋白质结构生成模型已成为从头（de novo）蛋白质设计的强大工具。在这里，我们开发了 *Proteina*，这是一种新的大规模基于流的蛋白质主链生成器，它利用分层折叠类别标签进行条件化（conditioning），并依赖于定制的可扩展 transformer 架构，其参数量最高可达先前模型的 $5\times$。为了有意义地量化性能，我们引入了一套新指标，直接测量生成的蛋白质与参考集之间的分布相似性，补充了现有指标。我们进一步探索将训练数据扩展到数百万个合成蛋白质结构，并探索适应于蛋白质主链生成的改进的训练和采样配方（recipes）。这包括用于蛋白质主链的 LoRA 等微调策略、用于蛋白质主链的无分类器引导（classifier-free guidance）和自动引导（autoguidance）等新引导方法，以及新调整的训练目标。Proteina 在从头蛋白质主链设计上实现了最先进的（state-of-the-art）性能，并生成了长度达到前所未有（高达 800 个残基）的多样且可设计的蛋白质。分层条件化提供了新颖的控制，实现了高层级的二级结构引导以及低层级的特定折叠生成。
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces Proteína, a foundational model for generating protein backbones with innovative fold class conditioning for precise control over structure.
  - ZH:
    > 本文介绍了 Proteína，这是一个用于生成蛋白质主链的基础模型，带有创新的折叠类别条件化，可实现对结构的精确控制。
- Limitation / 局限:
  - EN:
    > In line 119, a partial derivative seems mistakenly written as a total derivative, and the divergence is incorrectly labeled as a gradient.
  - ZH:
    > 在第 119 行，偏导数似乎被错误地写成了全导数，并且散度被错误地标记为梯度。
- Important result / 重要结果:
  - EN:
    > We further explore scaling training data to millions of synthetic protein structures and explore improved training and sampling recipes adapted to protein backbone generation.
  - ZH:
    > 我们进一步探索将训练数据扩展到数百万个合成蛋白质结构，并探索适应于蛋白质主链生成的改进的训练和采样配方（recipes）。

#### Paper 2

- Paper ID: `mPMLZv4kSL`
- URL: https://openreview.net/forum?id=mPMLZv4kSL
- Title / 标题:
  - EN:
    > ProteinWeaver: A Divide-and-Assembly Approach for Protein Backbone Design
  - ZH:
    > ProteinWeaver：一种用于蛋白质主链设计的“分而组装”方法
- Abstract / 摘要:
  - EN:
    > Nature creates diverse proteins through a 'divide and assembly' strategy. Inspired by this idea, we introduce ProteinWeaver, a two-stage framework for protein backbone design. Our method first generates individual protein domains, then employs an SE(3) diffusion model to flexibly assemble these domains. A key challenge lies in the assembling step, given the complex and rugged nature of the inter-domain interaction landscape. To address this challenge, we employ preference alignment to discern complex relationships between structure and interaction landscapes through comparative analysis of generated samples. Comprehensive experiments demonstrate that ProteinWeaver: (1) generates high-quality, novel protein backbones through versatile domain assembly; (2) outperforms RFdiffusion, the current state-of-the-art in backbone design, by 13% and 39% for long-chain proteins; (3) shows the potential for cooperative function design through illustrative case studies. To sum up, by introducing a 'divide-and-assembly' paradigm, ProteinWeaver advances protein engineering and opens new avenues for functional protein design.
  - ZH:
    > 自然界通过一种“分而组装”（divide and assembly）策略创造出多样的蛋白质。受此想法启发，我们引入了ProteinWeaver，这是一个用于蛋白质主链设计（protein backbone design）的两阶段框架。我们的方法首先生成单独的蛋白质结构域（protein domains），然后采用SE(3)扩散模型（diffusion model）灵活地组装这些结构域。鉴于域间相互作用景观（inter-domain interaction landscape）的复杂和崎岖性质，一个关键挑战在于组装步骤。为了应对这一挑战，我们采用偏好对齐（preference alignment），通过对生成样本的比较分析来辨别结构和相互作用景观之间的复杂关系。综合实验表明，ProteinWeaver：（1）通过多功能的结构域组装生成高质量、新颖的蛋白质主链；（2）对于长链蛋白质，以13%和39%的优势超越了目前主链设计中的最先进技术RFdiffusion；（3）通过说明性的案例研究展示了协同功能设计（cooperative function design）的潜力。总而言之，通过引入一种“分而组装”范式，ProteinWeaver推进了蛋白质工程（protein engineering），并为功能性蛋白质设计开辟了新途径。
- Key contribution / 关键贡献:
  - EN:
    > The paper introduces ProteinWeaver, a two-stage framework for protein backbone design.
  - ZH:
    > 本文引入了ProteinWeaver，这是一个用于蛋白质主链设计的两阶段框架。
- Limitation / 局限:
  - EN:
    > The comparative evaluation is insufficient.
  - ZH:
    > 比较评估（comparative evaluation）是不充分的。
- Important result / 重要结果:
  - EN:
    > Comprehensive experiments demonstrate that ProteinWeaver: (1) generates high-quality, novel protein backbones through versatile domain assembly; (2) outperforms RFdiffusion, the current state-of-the-art in backbone design, by 13% and 39% for long-chain proteins; (3) shows the potential for cooperative function design through illustrative case studies.
  - ZH:
    > 综合实验表明，ProteinWeaver：（1）通过多功能的结构域组装生成高质量、新颖的蛋白质主链；（2）对于长链蛋白质，以13%和39%的优势超越了目前主链设计中的最先进技术RFdiffusion；（3）通过说明性的案例研究展示了协同功能设计的潜力。

#### Paper 3

- Paper ID: `kPlePgo1Nw`
- URL: https://openreview.net/forum?id=kPlePgo1Nw
- Title / 标题:
  - EN:
    > Learning the Language of Protein Structure
  - ZH:
    > 学习蛋白质结构的语言
- Abstract / 摘要:
  - EN:
    > Representation learning and \emph{de novo} generation of proteins are pivotal computational biology tasks. Whilst natural language processing (NLP) techniques have proven highly effective for protein sequence modelling, structure modelling presents a complex challenge, primarily due to its continuous and three-dimensional nature. Motivated by this discrepancy, we introduce an approach using a vector-quantized autoencoder that effectively tokenizes protein structures into discrete representations. This method transforms the continuous, complex space of protein structures into a manageable, discrete format with a codebook ranging from 4096 to 64000 tokens, achieving high-fidelity reconstructions with backbone root mean square deviations (RMSD) of approximately 1-5 \AA. To demonstrate the efficacy of our learned representations, we show that a simple GPT model trained on our codebooks can generate novel, diverse, and designable protein structures. Our approach not only provides representations of protein structure, but also mitigates the challenges of disparate modal representations and sets a foundation for seamless, multi-modal integration, enhancing the capabilities of computational methods in protein design.
  - ZH:
    > 蛋白质的表示学习和 \emph{de novo} 生成是关键的计算生物学任务。尽管自然语言处理 (NLP) 技术已被证明对蛋白质序列建模非常有效，但结构建模提出了一项复杂的挑战，这主要是由于其连续和三维的性质。受这种差异的启发，我们引入了一种使用向量量化自编码器（vector-quantized autoencoder）的方法，该方法有效地将蛋白质结构标记化（tokenize）为离散表示。该方法将连续、复杂的蛋白质结构空间转换为易于管理的离散格式，其密码本（codebook）范围从 4096 到 64000 个标记（tokens），实现了高保真重建，主链均方根偏差 (RMSD) 约为 1-5 \AA。为了证明我们学习到的表示的功效，我们展示了一个在我们的密码本上训练的简单 GPT 模型可以生成新颖的、多样的且可设计的蛋白质结构。我们的方法不仅提供了蛋白质结构的表示，还缓解了不同模态表示的挑战，并为无缝的多模态集成奠定了基础，增强了蛋白质设计中计算方法的能力。
- Key contribution / 关键贡献:
  - EN:
    > The work proposes to use an FSQ-based auto-encoder to tokenize 3D protein structures at the residue level.
  - ZH:
    > 该工作提出使用基于 FSQ 的自编码器在残基级别对 3D 蛋白质结构进行标记化（tokenize）。
- Limitation / 局限:
  - EN:
    > An ablation study comparing the FS quantization with VQ would help motivate the architectural choice.
  - ZH:
    > 一项比较 FS 量化与 VQ 的消融研究将有助于说明架构选择的动机。
- Important result / 重要结果:
  - EN:
    > To demonstrate the efficacy of our learned representations, we show that a simple GPT model trained on our codebooks can generate novel, diverse, and designable protein structures.
  - ZH:
    > 为了证明我们学习到的表示的功效，我们展示了一个在我们的密码本上训练的简单 GPT 模型可以生成新颖的、多样的且可设计的蛋白质结构。

#### Paper 4

- Paper ID: `hiciJQdmpw`
- URL: https://openreview.net/forum?id=hiciJQdmpw
- Title / 标题:
  - EN:
    > Dual Flows with Contrastive Guidance for Generating Highly Designable Proteins
  - ZH:
    > 具有对比引导的双重流用于生成高可设计性蛋白质
- Abstract / 摘要:
  - EN:
    > Deep generative models have achieved substantial success in protein design. A prevalent approach for de novo protein design involves initially designing a protein backbone structure using deep generative models, such as diffusion and flow models, followed by using a separate inverse folding model to design the correponding sequence. Recently, co-design methods, which aim to jointly generate the structure and sequence of a protein, have attracted considerable attention. Despite this, co-designing sequences and structures of long proteins remains challenging. The complexity of this high-dimensional multimodal generative modeling makes sampling of diffusion and flow models prone to accumulated errors, often leading to non-designable regions. To tackle this challenge, we introduce a contrastive guided sampling algorithm with dual multimodal flows to sample both sequences and structures of highly designable proteins. The contrastive guidance uses the lower-quality flow to help the higher-quality flow avoid non-designable regions by gently steering it during sampling. Our method achieves designability of 80% for length-400 proteins and 37% for length-500 proteins, significantly outperforming previous approaches.
  - ZH:
    > 深度生成模型在蛋白质设计中取得了巨大成功。从头 (de novo) 蛋白质设计的一种普遍方法包括首先使用深度生成模型（如扩散 (diffusion) 和流 (flow) 模型）设计蛋白质主链 (backbone) 结构，然后使用单独的反向折叠 (inverse folding) 模型来设计相应的序列。最近，旨在联合生成蛋白质结构和序列的协同设计 (co-design) 方法引起了相当大的关注。尽管如此，长蛋白质的序列和结构的协同设计仍然具有挑战性。这种高维多模态生成建模的复杂性使得扩散和流模型的采样容易产生累积误差，通常会导致不可设计的区域。为了应对这一挑战，我们引入了一种具有双重多模态流的对比引导采样算法，以对高可设计性蛋白质的序列和结构进行采样。对比引导在采样过程中通过温和地引导，使用较低质量的流来帮助较高质量的流避开不可设计的区域。我们的方法在长度为400的蛋白质上实现了80%的可设计性，在长度为500的蛋白质上实现了37%的可设计性，显著优于以前的方法。
- Key contribution / 关键贡献:
  - EN:
    > The authors demonstrate that by carefully curating high- and low-quality generated samples from Multiflow, they can fine-tune the model into separate high-quality and low-quality versions.
  - ZH:
    > 作者证明，通过仔细整理来自 Multiflow 的高质量和低质量生成样本，他们可以将模型微调 (fine-tune) 为单独的高质量和低质量版本。
- Limitation / 局限:
  - EN:
    > One key issue with Multiflow is that its sequence/structure co-design does not outperform a simpler approach: designing the backbone and then performing inverse folding.
  - ZH:
    > Multiflow 的一个关键问题是其序列/结构协同设计并未优于一种更简单的方法：设计主链，然后执行反向折叠。
- Important result / 重要结果:
  - EN:
    > Deep generative models have achieved substantial success in protein design.
  - ZH:
    > 深度生成模型在蛋白质设计中取得了巨大成功。

## t1_formal_020

- Batch: `fifth40`
- Context ID: `smallari_fifth40_033_instruction_high_quality_tuning_fine_tuning_sele__v02_fifth40`
- Area: `multimodal and vision-language learning`
- Top terms: `instruction, high-quality, tuning, fine-tuning, selection`
- Mean pairwise cosine: `0.1024`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fifth40 neighborhood around multimodal and vision-language learning: instruction, high-quality, tuning, fine-tuning, selection. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕多模态和视觉语言学习 (multimodal and vision-language learning) 构成了一个全新的 fifth40 邻域：指令 (instruction)、高质量 (high-quality)、调优 (tuning)、微调 (fine-tuning)、选择 (selection)。该上下文基于论文标题、摘要以及审稿人的局限性信号 (limitation signals)。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fifth40 neighborhood around multimodal and vision-language learning: instruction, high-quality, tuning, fine-tuning, selection, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，综合这个围绕多模态和视觉语言学习的 fifth40 邻域：指令、高质量、调优、微调、选择，针对在提供的审稿意见和摘要中可见的局限性或评估空白 (evaluation gap)。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型 (open-weight models)；最小验证 <=8 A100 GPU-days；无专有模型权重；无未来论文答案键 (future-paper answer keys)；包括一个来自所提供论文的基线 (baseline) 以及一个失败模式 (failure-mode) 或消融诊断 (ablation diagnostic)。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪 (falsifiable) 下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `7qMrDf9zFU`
- URL: https://openreview.net/forum?id=7qMrDf9zFU
- Title / 标题:
  - EN:
    > Priority on High-Quality: Instruction Data Selection for Optimized Instruction Tuning
  - ZH:
    > 以高质量为优先：用于优化的指令微调的指令数据选择
- Abstract / 摘要:
  - EN:
    > Large Language Models (LLMs) have demonstrated a remarkable understanding of language nuances through instruction tuning, enabling them to effectively tackle various natural language processing tasks. Previous research on instruction tuning mainly focused on the quantity of instruction data. Recent studies indicate that the quality of instruction data is more significant than the quantity of data. Even selecting a small amount of high-quality data can achieve optimal fine-tuning effects. However, existing selection methods have severe limitations in defining the quality of each instruction data and considering the balance between data quality and data diversity. To address these challenges, we propose a strategy that utilizes noise injection to identify the quality of instruction data. We also implement the strategy of combining inter-class diversity and intra-class diversity to improve model performance. Experimental results demonstrate that our method significantly outperforms the model trained on the full dataset when utilizing only 12% of the entire dataset. Our study provides a new perspective on noise injection in the field of instruction tuning, and also illustrates that a high-quality instruction dataset should possess both quality and diversity. Additionally, we have published our selected high-quality instruction data.
  - ZH:
    > 大型语言模型（Large Language Models, LLMs）通过指令微调（instruction tuning）展示了对语言细微差别的卓越理解，使其能够有效地处理各种自然语言处理任务。先前关于指令微调的研究主要集中在指令数据的数量上。最近的研究表明，指令数据的质量比数据的数量更重要。即使选择少量的高质量数据也能达到最佳的微调（fine-tuning）效果。然而，现有的选择方法在定义每条指令数据的质量以及考虑数据质量与数据多样性之间的平衡方面存在严重的局限性。为了应对这些挑战，我们提出了一种利用噪声注入（noise injection）来识别指令数据质量的策略。我们还实施了结合类间多样性（inter-class diversity）和类内多样性（intra-class diversity）的策略以提高模型性能。实验结果表明，当仅利用整个数据集的12%时，我们的方法显著优于在完整数据集上训练的模型。我们的研究为指令微调领域的噪声注入提供了新的视角，同时也说明了一个高质量的指令数据集应该兼具质量和多样性。此外，我们已经发布了我们选出的高质量指令数据。
- Key contribution / 关键贡献:
  - EN:
    > The authors propose a data selection approach using noise injection to assess instruction quality by introducing controlled noise into the input data and measuring the consistency of the model's output distribution.
  - ZH:
    > 作者提出了一种使用噪声注入的数据选择方法，通过向输入数据中引入受控的噪声并测量模型输出分布的一致性来评估指令质量。
- Limitation / 局限:
  - EN:
    > The paper’s experimental results could be improved with additional baseline comparisons.
  - ZH:
    > 通过额外的基线比较（baseline comparisons），该论文的实验结果可以得到改进。
- Important result / 重要结果:
  - EN:
    > Large Language Models (LLMs) have demonstrated a remarkable understanding of language nuances through instruction tuning, enabling them to effectively tackle various natural language processing tasks.
  - ZH:
    > 大型语言模型（LLMs）通过指令微调展示了对语言细微差别的卓越理解，使其能够有效地处理各种自然语言处理任务。

#### Paper 2

- Paper ID: `Q9vYgjcvrX`
- URL: https://openreview.net/forum?id=Q9vYgjcvrX
- Title / 标题:
  - EN:
    > SASS: Self-Alignment with Semi-Supervised Instruction Data Generation
  - ZH:
    > SASS：使用半监督指令数据生成的自我对齐
- Abstract / 摘要:
  - EN:
    > Instruction tuning is instrumental in enabling Large Language Models~(LLMs) to follow user instructions to complete various open-domain tasks. The success of instruction tuning depends on the availability of high-quality instruction data. Owing to the exorbitant cost and substandard quality of human annotation, recent works have been deeply engaged in the exploration of the utilization of powerful closed-source models to generate instruction data automatically. However, these methods carry potential risks arising from the usage requirements of powerful closed-source models, which strictly forbid the utilization of their outputs to develop machine learning models. To deal with this problem, in this work, we explore alternative approaches to generate high-quality instruction data that do not rely on closed-source models. Our exploration includes an investigation of various existing instruction generation methods, culminating in the integration of the most efficient variant with two novel strategies to enhance the quality further. Evaluation results from two benchmarks and the GPT-4 model demonstrate the effectiveness of our generated instruction data, which can outperform Alpaca, a method reliant on closed-source models. We hope that more progress can be achieved in generating high-quality instruction data without using closed-source models.
  - ZH:
    > 指令微调 (Instruction tuning) 在使大语言模型~(LLMs)能够遵循用户指令以完成各种开放领域任务方面发挥着重要作用。指令微调的成功取决于高质量指令数据的可用性。由于人工标注的极其高昂的成本和不合格的质量，最近的工作深深致力于探索利用强大的闭源模型来自动生成指令数据。然而，这些方法带有因强大闭源模型的使用要求而产生的潜在风险，这些要求严格禁止利用它们的输出来开发机器学习模型。为了处理这个问题，在这项工作中，我们探索了不依赖于闭源模型来生成高质量指令数据的替代方法。我们的探索包括对各种现有指令生成方法的调查，最终将最高效的变体与两种新颖策略相整合，以进一步提升质量。来自两个基准和 GPT-4 模型的评估结果证明了我们生成的指令数据的有效性，它可以超越依赖于闭源模型的方法 Alpaca。我们希望在不使用闭源模型生成高质量指令数据方面能够取得更多进展。
- Key contribution / 关键贡献:
  - EN:
    > This work introduces SASS, a semi-supervised instruction generation method with open-source models.
  - ZH:
    > 这项工作引入了 SASS，一种使用开源模型的半监督指令生成方法。
- Limitation / 局限:
  - EN:
    > Need more evaluation.** - While the proposed work improves over the LongForm benchmark, more evaluation is needed.
  - ZH:
    > 需要更多评估。** - 虽然提出的工作在 LongForm 基准上有所改进，但需要更多评估。
- Important result / 重要结果:
  - EN:
    > Evaluation results from two benchmarks and the GPT-4 model demonstrate the effectiveness of our generated instruction data, which can outperform Alpaca, a method reliant on closed-source models.
  - ZH:
    > 来自两个基准和 GPT-4 模型的评估结果证明了我们生成的指令数据的有效性，它可以超越依赖于闭源模型的方法 Alpaca。

#### Paper 3

- Paper ID: `DNvzCsQG1D`
- URL: https://openreview.net/forum?id=DNvzCsQG1D
- Title / 标题:
  - EN:
    > InstructionGPT-4: A 200-Instruction Paradigm for Fine-Tuning MiniGPT-4
  - ZH:
    > InstructionGPT-4：用于微调MiniGPT-4的200指令范式
- Abstract / 摘要:
  - EN:
    > Multimodal large language models are typically trained in two stages: first pre-training on image-text pairs, and then fine-tuning using supervised vision-language instruction data. Recent studies have shown that large language models can achieve satisfactory results even with a limited amount of high-quality instruction-following data. In this paper, we introduce InstructionGPT-4, which is fine-tuned on a small dataset comprising only 200 examples, amounting to approximately 6% of the instruction-following data used in the alignment dataset for MiniGPT-4. To achieve this, we first propose several metrics to access the quality of multimodal instruction data. Based on these metrics, we present an effective and trainable data selector to automatically identify and filter low-quality vision-language data. By employing this method, InstructionGPT-4 outperforms the original MiniGPT-4 on various evaluations. Overall, our findings demonstrate that less but high-quality instruction tuning data is efficient in enabling multimodal large language models to generate better output.
  - ZH:
    > 多模态大语言模型通常在两个阶段进行训练：首先在图像-文本对上进行预训练，然后使用有监督的视觉-语言指令数据进行微调。最近的研究表明，即使使用数量有限的高质量指令遵循数据，大语言模型也能取得令人满意的结果。在本文中，我们介绍了InstructionGPT-4，它在一个仅包含200个示例的小型数据集上进行了微调，约占用于MiniGPT-4对齐数据集中的指令遵循数据的6%。为了实现这一目标，我们首先提出了几种指标来评估多模态指令数据的质量。基于这些指标，我们提出了一个有效且可训练的数据选择器，以自动识别并过滤低质量的视觉-语言数据。通过采用这种方法，InstructionGPT-4在各种评估中优于原始的MiniGPT-4。总而言之，我们的发现表明，少量但高质量的指令微调数据能有效地使多模态大语言模型生成更好的输出。
- Key contribution / 关键贡献:
  - EN:
    > The authors performed a series of steps aimed to selecting training data for multimodal large langauge models (MLLMs).
  - ZH:
    > 作者执行了一系列旨在为多模态大语言模型（MLLMs）选择训练数据的步骤。
- Limitation / 局限:
  - EN:
    > The most important weakness of the paper is the lack of baselines.
  - ZH:
    > 该论文最重要的弱点是缺乏基线（baselines）。
- Important result / 重要结果:
  - EN:
    > Recent studies have shown that large language models can achieve satisfactory results even with a limited amount of high-quality instruction-following data.
  - ZH:
    > 最近的研究表明，即使使用数量有限的高质量指令遵循数据，大语言模型也能取得令人满意的结果。

#### Paper 4

- Paper ID: `9wvVFldF0u`
- URL: https://openreview.net/forum?id=9wvVFldF0u
- Title / 标题:
  - EN:
    > InsBank: Evolving Instruction Subset for Ongoing Alignment
  - ZH:
    > InsBank：演化指令子集以实现持续对齐
- Abstract / 摘要:
  - EN:
    > Pre-trained large language models (LLMs) typically undergo instruction fine-tuning to improve alignment. Recent research highlights that the quality and diversity of instruction data are more critical than data quantity, prompting the selection of diverse, high-quality instruction subsets to reduce training costs. However, how to evolve these selected subsets alongside the development of new instruction data remains insufficiently explored. To achieve LLMs' ongoing alignment, we introduce Instruction Bank (InsBank), a continuously updated repository that integrates the latest valuable instructional data. We further propose Progressive Instruction Bank Evolution (PIBE), a novel framework designed to evolve InsBank effectively and efficiently over time. It firstly employs a gradual data selection strategy to maintain long-term efficiency, utilizing a representation-based diversity score that captures relationships between data points and retains historical information for comprehensive diversity evaluation. This also allows for flexible combination of diversity and quality scores during data selection and ranking. Extensive experiments demonstrate that PIBE significantly outperforms baseline methods in evolving InsBank. Additionally, PIBE enables users to flexibly extract smaller subsets based on their specific budget.
  - ZH:
    > 预训练大型语言模型（LLMs）通常经历指令微调（instruction fine-tuning）以改善对齐（alignment）。最近的研究强调，指令数据的质量和多样性比数据数量更为关键，这促使选择多样化、高质量的指令子集以降低训练成本。然而，如何随着新指令数据的发展来演化这些选定的子集仍未得到充分探索。为了实现LLMs的持续对齐，我们引入了指令库（Instruction Bank, InsBank），这是一个不断更新的存储库，整合了最新有价值的指令数据。我们进一步提出了渐进式指令库演化（Progressive Instruction Bank Evolution, PIBE），这是一种旨在随时间推移高效且有效地演化InsBank的新颖框架。它首先采用渐进的数据选择策略以保持长期效率，利用基于表示的多样性得分来捕获数据点之间的关系并保留历史信息以进行全面的多样性评估。这也允许在数据选择和排名期间灵活结合多样性和质量得分。广泛的实验表明，PIBE在演化InsBank方面显著优于基线方法。此外，PIBE使用户能够根据其特定预算灵活地提取较小的子集。
- Key contribution / 关键贡献:
  - EN:
    > The paper introduces Instruction Bank (InsBank), a continuously updated repository that integrates the latest valuable instruction data to enhance the alignment of Large Language Models (LLMs) over time.
  - ZH:
    > 该论文引入了指令库（Instruction Bank, InsBank），这是一个不断更新的存储库，整合了最新有价值的指令数据，以随着时间的推移增强大型语言模型（LLMs）的对齐。
- Limitation / 局限:
  - EN:
    > Lack of novelty: While the paper presents the InsBank concept and the PIBE framework, the methods employed largely combine existing techniques without substantial innovation.
  - ZH:
    > 缺乏新颖性：虽然该论文提出了InsBank概念和PIBE框架，但所采用的方法主要结合了现有技术，没有实质性的创新。
- Important result / 重要结果:
  - EN:
    > Pre-trained large language models (LLMs) typically undergo instruction fine-tuning to improve alignment.
  - ZH:
    > 预训练大型语言模型（LLMs）通常经历指令微调以改善对齐。
