# Task 02 — Human Calibration: Pairwise Answer Preference

英文原文为准，中文翻译仅供参考。请不要猜模型身份；Answer A / B 是匿名答案。

## 填完后先自检（必须做）

完成本任务和 Task 1 后，回到包根目录运行：

`python3 validate_annotations.py`

看到 `RESULT: PASS` 才提交。它只检查漏填和格式，不判断你的科学判断是否正确。

## Goal / 目的

对同一个论文邻域和同一个 open problem，比较两个 Lit2Test answer。选择哪个 answer 更适合作为 grounded、specific、minimal、feasible、falsifiable 的下一步研究实验。

## Overall decision / 总体选择

- `winner`: `A` / `B` / `TIE` / `INVALID`。
  - `A` or `B`: 一方整体更好。
  - `TIE`: 两者质量非常接近，或优缺点不同且无法稳定偏好。
  - `INVALID`: 至少一方严重缺失、不可读、偏离任务，导致无法正常比较。
- `confidence`: `low` / `medium` / `high`。

每一行的 `winner` 都必须填写。建议先比较并打完维度分，再回到本列确认最终选择。

## Dimension scores / 维度评分

每个 answer 分别打 `1`-`3`。`1` 表示弱，`2` 表示部分达标，`3` 表示明确达标。

如果 `winner=INVALID` 且答案缺失/不可读，无法合理评分的维度可以留空；其他 `A/B/TIE` 行必须填写全部维度分数。

- `grounding_score_a/b`: 是否真实利用 supplied papers 和 open problem。
  - `1`: 没有具体用到 supplied paper，基本换一组论文也能用。
  - `2`: 具体用到至少一篇论文，或提到多篇论文但没有说清它们之间的联系。
  - `3`: 具体用到至少两篇论文，并说清共同限制、机制张力或评估缺口。
- `hypothesis_specificity_score_a/b`: 假设是否具体、可检验。
  - 检查三点：`H1` 实验对象/条件，`H2` 机制，`H3` 预期差异。
  - `1`: 三点中最多有一项。
  - `2`: 三点中有两项。
  - `3`: 三点都有。
- `minimality_feasibility_score_a/b`: 实验是否足够小且可执行，也是否写清楚到可以实际运行。
  - 检查五点：明确 dataset/task、明确 baseline/control、只有一个主要比较、步骤/条件写清、资源在约束内。
  - `1`: 缺少多项关键内容，或明显过大/超出资源约束。
  - `2`: 大体可做，但缺少一两项重要细节或资源估计。
  - `3`: 实验小而具体，数据、对照、步骤和资源约束基本齐全。
- `decisive_metric_score_a/b`: metric 是否能决定假设。
  - 检查三点：有具体主指标、指标对应假设机制、有比较/阈值/slice。
  - `1`: 三点中最多有一项。
  - `2`: 三点中有两项。
  - `3`: 三点都有。
- `falsifiability_score_a/b`: 是否有真正能推翻假设的结果。
  - 检查三点：明确负结果、有比较/阈值、该负结果确实会削弱假设。
  - `1`: 三点中最多有一项。
  - `2`: 三点中有两项。
  - `3`: 三点都有。

## 如果材料不够，怎么处理

| 问题来源 | 处理 |
|---|---|
| 答案缺失或不可读 | `winner=INVALID`，并填写 `invalid_reason` |
| 两个答案都可读，但材料不足以比较 | `winner=TIE`，`tie_reason=insufficient_context` |
| 材料不完整但一方明显更好 | 正常选 `A` 或 `B`，同时降低 `confidence` |
| Task 1 的摘要不足 | 在 Task 1 使用 `needs_full_text_to_judge`，并降低 `answerability` |

`TIE + insufficient_context` 不表示两个答案真的质量相同，只表示在当前材料下无法稳定区分。请在 `notes_zh` 中写明缺少什么信息。`confidence=low` 时也请写一句原因。

## Tie / invalid fields

- `tie_reason`: winner 为 `TIE` 时填写；可选值：`too_close`, `both_good`, `both_bad`, `different_tradeoff`, `insufficient_context`, `other`。
- `invalid_reason`: winner 为 `INVALID` 时填写；可选值：`missing_answer`, `not_about_task`, `unreadable`, `unsafe_or_irrelevant`, `other`。

`tie_reason` 的含义：

- `too_close`: 两者只有很小差别，无法稳定选择。
- `both_good`: 两者都达到较高质量。
- `both_bad`: 两者都有明显问题。
- `different_tradeoff`: 两者各有优势，侧重点不同。
- `insufficient_context`: 两者都能读，但材料不足以比较。
- `other`: 其他原因，需要在 `notes_zh` 说明。

`invalid_reason` 的含义：

- `missing_answer`: 至少一个答案缺失。
- `not_about_task`: 答案明显偏离任务。
- `unreadable`: 内容无法正常阅读或解析。
- `unsafe_or_irrelevant`: 内容不相关或不适合作为本任务答案。
- `other`: 其他原因，需要在 `notes_zh` 说明。

## Weakness taxonomy / 弱点分类

当 winner 是 `A` 或 `B` 时，请给 loser 选择主要弱点 `loser_primary_weakness`，可选次要弱点 `loser_secondary_weakness`。可选值：`weak_grounding`, `generic_hypothesis`, `overbroad_or_infeasible`, `missing_baseline_or_control`, `weak_decisive_metric`, `no_real_falsification`, `misread_task_or_invalid`, `unclear_writing`, `other`。

定义：

- `weak_grounding`: 没有真正基于给定论文；像通用提案。
- `generic_hypothesis`: 假设太泛，缺少机制、条件或可检验方向。
- `overbroad_or_infeasible`: 实验范围过大、资源不现实，或缺少可执行步骤。
- `missing_baseline_or_control`: 没有关键 baseline、control group、ablation 或对照条件，导致结果不可解释。
- `weak_decisive_metric`: metric 太普通，不能判断核心机制或失败模式。
- `no_real_falsification`: falsifying result 不能真正推翻假设，或只是重复“没有提升”。
- `misread_task_or_invalid`: 误解 open problem、答非所问、字段缺失或不可读。
- `unclear_writing`: 表达混乱导致难以判断。
- `other`: 其他，需在 `notes_zh` 简述。

## Other fields / 其他字段

- `difficulty_for_annotator`: `easy` / `medium` / `hard`。
- `time_minutes`: 本 case 实际用时，填正数。
- `notes_zh`: 简短中文备注；`confidence=low`、`TIE + insufficient_context` 或选择任何 `other` 时必须填写。

## Compact examples / 简短例子

- 如果 Answer A 给出明确 baseline、ablation、failure slice 和 falsifier；Answer B 只说“combine methods and evaluate accuracy”，通常 A 胜，B 的弱点可能是 `generic_hypothesis` + `weak_decisive_metric`。
- 如果两者都可行，但一个更 novel、另一个更 feasible，且你无法稳定偏好，可选 `TIE`，`tie_reason=different_tradeoff`。
- 如果某答案没有按六字段作答且无法判断，考虑 `INVALID`。
