#!/usr/bin/env python3
"""Validate completed Lit2Test human-acceptance annotation CSVs.

The checker only validates form completeness and value domains. It does not
judge the substance of an annotation.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path
from typing import Any


TASK1_DIR = "task_01_neighborhood_quality"
TASK2_DIR = "task_02_human_calibration"

TASK1_REQUIRED = [
    "case_id",
    "batch",
    "context_id",
    "area",
    "paper_relatedness",
    "open_problem_grounding",
    "answerability",
    "outlier_paper_count",
    "overall_keep",
    "needs_full_text_to_judge",
    "confidence",
    "difficulty_for_annotator",
    "time_minutes",
]
TASK1_SCORE_FIELDS = ["paper_relatedness", "open_problem_grounding", "answerability"]
TASK1_KEEP_VALUES = {"keep", "revise", "drop"}
TASK1_FULL_TEXT_VALUES = {"no", "maybe", "yes"}
CONFIDENCE_VALUES = {"low", "medium", "high"}
DIFFICULTY_VALUES = {"easy", "medium", "hard"}

TASK2_SCORE_FIELDS = [
    "grounding_score_a",
    "grounding_score_b",
    "hypothesis_specificity_score_a",
    "hypothesis_specificity_score_b",
    "minimality_feasibility_score_a",
    "minimality_feasibility_score_b",
    "decisive_metric_score_a",
    "decisive_metric_score_b",
    "falsifiability_score_a",
    "falsifiability_score_b",
]
TASK2_REQUIRED = [
    "case_id",
    "context_id",
    "batch",
    "pair_display_id",
    "winner",
    "confidence",
    "difficulty_for_annotator",
    "time_minutes",
]
WINNER_VALUES = {"A", "B", "TIE", "INVALID"}
TIE_VALUES = {"too_close", "both_good", "both_bad", "different_tradeoff", "insufficient_context", "other"}
INVALID_VALUES = {"missing_answer", "not_about_task", "unreadable", "unsafe_or_irrelevant", "other"}
WEAKNESS_VALUES = {
    "weak_grounding",
    "generic_hypothesis",
    "overbroad_or_infeasible",
    "missing_baseline_or_control",
    "weak_decisive_metric",
    "no_real_falsification",
    "misread_task_or_invalid",
    "unclear_writing",
    "other",
}


def is_blank(value: Any) -> bool:
    return value is None or str(value).strip() == ""


def read_csv(path: Path) -> tuple[list[dict[str, str]], list[str]]:
    raw = path.read_bytes()
    last_error: UnicodeDecodeError | None = None
    text = ""
    for encoding in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError as exc:
            last_error = exc
    else:
        raise ValueError(f"cannot decode {path}: {last_error}")
    reader = csv.DictReader(text.splitlines())
    if reader.fieldnames is None:
        raise ValueError(f"{path} has no CSV header")
    return list(reader), list(reader.fieldnames)


def parse_int(value: Any) -> int | None:
    if is_blank(value):
        return None
    text = str(value).strip()
    if not re.fullmatch(r"[+-]?\d+", text):
        return None
    return int(text)


def parse_positive_number(value: Any) -> float | None:
    if is_blank(value):
        return None
    try:
        number = float(str(value).strip())
    except ValueError:
        return None
    return number if number > 0 else None


def add_error(errors: list[str], task: str, row_number: int | None, field: str, message: str) -> None:
    location = task if row_number is None else f"{task} row {row_number}"
    errors.append(f"{location} [{field}]: {message}")


def check_headers(headers: list[str], required: list[str], task: str, errors: list[str]) -> None:
    missing = [field for field in required if field not in headers]
    if missing:
        add_error(errors, task, None, "header", "missing columns: " + ", ".join(missing))


def validate_task1(path: Path) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        rows, headers = read_csv(path)
    except Exception as exc:  # noqa: BLE001 - report a user-facing validation error.
        return {"task": "task1", "path": str(path), "rows": 0, "errors": [str(exc)], "warnings": warnings}

    check_headers(headers, TASK1_REQUIRED, "task1", errors)
    if not rows:
        add_error(errors, "task1", None, "rows", "annotation.csv has no data rows")
    seen: set[str] = set()
    for row_number, row in enumerate(rows, 2):
        case_id = str(row.get("case_id", "")).strip()
        if is_blank(case_id):
            add_error(errors, "task1", row_number, "case_id", "required")
        elif case_id in seen:
            add_error(errors, "task1", row_number, "case_id", f"duplicate case_id {case_id}")
        seen.add(case_id)

        for field in TASK1_REQUIRED:
            if field != "case_id" and is_blank(row.get(field)):
                add_error(errors, "task1", row_number, field, "required")

        for field in TASK1_SCORE_FIELDS:
            if is_blank(row.get(field)):
                continue
            value = parse_int(row.get(field))
            if value is None or value not in {0, 1, 2}:
                add_error(errors, "task1", row_number, field, "must be an integer in 0..2")

        outlier_count = parse_int(row.get("outlier_paper_count"))
        if outlier_count is None or not 0 <= outlier_count <= 4:
            add_error(errors, "task1", row_number, "outlier_paper_count", "must be an integer in 0..4")
        raw_indices = str(row.get("outlier_paper_indices") or "").strip()
        indices: list[int] = []
        if raw_indices:
            parts = [part for part in re.split(r"[;,\s]+", raw_indices) if part]
            for part in parts:
                if not re.fullmatch(r"\d+", part):
                    add_error(errors, "task1", row_number, "outlier_paper_indices", "use paper indices such as 2 or 1;4")
                    continue
                index = int(part)
                if not 1 <= index <= 4:
                    add_error(errors, "task1", row_number, "outlier_paper_indices", "each index must be 1..4")
                indices.append(index)
            if len(indices) != len(set(indices)):
                add_error(errors, "task1", row_number, "outlier_paper_indices", "indices must be unique")
        if outlier_count is not None:
            if outlier_count == 0 and raw_indices:
                add_error(errors, "task1", row_number, "outlier_paper_indices", "must be blank when outlier_paper_count is 0")
            if outlier_count > 0 and not raw_indices:
                add_error(errors, "task1", row_number, "outlier_paper_indices", "required when outlier_paper_count is greater than 0")
            if raw_indices and len(set(indices)) != outlier_count:
                add_error(errors, "task1", row_number, "outlier_paper_indices", "number of indices must match outlier_paper_count")

        if not is_blank(row.get("overall_keep")) and str(row.get("overall_keep", "")).strip() not in TASK1_KEEP_VALUES:
            add_error(errors, "task1", row_number, "overall_keep", "must be keep, revise, or drop")
        if not is_blank(row.get("needs_full_text_to_judge")) and str(row.get("needs_full_text_to_judge", "")).strip() not in TASK1_FULL_TEXT_VALUES:
            add_error(errors, "task1", row_number, "needs_full_text_to_judge", "must be no, maybe, or yes")
        if not is_blank(row.get("confidence")) and str(row.get("confidence", "")).strip() not in CONFIDENCE_VALUES:
            add_error(errors, "task1", row_number, "confidence", "must be low, medium, or high")
        if not is_blank(row.get("difficulty_for_annotator")) and str(row.get("difficulty_for_annotator", "")).strip() not in DIFFICULTY_VALUES:
            add_error(errors, "task1", row_number, "difficulty_for_annotator", "must be easy, medium, or hard")
        if parse_positive_number(row.get("time_minutes")) is None:
            add_error(errors, "task1", row_number, "time_minutes", "required and must be a positive number")
        if (
            str(row.get("confidence", "")).strip() == "low"
            or str(row.get("needs_full_text_to_judge", "")).strip() != "no"
            or str(row.get("overall_keep", "")).strip() != "keep"
        ) and is_blank(row.get("notes_zh")):
            add_error(errors, "task1", row_number, "notes_zh", "required when confidence is low, source material is insufficient, or overall_keep is not keep")

    return {"task": "task1", "path": str(path), "rows": len(rows), "errors": errors, "warnings": warnings}


def validate_task2(path: Path) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        rows, headers = read_csv(path)
    except Exception as exc:  # noqa: BLE001 - report a user-facing validation error.
        return {"task": "task2", "path": str(path), "rows": 0, "errors": [str(exc)], "warnings": warnings}

    check_headers(headers, TASK2_REQUIRED, "task2", errors)
    if not rows:
        add_error(errors, "task2", None, "rows", "annotation.csv has no data rows")
    seen: set[str] = set()
    for row_number, row in enumerate(rows, 2):
        case_id = str(row.get("case_id", "")).strip()
        if is_blank(case_id):
            add_error(errors, "task2", row_number, "case_id", "required")
        elif case_id in seen:
            add_error(errors, "task2", row_number, "case_id", f"duplicate case_id {case_id}")
        seen.add(case_id)

        for field in TASK2_REQUIRED:
            if field != "case_id" and is_blank(row.get(field)):
                add_error(errors, "task2", row_number, field, "required")

        winner = str(row.get("winner", "")).strip()
        if winner and winner not in WINNER_VALUES:
            add_error(errors, "task2", row_number, "winner", "must be A, B, TIE, or INVALID")

        for field in TASK2_SCORE_FIELDS:
            if is_blank(row.get(field)) and winner == "INVALID":
                continue
            if is_blank(row.get(field)):
                add_error(errors, "task2", row_number, field, "required unless winner is INVALID")
                continue
            value = parse_int(row.get(field))
            if value is None or value not in {1, 2, 3}:
                add_error(errors, "task2", row_number, field, "must be an integer in 1..3")

        if not is_blank(row.get("confidence")) and str(row.get("confidence", "")).strip() not in CONFIDENCE_VALUES:
            add_error(errors, "task2", row_number, "confidence", "must be low, medium, or high")
        if not is_blank(row.get("difficulty_for_annotator")) and str(row.get("difficulty_for_annotator", "")).strip() not in DIFFICULTY_VALUES:
            add_error(errors, "task2", row_number, "difficulty_for_annotator", "must be easy, medium, or hard")
        if parse_positive_number(row.get("time_minutes")) is None:
            add_error(errors, "task2", row_number, "time_minutes", "required and must be a positive number")

        tie_reason = str(row.get("tie_reason") or "").strip()
        invalid_reason = str(row.get("invalid_reason") or "").strip()
        primary = str(row.get("loser_primary_weakness") or "").strip()
        secondary = str(row.get("loser_secondary_weakness") or "").strip()
        if winner == "TIE":
            if tie_reason not in TIE_VALUES:
                add_error(errors, "task2", row_number, "tie_reason", "required and must use the listed TIE reason")
            if invalid_reason:
                add_error(errors, "task2", row_number, "invalid_reason", "must be blank when winner is TIE")
            if primary or secondary:
                add_error(errors, "task2", row_number, "loser_*_weakness", "must be blank when winner is TIE")
        elif winner == "INVALID":
            if invalid_reason not in INVALID_VALUES:
                add_error(errors, "task2", row_number, "invalid_reason", "required and must use the listed INVALID reason")
            if tie_reason:
                add_error(errors, "task2", row_number, "tie_reason", "must be blank when winner is INVALID")
            if primary or secondary:
                add_error(errors, "task2", row_number, "loser_*_weakness", "must be blank when winner is INVALID")
        elif winner in {"A", "B"}:
            if tie_reason:
                add_error(errors, "task2", row_number, "tie_reason", "must be blank when winner is A or B")
            if invalid_reason:
                add_error(errors, "task2", row_number, "invalid_reason", "must be blank when winner is A or B")
            if primary not in WEAKNESS_VALUES:
                add_error(errors, "task2", row_number, "loser_primary_weakness", "required and must use the listed weakness")
            if secondary and secondary not in WEAKNESS_VALUES:
                add_error(errors, "task2", row_number, "loser_secondary_weakness", "must use the listed weakness")

        if winner == "TIE" and tie_reason == "insufficient_context" and is_blank(row.get("notes_zh")):
            add_error(errors, "task2", row_number, "notes_zh", "required for TIE + insufficient_context")
        if str(row.get("confidence", "")).strip() == "low" and is_blank(row.get("notes_zh")):
            add_error(errors, "task2", row_number, "notes_zh", "required when confidence is low")

        if tie_reason == "other" and is_blank(row.get("notes_zh")):
            add_error(errors, "task2", row_number, "notes_zh", "required when tie_reason is other")
        if invalid_reason == "other" and is_blank(row.get("notes_zh")):
            add_error(errors, "task2", row_number, "notes_zh", "required when invalid_reason is other")
        if primary == "other" and is_blank(row.get("notes_zh")):
            add_error(errors, "task2", row_number, "notes_zh", "required when loser_primary_weakness is other")
        if secondary == "other" and is_blank(row.get("notes_zh")):
            add_error(errors, "task2", row_number, "notes_zh", "required when loser_secondary_weakness is other")

    return {"task": "task2", "path": str(path), "rows": len(rows), "errors": errors, "warnings": warnings}


def default_package_dir() -> Path | None:
    here = Path(__file__).resolve().parent
    if (here / TASK1_DIR).is_dir() and (here / TASK2_DIR).is_dir():
        return here
    cwd = Path.cwd()
    if (cwd / TASK1_DIR).is_dir() and (cwd / TASK2_DIR).is_dir():
        return cwd
    return None


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Check completed Lit2Test human-acceptance annotation.csv files. This checks form validity only."
    )
    parser.add_argument(
        "--package-dir",
        type=Path,
        default=None,
        help="package root containing task_01_neighborhood_quality/ and task_02_human_calibration/ (default: current package directory)",
    )
    parser.add_argument("--task1-csv", type=Path, help="validate a Task 1 CSV directly")
    parser.add_argument("--task2-csv", type=Path, help="validate a Task 2 CSV directly")
    parser.add_argument("--json", action="store_true", help="print machine-readable JSON instead of the short report")
    args = parser.parse_args()

    if bool(args.task1_csv) != bool(args.task2_csv):
        parser.error("--task1-csv and --task2-csv must be provided together")

    package_dir = (args.package_dir or default_package_dir())
    if args.task1_csv and args.task2_csv:
        task1_path = args.task1_csv.expanduser().resolve()
        task2_path = args.task2_csv.expanduser().resolve()
        package_dir = task1_path.parent.parent
    elif package_dir is None:
        parser.error("cannot find package root; run this from the package directory or pass --package-dir PATH")
    else:
        package_dir = package_dir.resolve()
        task1_path = package_dir / TASK1_DIR / "annotation.csv"
        task2_path = package_dir / TASK2_DIR / "annotation.csv"
    reports = [validate_task1(task1_path), validate_task2(task2_path)]
    errors = [error for report in reports for error in report["errors"]]
    warnings = [warning for report in reports for warning in report["warnings"]]
    result = {
        "status": "pass" if not errors else "fail",
        "package_dir": str(package_dir),
        "reports": reports,
        "error_count": len(errors),
        "warning_count": len(warnings),
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Package: {package_dir}")
        for report in reports:
            status = "PASS" if not report["errors"] else "FAIL"
            print(f"{status} {report['task']}: {report['rows']} data rows, {len(report['errors'])} errors, {len(report['warnings'])} warnings")
            for message in report["errors"]:
                print(f"  ERROR: {message}")
            for message in report["warnings"]:
                print(f"  WARNING: {message}")
        print("RESULT:", "PASS" if not errors else "FAIL")
        if errors:
            print("请先修复所有 ERROR，再重新运行本命令。")
        elif warnings:
            print("表格格式通过；请在提交前人工查看 WARNING。")
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
