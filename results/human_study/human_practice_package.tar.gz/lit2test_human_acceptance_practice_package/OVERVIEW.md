# Lit2Test Human Acceptance Package — 练习包 / Practice package

英文原文为准，中文翻译仅供参考。如果英文和中文不一致，请按英文原文判断。

Lit2Test 评估的是：模型是否能基于近期真实论文邻域，提出 grounded、feasible、falsifiable 的最小下一步研究实验。请不要使用外部搜索；所有判断只基于包内给出的摘要级材料和答案文本。

## Workflow / 工作流

1. 先阅读本 `OVERVIEW.md`。
2. 对每个 subtask，阅读该文件夹内的 `README.md`。
3. 在 `reading.md` 中阅读 case 材料。
4. 在同一文件夹的 `annotation.csv` 中填写结构化判断。
5. CSV 不包含审稿人身份；回收后会在文件名层面区分 reviewer。

## Subtasks / 子任务

| Subtask | What to do | Cases | Expected time per case | Hard cap per case | Expected total |
|---|---|---:|---:|---:|---:|
| `task_01_neighborhood_quality` | Judge whether a 4-paper abstract-level neighborhood is coherent, grounded, and answerable. | 3 | 5-8 min | 10 min | 20-35 min + feedback |
| `task_02_human_calibration` | Compare Answer A vs Answer B, choose winner/tie/invalid, score dimensions, and select weakness labels. | 5 | about 5 min | 10 min | target <=45 min + feedback |

如果单个 case 达到 hard cap 仍不确定，不要继续深挖。请降低 `confidence`、必要时选 `TIE` 或 `INVALID`，并在 `notes_zh` 里写一句原因。

## Important boundaries / 判断边界

- `task_01` 只评价输入论文邻域质量；不评价模型答案，也不评价 Gemini judge。
- `task_02` 只评价两个匿名答案哪个更适合作为下一步研究实验；不要猜模型身份。
- 请不要打开全文。若必须看全文才敢判断，在相应字段标记不确定。
- 正式标注建议按 45-60 分钟为一个工作块，中间休息。
