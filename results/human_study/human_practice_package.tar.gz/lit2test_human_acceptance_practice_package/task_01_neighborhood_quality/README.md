# Task 01 — Abstract-level Neighborhood Quality Audit

英文原文为准，中文翻译仅供参考。请只基于给出的摘要级材料判断，不要打开全文。

## Goal / 目的

判断一个 4-paper neighborhood 是否足够 coherent、grounded、answerable，能否作为 Lit2Test 的研究构想输入。这里不评价模型输出，也不判断论文技术正确性。

## Fields to fill / 需要填写的字段

- `paper_relatedness`：4 篇论文是否围绕同一局部研究问题或技术张力。
  - `0`: 明显不相关，像随机拼接。
  - `1`: 有部分相关性，但至少一篇明显偏离或共同问题较松。
  - `2`: 明确相关，能看出共同主题、方法或失败模式。
- `open_problem_grounding`：open problem 是否由这些论文自然支撑。
  - `0`: open problem 看起来凭空提出，和论文摘要关系弱。
  - `1`: 有一定支撑，但依赖宽泛解释或只被部分论文支撑。
  - `2`: open problem 明显来自多篇论文的共同限制、张力或下一步。
- `answerability`：仅凭摘要级材料，是否能提出一个最小、可证伪的下一步实验。
  - `0`: 信息不足，难以提出具体实验。
  - `1`: 可以勉强提出，但需要较多外部知识或全文细节。
  - `2`: 可以基于材料提出具体、可执行、可证伪实验。
- `outlier_paper_count`：明显离群论文数量，填 `0`-`4`。
- `outlier_paper_indices`：若有离群论文，填 paper index，如 `2` 或 `1;4`；没有则留空。
- `overall_keep`：整体是否保留。
  - `keep`: 可直接作为 benchmark item。
  - `revise`: 有可修问题，如删换 1 篇论文或改 open problem。
  - `drop`: 整体不适合作为 item。
- `needs_full_text_to_judge`：是否必须看全文才能判断。
  - `no`: 摘要级材料足够。
  - `maybe`: 有些不确定，但仍可给出当前判断。
  - `yes`: 关键判断无法仅凭摘要完成。
- `confidence`: `low` / `medium` / `high`。
- `difficulty_for_annotator`: `easy` / `medium` / `hard`。
- `time_minutes`: 实际用时，数字即可。
- `notes_zh`: 简短中文备注。

## Compact examples / 简短例子

- 若四篇都围绕 long-context KV cache 压缩，但一篇只讲完全无关的视觉分类，可给 `paper_relatedness=1`，并把该论文标为 outlier。
- 若 open problem 明确要求“在固定显存下检验压缩是否保留 retrieval accuracy”，且摘要都讨论 memory/accuracy trade-off，可给 `open_problem_grounding=2`。
- 若材料只给很泛的“improve AI systems”，无法形成具体 baseline/metric/falsifier，可给 `answerability=0` 或 `1`。
