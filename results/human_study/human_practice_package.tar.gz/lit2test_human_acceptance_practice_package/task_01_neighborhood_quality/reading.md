# Task 01 Reading Materials

英文原文为准，中文翻译仅供参考。请不要打开全文。

## t1_practice_001

- Batch: `next40`
- Context ID: `smallari_next40_004_autoencoders_sparse_interpretability_find_saes__v02_next40`
- Area: `efficient inference and compression`
- Top terms: `autoencoders, sparse, interpretability, find, saes`
- Mean pairwise cosine: `0.1621`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh next40 neighborhood around efficient inference and compression: autoencoders, sparse, interpretability, find, saes. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文围绕高效推理与压缩（efficient inference and compression）构成了一个全新的 next40 邻域：autoencoders, sparse, interpretability, find, saes。该背景基于论文标题、摘要以及审稿人的局限性信号（reviewer limitation signals）。它测试模型是否能从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this next40 neighborhood around efficient inference and compression: autoencoders, sparse, interpretability, find, saes, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合了这一围绕高效推理与压缩的 next40 邻域：autoencoders, sparse, interpretability, find, saes，并针对所提供的评审意见和摘要中可见的局限性或评估缺口（evaluation gap）。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；最小化验证 <=8 A100 GPU-days；无专有模型权重；无未来论文的参考答案（answer keys）；包含一个来自所提供论文的基线（baseline），以及一个失败模式（failure-mode）或消融诊断（ablation diagnostic）。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的、可证伪的下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `k2ZVAzVeMP`
- URL: https://openreview.net/forum?id=k2ZVAzVeMP
- Title / 标题:
  - EN:
    > Efficient Dictionary Learning with Switch Sparse Autoencoders
  - ZH:
    > 使用 Switch 稀疏自编码器进行高效字典学习
- Abstract / 摘要:
  - EN:
    > Sparse autoencoders (SAEs) are a recent technique for decomposing neural network activations into human-interpretable features. However, in order for SAEs to identify all features represented in frontier models, it will be necessary to scale them up to very high width, posing a computational challenge. In this work, we introduce Switch Sparse Autoencoders, a novel SAE architecture aimed at reducing the compute cost of training SAEs. Inspired by sparse mixture of experts models, Switch SAEs route activation vectors between smaller "expert" SAEs, enabling SAEs to efficiently scale to many more features. We present experiments comparing Switch SAEs with other SAE architectures, and find that Switch SAEs deliver a substantial Pareto improvement in the reconstruction vs. sparsity frontier for a given fixed training compute budget. We also study the geometry of features across experts, analyze features duplicated across experts, and verify that Switch SAE features are as interpretable as features found by other SAE architectures.
  - ZH:
    > 稀疏自编码器（Sparse autoencoders, SAEs）是近期一种将神经网络激活分解为人类可解释特征的技术。然而，为了使 SAEs 能够识别前沿模型中表示的所有特征，必须将它们扩展到非常高的宽度，这带来了计算挑战。在这项工作中，我们引入了 Switch 稀疏自编码器（Switch Sparse Autoencoders），这是一种旨在降低训练 SAEs 计算成本的新颖 SAE 架构。受稀疏混合专家模型（sparse mixture of experts models）的启发，Switch SAEs 在较小的“专家” SAEs 之间路由激活向量，使 SAEs 能够高效扩展到多得多的特征。我们展示了比较 Switch SAEs 与其他 SAE 架构的实验，并发现对于给定的固定训练计算预算，Switch SAEs 在重建与稀疏性前沿（reconstruction vs. sparsity frontier）上提供了实质性的帕累托改进（Pareto improvement）。我们还研究了跨专家的特征几何结构，分析了跨专家重复的特征，并验证了 Switch SAE 特征与通过其他 SAE 架构发现的特征一样具有可解释性。
- Key contribution / 关键贡献:
  - EN:
    > This paper introduces Switch sparse autoencoders for learning sparse representations of neural network activations.
  - ZH:
    > 本文引入了 Switch 稀疏自编码器，用于学习神经网络激活的稀疏表示（sparse representations）。
- Limitation / 局限:
  - EN:
    > The idea maybe can be considered as a little bit incremental, but given the very good execution of the paper I don't think that's a big problem.
  - ZH:
    > 这个想法也许可以被认为是有一点渐进式的（incremental），但考虑到论文非常出色的执行情况，我不认为这是一个大问题。
- Important result / 重要结果:
  - EN:
    > We present experiments comparing Switch SAEs with other SAE architectures, and find that Switch SAEs deliver a substantial Pareto improvement in the reconstruction vs.
  - ZH:
    > 我们展示了比较 Switch SAEs 与其他 SAE 架构的实验，并发现 Switch SAEs 在重建与 (reconstruction vs.) 中提供了实质性的帕累托改进。

#### Paper 2

- Paper ID: `1Njl73JKjB`
- URL: https://openreview.net/forum?id=1Njl73JKjB
- Title / 标题:
  - EN:
    > Towards Principled Evaluations of Sparse Autoencoders for Interpretability and Control
  - ZH:
    > 迈向针对可解释性 (Interpretability) 和控制的稀疏自编码器 (Sparse Autoencoders) 的原则性评估
- Abstract / 摘要:
  - EN:
    > Disentangling model activations into human-interpretable features is a central problem in interpretability. Sparse autoencoders (SAEs) have recently attracted much attention as a scalable unsupervised approach to this problem. However, our imprecise understanding of ground-truth features in realistic scenarios makes it difficult to measure the success of SAEs. To address this challenge, we propose to evaluate SAEs on specific tasks by comparing them to supervised feature dictionaries computed with knowledge of the concepts relevant to the task. Specifically, we suggest that it is possible to (1) compute supervised sparse feature dictionaries that disentangle model computations for a specific task; (2) use them to evaluate and contextualize the degree of disentanglement and control offered by SAE latents on this task. Importantly, we can do this in a way that is agnostic to whether the SAEs have learned the exact ground-truth features or a different but similarly useful representation. As a case study, we apply this framework to the indirect object identification (IOI) task using GPT-2 Small, with SAEs trained on either the IOI or OpenWebText datasets. We find that SAEs capture i...
  - ZH:
    > 将模型激活解耦 (Disentangling) 为人类可解释的特征是可解释性中的一个核心问题。稀疏自编码器 (Sparse autoencoders, SAEs) 作为解决此问题的一种可扩展的无监督方法，最近引起了广泛关注。然而，在现实场景中，我们对真实 (ground-truth) 特征的不精确理解使得很难衡量 SAEs 的成功。为了应对这一挑战，我们提出通过将特定任务上的 SAEs 与利用与任务相关的概念知识计算出的监督特征字典 (supervised feature dictionaries) 进行比较，来评估它们。具体而言，我们建议可以 (1) 计算监督稀疏特征字典，以解耦特定任务的模型计算；(2) 使用它们来评估和语境化 (contextualize) SAE 潜在变量 (latents) 在该任务上提供的解耦和控制的程度。重要的是，我们能以一种不可知 (agnostic) 的方式做到这一点，即不管 SAEs 是否学习到了精确的真实特征，还是一种不同但同样有用的表示。作为案例研究，我们将该框架应用于使用 GPT-2 Small 的间接宾语识别 (indirect object identification, IOI) 任务，其中 SAEs 在 IOI 或 OpenWebText 数据集上进行训练。我们发现 SAEs 捕获了 i...
- Key contribution / 关键贡献:
  - EN:
    > The authors propose a (principled) method allowing to create supervised dictionaries for space features, which allow for evaluating the degree of disentanglement of SAEs.
  - ZH:
    > 作者提出了一种（原则性的）方法，允许为空间特征 (space features) 创建监督字典，从而允许评估 SAEs 的解耦程度。
- Limitation / 局限:
  - EN:
    > Though this has most probably costed a lot of work, the empirical validation of the proposed methodology is rather scarce.
  - ZH:
    > 尽管这很可能花费了大量工作，但所提出方法的经验验证 (empirical validation) 相当匮乏。
- Important result / 重要结果:
  - EN:
    > We find that SAEs capture interpretable features for the IOI task, and that more recent SAE variants such as Gated SAEs and Top-K SAEs are competitive with supervised features in terms of disentanglement and control over the model.
  - ZH:
    > 我们发现 SAEs 为 IOI 任务捕获了可解释的特征，并且更近期的 SAE 变体（如 Gated SAEs 和 Top-K SAEs）在解耦和对模型的控制方面与监督特征具有竞争力。

#### Paper 3

- Paper ID: `NB8qn8iIW9`
- URL: https://openreview.net/forum?id=NB8qn8iIW9
- Title / 标题:
  - EN:
    > Enhancing Neural Network Interpretability with Feature-Aligned Sparse Autoencoders
  - ZH:
    > 使用特征对齐的稀疏自编码器增强神经网络可解释性
- Abstract / 摘要:
  - EN:
    > Sparse Autoencoders (SAEs) have shown promise in improving the interpretability of neural network activations, but can learn features that are not features of the input, limiting their effectiveness. We propose Mutual Feature Regularization (MFR), a regularization technique for improving feature learning by encouraging SAEs trained in parallel to learn similar features. We motivate MFR by showing that features learned by multiple SAEs are more likely to correlate with features of the input. By training on synthetic data with known features of the input, we show that MFR can help SAEs learn those features, as we can directly compare the features learned by the SAE with the input features for the synthetic data. We then scale MFR to SAEs that are trained to denoise electroencephalography (EEG) data and SAEs that are trained to reconstruct GPT-2 Small activations. We show that MFR can improve the reconstruction loss of SAEs by up to 21.21\% on GPT-2 Small, and 6.67\% on EEG data. Our results suggest that the similarity between features learned by different SAEs can be leveraged to improve SAE training, thereby enhancing performance and the usefulness of SAEs for model interpretabil...
  - ZH:
    > 稀疏自编码器 (Sparse Autoencoders, SAEs) 在改善神经网络激活的可解释性方面展现出了前景，但可能学到并非输入特征的特征，从而限制了它们的有效性。我们提出了互特征正则化 (Mutual Feature Regularization, MFR)，这是一种通过鼓励并行训练的SAEs学习相似特征来改善特征学习的正则化技术。我们通过展示由多个SAEs学到的特征更可能与输入的特征相关，来作为MFR的动机。通过在具有已知输入特征的合成数据上进行训练，我们展示了MFR能够帮助SAEs学习这些特征，因为我们可以直接将SAE学到的特征与合成数据的输入特征进行比较。然后我们将MFR扩展到被训练用于对脑电图 (electroencephalography, EEG) 数据进行去噪的SAEs，以及被训练用于重建GPT-2 Small激活的SAEs。我们展示了MFR可以在GPT-2 Small上将SAEs的重建损失改善高达21.21\%，在EEG数据上改善6.67\%。我们的结果表明，可以利用不同SAEs学到的特征之间的相似性来改善SAE的训练，从而增强性能以及SAEs对于模型可解释...的有用性。
- Key contribution / 关键贡献:
  - EN:
    > The manuscript introduces Mutual Feature Regularization (MFR), a technique to improve Sparse Autoencoder training by encouraging multiple SAEs trained in parallel to learn similar features.
  - ZH:
    > 该手稿引入了互特征正则化 (Mutual Feature Regularization, MFR)，这是一种通过鼓励并行训练的多个SAEs学习相似特征来改善稀疏自编码器 (Sparse Autoencoder) 训练的技术。
- Limitation / 局限:
  - EN:
    > Tables 1, 2, and 3 do not report variability across folds or multiple runs.
  - ZH:
    > 表1、2和3没有报告跨折 (folds) 或多次运行的变异性。
- Important result / 重要结果:
  - EN:
    > Sparse Autoencoders (SAEs) have shown promise in improving the interpretability of neural network activations, but can learn features that are not features of the input, limiting their effectiveness.
  - ZH:
    > 稀疏自编码器 (Sparse Autoencoders, SAEs) 在改善神经网络激活的可解释性方面展现出了前景，但可能学到并非输入特征的特征，从而限制了它们的有效性。

#### Paper 4

- Paper ID: `9ca9eHNrdH`
- URL: https://openreview.net/forum?id=9ca9eHNrdH
- Title / 标题:
  - EN:
    > Sparse Autoencoders Do Not Find Canonical Units of Analysis
  - ZH:
    > 稀疏自编码器 (Sparse Autoencoders) 未找到规范的分析单元
- Abstract / 摘要:
  - EN:
    > A common goal of mechanistic interpretability is to decompose the activations of neural networks into features: interpretable properties of the input computed by the model. Sparse autoencoders (SAEs) are a popular method for finding these features in LLMs, and it has been postulated that they can be used to find a canonical set of units: a unique and complete list of atomic features. We cast doubt on this belief using two novel techniques: SAE stitching to show they are incomplete, and meta-SAEs to show they are not atomic. SAE stitching involves inserting or swapping latents from a larger SAE into a smaller one. Latents from the larger SAE can be divided into two categories: novel latents, which improve performance when added to the smaller SAE, indicating they capture novel information, and reconstruction latents, which can replace corresponding latents in the smaller SAE that have similar behavior. The existence of novel features indicates incompleteness of smaller SAEs. Using meta-SAEs - SAEs trained on the decoder matrix of another SAE - we find that latents in SAEs often decompose into combinations of latents from a smaller SAE, showing that larger SAE latents are not atom...
  - ZH:
    > 机制可解释性 (mechanistic interpretability) 的一个共同目标是将神经网络的激活分解为特征：由模型计算的输入的可解释属性。稀疏自编码器 (Sparse autoencoders, SAEs) 是在 LLMs 中寻找这些特征的一种流行方法，并且有人假设它们可用于找到一组规范的单元：唯一且完整的原子特征列表。我们使用两种新技术对这一信念提出质疑：SAE 拼接 (SAE stitching) 以显示它们是不完整的，以及元 SAE (meta-SAEs) 以显示它们不是原子的。SAE 拼接涉及将较大 SAE 中的潜在变量 (latents) 插入或交换到较小 SAE 中。来自较大 SAE 的潜在变量可分为两类：新颖潜在变量 (novel latents)，当添加到较小 SAE 时能提高性能，表明它们捕获了新颖信息；以及重建潜在变量 (reconstruction latents)，可以替换较小 SAE 中具有相似行为的相应潜在变量。新颖特征的存在表明较小 SAE 的不完整性。使用元 SAE——在另一个 SAE 的解码器矩阵上训练的 SAE——我们发现 SAE 中的潜在变量通常分解为来自较小 SAE 的潜在变量的组合，表明较大 SAE 的潜在变量不是原... (not atom...)
- Key contribution / 关键贡献:
  - EN:
    > This paper wrestles with the question of whether sparse autoencoders (SAEs) of different sizes learn the same set of "canonical" or "atomic" units.
  - ZH:
    > 本文探讨了不同大小的稀疏自编码器 (sparse autoencoders, SAEs) 是否学习同一组“规范的” (canonical) 或“原子的” (atomic) 单元的问题。
- Limitation / 局限:
  - EN:
    > I could not find reported values of the reconstruction loss that meta-SAEs obtain in reconstructing the base 49k-latent SAE latents.
  - ZH:
    > 我未能找到元 SAE (meta-SAEs) 在重建基础 49k-latent SAE 潜在变量时所获得的重建损失 (reconstruction loss) 的报告值。
- Important result / 重要结果:
  - EN:
    > Sparse autoencoders (SAEs) are a popular method for finding these features in LLMs, and it has been postulated that they can be used to find a canonical set of units: a unique and complete list of atomic features.
  - ZH:
    > 稀疏自编码器 (Sparse autoencoders, SAEs) 是在 LLMs 中寻找这些特征的一种流行方法，并且有人假设它们可用于找到一组规范的单元：唯一且完整的原子特征列表。

## t1_practice_002

- Batch: `fifth40`
- Context ID: `smallari_fifth40_018_policy_offline_behavior_reinforcement_diffusion__v02_fifth40`
- Area: `reinforcement learning and agents`
- Top terms: `policy, offline, behavior, reinforcement, diffusion`
- Mean pairwise cosine: `0.0792`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh fifth40 neighborhood around reinforcement learning and agents: policy, offline, behavior, reinforcement, diffusion. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的 ICLR OpenReview 论文在强化学习（reinforcement learning）和智能体（agents）周围形成了一个新鲜的 fifth40 邻域：策略（policy）、离线（offline）、行为（behavior）、强化（reinforcement）、扩散（diffusion）。该背景基于论文标题、摘要和审稿人的局限性信号。它测试模型是否能从一个紧密的本地文献簇中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this fifth40 neighborhood around reinforcement learning and agents: policy, offline, behavior, reinforcement, diffusion, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合这个围绕强化学习和智能体的 fifth40 邻域：策略、离线、行为、强化、扩散，并针对提供的评论和摘要中可见的局限性或评估差距。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；最小验证需 <=8 A100 GPU-days；无专有模型权重；无未来论文的答案键（answer keys）；包括一个来自所提供论文的基线（baseline）以及一个故障模式（failure-mode）或消融（ablation）诊断。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 制定一个最小的可证伪的下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `gEdg9JvO8X`
- URL: https://openreview.net/forum?id=gEdg9JvO8X
- Title / 标题:
  - EN:
    > BDQL: Offline RL via Behavior Diffusion Q-learning without Policy Constraint
  - ZH:
    > BDQL：通过无策略约束的行为扩散Q学习（Behavior Diffusion Q-learning）实现的离线RL
- Abstract / 摘要:
  - EN:
    > Offline reinforcement learning (RL) algorithms often constrain the policy or regularize the value function within an off-policy actor-critic framework to overcome the overestimation on out-of-distribution (OOD) actions. And the on-policy style offline algorithms also cannot escape from these constraints (or regularization). In this paper, we propose an on-policy style algorithm, Behavior Diffusion Q-Learning (BDQL), which has the potential to solve offline RL without introducing any potential constraints. BDQL first recovers the behavior policy through the diffusion model and then updates this diffusion-based behavior policy using the behavior Q-function learned by SARSA. The update of BDQL exhibits a special two-stage pattern. At the beginning of the training, thanks to the precise modeling of the diffusion model, the on-policy guidance of the behavior Q-function over the behavior policy is effective enough to solve the offline RL. As training processes, BDQL suffers from the OOD issue, causing the training fluctuation or even collapse. Consequently, OOD issue arises after BDQL solves the offline problem which means the policy constraint is not necessary for solving offline RL...
  - ZH:
    > 离线强化学习（Offline reinforcement learning, RL）算法通常在离策略演员-评论家（off-policy actor-critic）框架内约束策略或正则化值函数，以克服对分布外（out-of-distribution, OOD）动作的高估。而同策略（on-policy）风格的离线算法也无法摆脱这些约束（或正则化）。在本文中，我们提出了一种同策略风格的算法——行为扩散Q学习（Behavior Diffusion Q-Learning, BDQL），它有潜力在不引入任何潜在约束的情况下解决离线RL。BDQL首先通过扩散模型（diffusion model）恢复行为策略（behavior policy），然后使用由SARSA学习到的行为Q函数（behavior Q-function）更新这个基于扩散的行为策略。BDQL的更新展现出一种特殊的两阶段模式。在训练开始时，得益于扩散模型的精确建模，行为Q函数对行为策略的同策略引导足够有效，能够解决离线RL。随着训练的进行，BDQL会遭受OOD问题的影响，导致训练波动甚至崩溃。因此，OOD问题是在BDQL解决离线问题之后出现的，这意味着策略约束对于解决离线RL并不是必需的...
- Key contribution / 关键贡献:
  - EN:
    > The current paper introduces a new offline RL algorithm using diffusion models for policy, named BDQL.
  - ZH:
    > 当前论文介绍了一种将扩散模型用于策略的新的离线RL算法，名为BDQL。
- Limitation / 局限:
  - EN:
    > The significance of section 2.2 is unclear, since both methods are not used in the current paper.
  - ZH:
    > 第2.2节的意义不明确，因为这两种方法在当前论文中均未使用。
- Important result / 重要结果:
  - EN:
    > Experiments on D4RL demonstrate the special two-stage training phenomenon, where the first stage does have the capability to solve offline RL.
  - ZH:
    > 在D4RL上的实验证明了特殊的两阶段训练现象，其中第一阶段确实具有解决离线RL的能力。

#### Paper 2

- Paper ID: `enUArz7TeR`
- URL: https://openreview.net/forum?id=enUArz7TeR
- Title / 标题:
  - EN:
    > Decoupled Prioritized Resampling: Advancing Offline RL with Improved Behavior Policy
  - ZH:
    > 解耦优先级重采样：通过改进的行为策略推进离线强化学习
- Abstract / 摘要:
  - EN:
    > Offline reinforcement learning (RL) is challenged by the distributional shift problem. To tackle this issue, existing works mainly focus on designing sophisticated policy constraints between the learned policy and the behavior policy. However, these constraints are applied equally to well-performing and inferior actions through uniform sampling, which might negatively affect the learned policy. In this paper, we proposeOffline Decoupled Prioritized Resampling (ODPR), which designs specialized priority functions for the suboptimal policy constraint issue in offline RL, and employs unique decoupled resampling for training stability. Through theoretical analysis, we show that the distinctive priority functions induces a provable improved behavior policy by modifying the distribution of the original behavior policy, and when constrained to this improved policy, a policy-constrained offline RL algorithm is likely to yield a better solution. We provide two practical implementations to balance computation and performance: one estimates priorities based on a fitted value network (ODPR-A), and the other utilizes trajectory returns (ODPR-R) for quick computation. ODPR serves as a highly c...
  - ZH:
    > 离线强化学习 (RL) 面临分布偏移 (distributional shift) 问题的挑战。为了解决这个问题，现有的工作主要集中在学习策略与行为策略之间设计复杂的策略约束上。然而，这些约束通过均匀采样被同等地应用于表现良好和较差的动作，这可能对学习策略产生负面影响。在本文中，我们提出了离线解耦优先级重采样 (Offline Decoupled Prioritized Resampling, ODPR)，它为离线RL中次优的策略约束问题设计了专门的优先级函数，并采用了独特的解耦重采样以保障训练稳定性。通过理论分析，我们表明，独特的优先级函数通过修改原始行为策略的分布，引发了一个可证明改进的行为策略，并且当受限于这个改进的策略时，带有策略约束的离线RL算法很可能会产生更好的解。我们提供了两种实用的实现来平衡计算和性能：一种基于拟合的价值网络来估计优先级 (ODPR-A)，另一种利用轨迹回报 (ODPR-R) 进行快速计算。ODPR作为一个高度c...
- Key contribution / 关键贡献:
  - EN:
    > This study introduces a sampling strategy that assigns priority to certain actions to enhance the efficacy of offline reinforcement learning algorithms with constraints.
  - ZH:
    > 本研究引入了一种为某些动作分配优先级的采样策略，以增强带有约束的离线强化学习算法的功效。
- Limitation / 局限:
  - EN:
    > Unclear significance:** To strengthen the significance, I suggest the author thinks of experiments answering the question: would the additional complexity (i.e., learning the advantage function, weighting samples) lead to proportional performance gain?
  - ZH:
    > 显著性不明确:** 为了增强显著性，我建议作者考虑回答以下问题的实验：增加的复杂性（即，学习优势函数、加权样本）是否会带来成比例的性能提升？
- Important result / 重要结果:
  - EN:
    > Through theoretical analysis, we show that the distinctive priority functions induces a provable improved behavior policy by modifying the distribution of the original behavior policy, and when constrained to this improved policy, a policy-constrained offline RL algorithm is likely to yield a better solution.
  - ZH:
    > 通过理论分析，我们表明，独特的优先级函数通过修改原始行为策略的分布，引发了一个可证明改进的行为策略，并且当受限于这个改进的策略时，带有策略约束的离线强化学习算法很可能会产生更好的解决方案。

#### Paper 3

- Paper ID: `RMgqvQGTwH`
- URL: https://openreview.net/forum?id=RMgqvQGTwH
- Title / 标题:
  - EN:
    > Offline Data Enhanced On-Policy Policy Gradient with Provable Guarantees
  - ZH:
    > 具有可证明保证的离线数据增强同策略 (On-Policy) 策略梯度
- Abstract / 摘要:
  - EN:
    > Hybrid RL is the setting where an RL agent has access to both offline data and online data by interacting with the real-world environment. In this work, we propose a new hybrid RL algorithm that combines an on-policy actor-critic method with offline data. On-policy methods such as policy gradient and natural policy gradient (NPG) have shown to be more robust to model misspecification, though sometimes it may not be as sample efficient as methods that rely on off-policy learning. On the other hand, offline methods that depend on off-policy training often require strong assumptions in theory and are less stable to train in practice. Our new approach integrates a procedure of off-policy training on the offline data into an on-policy NPG framework. We show that our approach, in theory, can obtain a *best-of-both-worlds* type of result --- it achieves the state-of-art theoretical guarantees of offline RL when offline RL-specific assumptions hold, while at the same time maintaining the theoretical guarantees of on-policy NPG regardless of the offline RL assumptions' validity. Experimentally, in challenging rich-observation environments, we show that our approach outperforms a state-of...
  - ZH:
    > 混合强化学习 (Hybrid RL) 是一种设定，其中 RL 智能体通过与现实世界环境交互，可以同时访问离线数据和在线数据。在这项工作中，我们提出了一种新的混合 RL 算法，将同策略演员-评论家 (on-policy actor-critic) 方法与离线数据相结合。同策略方法（如策略梯度和自然策略梯度 (NPG)）已显示出对模型设定错误 (model misspecification) 具有更强的鲁棒性，尽管有时其样本效率可能不如依赖异策略 (off-policy) 学习的方法。另一方面，依赖异策略训练的离线方法通常在理论上需要很强的假设，并且在实践中训练不够稳定。我们的新方法将离线数据上的异策略训练过程集成到同策略 NPG 框架中。我们表明，我们的方法在理论上可以获得一种 *两全其美* (best-of-both-worlds) 类型的结果——当特定于离线 RL 的假设成立时，它实现了离线 RL 最先进的理论保证，同时无论离线 RL 假设是否有效，都能保持同策略 NPG 的理论保证。在实验上，在具有挑战性的丰富观察环境中，我们表明我们的方法优于 state-of...
- Key contribution / 关键贡献:
  - EN:
    > This paper focuses on hybrid RL, where the agent has offline data and is able to interact with the environment simultaneously.
  - ZH:
    > 本文专注于混合 RL (hybrid RL)，其中智能体拥有离线数据并且能够同时与环境交互。
- Limitation / 局限:
  - EN:
    > I did not spot any particular major weakness in this paper.
  - ZH:
    > 我没有发现本文有任何特定的主要弱点。
- Important result / 重要结果:
  - EN:
    > On-policy methods such as policy gradient and natural policy gradient (NPG) have shown to be more robust to model misspecification, though sometimes it may not be as sample efficient as methods that rely on off-policy learning.
  - ZH:
    > 同策略 (On-policy) 方法（如策略梯度和自然策略梯度 (NPG)）已显示出对模型设定错误 (model misspecification) 具有更强的鲁棒性，尽管有时其样本效率可能不如依赖异策略 (off-policy) 学习的方法。

#### Paper 4

- Paper ID: `v8jdwkUNXb`
- URL: https://openreview.net/forum?id=v8jdwkUNXb
- Title / 标题:
  - EN:
    > Consistency Models as a Rich and Efficient Policy Class for Reinforcement Learning
  - ZH:
    > 一致性模型作为强化学习的一种丰富且高效的策略类
- Abstract / 摘要:
  - EN:
    > Score-based generative models like the diffusion model have been testified to be effective in modeling multi-modal data from image generation to reinforcement learning (RL). However, the inference process of diffusion model can be slow, which hinders its usage in RL with iterative sampling. We propose to apply the consistency model as an efficient yet expressive policy representation, namely consistency policy, with an actor-critic style algorithm for three typical RL settings: offline, offline-to-online and online. For offline RL, we demonstrate the expressiveness of generative models as policies from multi-modal data. For offline-to-online RL, the consistency policy is shown to be more computational efficient than diffusion policy, with a comparable performance. For online RL, the consistency policy demonstrates significant speedup and even higher average performances than the diffusion policy.
  - ZH:
    > 像扩散模型这样的基于分数的生成模型已被证明在从图像生成到强化学习 (RL) 的多模态数据建模中是有效的。然而，扩散模型的推理过程可能很慢，这阻碍了它在带有迭代采样的 RL 中的使用。我们提出应用一致性模型作为一种高效且富有表现力的策略表示，即一致性策略 (consistency policy)，采用 actor-critic 风格的算法用于三种典型的 RL 设置：离线、离线到在线和在线。对于离线 RL，我们从多模态数据中展示了生成模型作为策略的表现力。对于离线到在线 RL，一致性策略被证明比扩散策略具有更高的计算效率，且性能相当。对于在线 RL，一致性策略展示出显著的加速，甚至具有比扩散策略更高的平均性能。
- Key contribution / 关键贡献:
  - EN:
    > This paper proposes to use the recent "consistency models" as a way of parameterizing the policy for deep RL.
  - ZH:
    > 本文提出使用最近的"一致性模型"作为参数化深度 RL 策略的一种方式。
- Limitation / 局限:
  - EN:
    > The idea of using consistency models as RL policies is fairly intuitive and not terribly surprising.
  - ZH:
    > 使用一致性模型作为 RL 策略的想法相当直观，并不十分令人惊讶。
- Important result / 重要结果:
  - EN:
    > For offline RL, we demonstrate the expressiveness of generative models as policies from multi-modal data.
  - ZH:
    > 对于离线 RL，我们从多模态数据中展示了生成模型作为策略的表现力。

## t1_practice_003

- Batch: `next40`
- Context ID: `smallari_next40_039_adversarial_robustness_networks_perspective_adva__v02_next40`
- Area: `robustness, ood, and uncertainty`
- Top terms: `adversarial, robustness, networks, perspective, advancing`
- Mean pairwise cosine: `0.0434`

### Prompt / 任务输入

- Research context / 研究背景:
  - EN:
    > These public ICLR OpenReview papers form a fresh next40 neighborhood around robustness, ood, and uncertainty: adversarial, robustness, networks, perspective, advancing. The context is grounded in paper titles, abstracts, and reviewer limitation signals. It tests whether a model can propose a concrete next-step experiment from a tight local literature cluster.
  - ZH:
    > 这些公开的ICLR OpenReview论文围绕鲁棒性（robustness）、分布外（ood）和不确定性（uncertainty）形成了一个新的next40邻域（neighborhood）：adversarial, robustness, networks, perspective, advancing。该背景基于论文标题、摘要和审稿人的局限性信号。它测试模型是否能够从一个紧密的局部文献集群中提出一个具体的下一步实验。
- Open problem / 开放问题:
  - EN:
    > Propose one concrete next-step research test that synthesizes this next40 neighborhood around robustness, ood, and uncertainty: adversarial, robustness, networks, perspective, advancing, targeting a limitation or evaluation gap visible in the supplied reviews and abstracts.
  - ZH:
    > 提出一个具体的下一步研究测试，该测试综合这个围绕鲁棒性、分布外和不确定性的next40邻域：adversarial, robustness, networks, perspective, advancing，针对在提供的评论和摘要中可见的局限性或评估差距。
- Resource constraint / 资源约束:
  - EN:
    > Public datasets and open-weight models only; <=8 A100 GPU-days for a minimal validation; no proprietary model weights; no future-paper answer keys; include one baseline from a supplied paper and one failure-mode or ablation diagnostic.
  - ZH:
    > 仅限公开数据集和开放权重模型；最小验证（minimal validation）需<=8个A100 GPU-days；无专有模型权重；无未来论文答案键（answer keys）；包含一个来自所提供论文的基线（baseline），以及一个失效模式（failure-mode）或消融（ablation）诊断。
- Task instruction / 任务说明:
  - EN:
    > Formulate one minimal falsifiable next-step test, not a broad research proposal.
  - ZH:
    > 构思一个最小的可证伪的下一步测试，而不是一个宽泛的研究提案。

### Papers / 论文

#### Paper 1

- Paper ID: `dA4EWchlbn`
- URL: https://openreview.net/forum?id=dA4EWchlbn
- Title / 标题:
  - EN:
    > Advancing the Adversarial Robustness of Neural Networks from the Data Perspective
  - ZH:
    > 从数据视角推进神经网络的对抗鲁棒性
- Abstract / 摘要:
  - EN:
    > Robustness in machine learning is a widespread concept and one of the pillars of trustworthiness, ranging from a model's resistance to noise---benign and adversarial---to the reliability of benchmarking. In this work, we analyse the robustness of labelled data which we argue corresponds to the data manifold's curvature as perceived by a model during training and thus establish a connection to its adversarial robustness. This view provides an intuitive explanation for our empirical results showing that neural networks acquire adversarial robustness much slower in the least robust regions. In combination with minor adjustments to the learning rate, the new concept offers a means to emphasise these regions during training and increase the model's overall adversarial robustness, even when using identical computational resources.
  - ZH:
    > 机器学习中的鲁棒性 (robustness) 是一个广泛的概念，也是可信度 (trustworthiness) 的支柱之一，范围从模型对噪声——良性和对抗性的——抵抗力，到基准测试的可靠性。在这项工作中，我们分析了标注数据的鲁棒性，我们认为这对应于模型在训练期间感知到的数据流形 (data manifold) 的曲率，从而建立起与其对抗鲁棒性 (adversarial robustness) 的联系。这一观点为我们的实证结果提供了一个直观的解释，该结果显示神经网络在最不鲁棒的区域获得对抗鲁棒性的速度要慢得多。结合对学习率的微小调整，这个新概念提供了一种手段，在训练期间强调这些区域并增加模型的整体对抗鲁棒性，即使在使用相同的计算资源时也是如此。
- Key contribution / 关键贡献:
  - EN:
    > The paper is on adversarial robustness and proposes that models are particularly vulnerable in regions where the data manifold would be perceived as highly curved by the model.
  - ZH:
    > 该论文是关于对抗鲁棒性的，并提出模型在数据流形会被模型感知为高度弯曲的区域中特别脆弱。
- Limitation / 局限:
  - EN:
    > The paper and overall presentation is very difficult to follow.
  - ZH:
    > 该论文及整体呈现非常难以理解。
- Important result / 重要结果:
  - EN:
    > This view provides an intuitive explanation for our empirical results showing that neural networks acquire adversarial robustness much slower in the least robust regions.
  - ZH:
    > 这一观点为我们的实证结果提供了一个直观的解释，该结果显示神经网络在最不鲁棒的区域获得对抗鲁棒性的速度要慢得多。

#### Paper 2

- Paper ID: `2ErS9Bkc3O`
- URL: https://openreview.net/forum?id=2ErS9Bkc3O
- Title / 标题:
  - EN:
    > Towards unlocking the mystery of adversarial fragility of neural networks
  - ZH:
    > 迈向解开神经网络对抗脆弱性 (adversarial fragility) 之谜
- Abstract / 摘要:
  - EN:
    > In this paper, we study the adversarial robustness of deep neural networks for classification tasks. The adversarial robustness of a classification algorithm is defined as the smallest magnitude of possible additive perturbations that can change the output of the classification algorithm. We provide a matrix-theoretic explanation of the adversarial fragility of deep neural network. In particular, our theoretical results show that neural network's adversarial robustness can degrade as the input dimension $d$ increases. Analytically we show that neural networks' adversarial robustness can be only $1/\sqrt{d}$ of the best possible adversarial robustness. Our matrix-theoretic explanation is consistent with an earlier information-theoretic feature-compression-based explanation for the adversarial robustness of neural networks.
  - ZH:
    > 在本文中，我们研究了用于分类任务的深度神经网络的对抗鲁棒性 (adversarial robustness)。分类算法的对抗鲁棒性被定义为能够改变分类算法输出的可能加性扰动 (additive perturbations) 的最小幅度。我们提供了深度神经网络对抗脆弱性的矩阵理论解释。特别是，我们的理论结果表明，神经网络的对抗鲁棒性会随着输入维度 $d$ 的增加而下降。分析表明，神经网络的对抗鲁棒性可能仅为可能的最佳对抗鲁棒性的 $1/\sqrt{d}$。我们的矩阵理论解释与早期针对神经网络对抗鲁棒性的基于信息论特征压缩的解释相一致。
- Key contribution / 关键贡献:
  - EN:
    > The paper provides a theoretical analysis of adversarial robustness in several specific contexts.
  - ZH:
    > 该论文在几个特定背景下提供了对抗鲁棒性的理论分析。
- Limitation / 局限:
  - EN:
    > Lack of Related Research: The paper overlooks existing theoretical work on random networks, such as "Adversarial Examples in Multi-Layer Random ReLU Networks" by Bartlett et al.
  - ZH:
    > 缺乏相关研究：该论文忽略了现有关于随机网络的理论工作，例如 Bartlett 等人的 "Adversarial Examples in Multi-Layer Random ReLU Networks"。
- Important result / 重要结果:
  - EN:
    > In particular, our theoretical results show that neural network's adversarial robustness can degrade as the input dimension $d$ increases.
  - ZH:
    > 特别是，我们的理论结果表明，神经网络的对抗鲁棒性会随着输入维度 $d$ 的增加而下降。

#### Paper 3

- Paper ID: `AZVvTBxTdZ`
- URL: https://openreview.net/forum?id=AZVvTBxTdZ
- Title / 标题:
  - EN:
    > A Neural Architecture Dataset for Adversarial Robustness
  - ZH:
    > 用于对抗鲁棒性的神经网络架构数据集
- Abstract / 摘要:
  - EN:
    > Robustness to adversarial attacks is critical for practical deployments of deep neural networks. However, pursuing adversarial robustness from the network architecture perspective demands tremendous computational resources, thereby hampering progress in understanding and designing robust architectures. In this work, we aim to lower this barrier-to-entry for researchers without access to large-scale computation by introducing the first comprehensive neural architecture dataset under adversarial training, dubbed NARes, for adversarial robustness. NARes comprises 15,625 WRN-style unique architectures adversarially trained and evaluated against four adversarial attacks (including AutoAttack). With NARes, researchers can query the adversarial robustness of various models immediately, along with more detailed information, such as fine-grained training statistics, empirical Lipschitz constant, stable accuracy, etc. In addition, four checkpoints are provided for each architecture to facilitate further fine-tuning or analysis. For the first time, the dataset provides a high-resolution architecture landscape for adversarial robustness, enabling quick verifications of theoretical or empiri...
  - ZH:
    > 对对抗攻击的鲁棒性对于深度神经网络的实际部署至关重要。然而，从网络架构的角度追求对抗鲁棒性需要巨大的计算资源，从而阻碍了理解和设计鲁棒架构的进展。在这项工作中，我们旨在通过引入第一个用于对抗鲁棒性的对抗训练下的综合神经网络架构数据集（命名为NARes），来为没有大规模计算资源的研究人员降低这一入门门槛。NARes包含15,625个WRN风格的独特架构，这些架构经过对抗训练，并针对四种对抗攻击（包括AutoAttack）进行了评估。借助NARes，研究人员可以立即查询各种模型的对抗鲁棒性，以及更详细的信息，例如细粒度的训练统计数据、经验Lipschitz常数、稳定准确率等。此外，为每个架构提供了四个检查点（checkpoints），以促进进一步的微调或分析。该数据集首次为对抗鲁棒性提供了高分辨率的架构景观（architecture landscape），从而能够快速验证理论或empiri...
- Key contribution / 关键贡献:
  - EN:
    > This paper spend tons of GPU resources to construct a huge benchmark on the relation between WRN architecture design and adversarial robustness.
  - ZH:
    > 本论文花费了大量的GPU资源来构建一个关于WRN架构设计与对抗鲁棒性之间关系的巨大基准（benchmark）。
- Limitation / 局限:
  - EN:
    > My main concern is that the benchmark only covers a tiny scope in the field of robust machine learning.
  - ZH:
    > 我的主要担忧是，该基准仅涵盖了鲁棒机器学习领域中一个极小的范围。
- Important result / 重要结果:
  - EN:
    > Tons of GPU resources are generously spent to build the new benchmark.
  - ZH:
    > 慷慨地花费了大量的GPU资源来构建这个新基准。

#### Paper 4

- Paper ID: `OuLgaHEmzi`
- URL: https://openreview.net/forum?id=OuLgaHEmzi
- Title / 标题:
  - EN:
    > Endowing Visual Reprogramming with Adversarial Robustness
  - ZH:
    > 赋予视觉重编程对抗鲁棒性
- Abstract / 摘要:
  - EN:
    > Visual reprogramming (VR) leverages well-developed pre-trained models (e.g., a pre-trained classifier on ImageNet) to tackle target tasks (e.g., a traffic sign recognition task), without the need for training from scratch. Despite the effectiveness of previous VR methods, all of them did not consider the adversarial robustness of reprogrammed models against adversarial attacks, which could lead to unpredictable problems in safety-crucial target tasks. In this paper, we empirically find that reprogramming pre-trained models with adversarial robustness and incorporating adversarial samples from the target task during reprogramming can both improve the adversarial robustness of reprogrammed models. Furthermore, we propose a theoretically guaranteed adversarial robustness risk upper bound for VR, which validates our empirical findings and could provide a theoretical foundation for future research. Extensive experiments demonstrate that by adopting the strategies revealed in our empirical findings, the adversarial robustness of reprogrammed models can be enhanced.
  - ZH:
    > 视觉重编程（Visual reprogramming, VR）利用完善的预训练模型（例如，ImageNet上的预训练分类器）来处理目标任务（例如，交通标志识别任务），而无需从头开始训练。尽管以前的VR方法很有效，但它们都没有考虑重编程模型针对对抗性攻击的对抗鲁棒性（adversarial robustness），这可能在安全至关重要的目标任务中导致不可预测的问题。在本文中，我们通过实证发现，对具有对抗鲁棒性的预训练模型进行重编程，并在重编程期间结合来自目标任务的对抗样本，两者都可以提高重编程模型的对抗鲁棒性。此外，我们提出了一个有理论保证的VR对抗鲁棒性风险上限，这验证了我们的实证发现，并可以为未来的研究提供理论基础。大量实验表明，通过采用我们的实证发现中所揭示的策略，可以增强重编程模型的对抗鲁棒性。
- Key contribution / 关键贡献:
  - EN:
    > This paper delves into the adversarial robustness of visual reprogramming.
  - ZH:
    > 本文深入探讨了视觉重编程的对抗鲁棒性。
- Limitation / 局限:
  - EN:
    > The two proposed strategies are mature techniques in the field.
  - ZH:
    > 提出的两种策略是该领域成熟的技术。
- Important result / 重要结果:
  - EN:
    > In this paper, we empirically find that reprogramming pre-trained models with adversarial robustness and incorporating adversarial samples from the target task during reprogramming can both improve the adversarial robustness of reprogrammed models.
  - ZH:
    > 在本文中，我们通过实证发现，对具有对抗鲁棒性的预训练模型进行重编程，并在重编程期间结合来自目标任务的对抗样本，两者都可以提高重编程模型的对抗鲁棒性。
