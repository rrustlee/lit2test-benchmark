# Task 02 — Human Calibration: Pairwise Answer Preference

英文原文为准，中文翻译仅供参考。请不要猜模型身份；Answer A / B 是匿名答案。

## Goal / 目的

对同一个论文邻域和同一个 open problem，比较两个 Lit2Test answer。选择哪个 answer 更适合作为 grounded、specific、minimal、feasible、falsifiable 的下一步研究实验。

## Overall decision / 总体选择

- `winner`: `A` / `B` / `TIE` / `INVALID`。
  - `A` or `B`: 一方整体更好。
  - `TIE`: 两者质量非常接近，或优缺点不同且无法稳定偏好。
  - `INVALID`: 至少一方严重缺失、不可读、偏离任务，导致无法正常比较。
- `confidence`: `low` / `medium` / `high`。

## Dimension scores / 维度评分

每个 answer 分别打 `1`-`3`。`1` 表示弱，`2` 表示部分达标，`3` 表示明确达标。

- `grounding_score_a/b`: 是否真实利用 supplied papers 和 open problem。
  - `1`: 泛泛而谈，换一组论文也能用。
  - `2`: 提到部分论文主题，但 synthesis 或 tension 不够明确。
  - `3`: 明确依赖多篇论文的共同限制、机制或张力。
- `hypothesis_specificity_score_a/b`: 假设是否具体、可检验。
  - `1`: 只有宽泛目标，如“improve performance”。
  - `2`: 有方向，但机制或条件不清。
  - `3`: 明确说明在什么条件下、因为什么机制、预期出现什么差异。
- `minimality_feasibility_score_a/b`: 实验是否足够小且可执行。
  - `1`: 过大、过空、需要不现实资源或缺关键 baseline。
  - `2`: 大体可做，但 scope、baseline、数据或资源有缺口。
  - `3`: 最小实验清楚，数据/baseline/资源约束基本可落地。
- `decisive_metric_score_a/b`: metric 是否能决定假设。
  - `1`: 只有普通平均分或主观观察，不能检验机制。
  - `2`: 有相关 metric，但和 hypothesis 的对应关系不够紧。
  - `3`: metric 与机制/失败模式直接对应，能区分 competing explanations。
- `falsifiability_score_a/b`: 是否有真正能推翻假设的结果。
  - `1`: falsifier 只是“效果不好”或几乎不可发生。
  - `2`: 有失败条件，但不够具体或不够 decisive。
  - `3`: 清楚说明什么结果会削弱/推翻假设。

## Tie / invalid fields

- `tie_reason`: winner 为 `TIE` 时填写；可选值：`too_close`, `both_good`, `both_bad`, `different_tradeoff`, `insufficient_context`, `other`。
- `invalid_reason`: winner 为 `INVALID` 时填写；可选值：`missing_answer`, `not_about_task`, `unreadable`, `unsafe_or_irrelevant`, `other`。

## Weakness taxonomy / 弱点分类

当 winner 是 `A` 或 `B` 时，请给 loser 选择主要弱点 `loser_primary_weakness`，可选次要弱点 `loser_secondary_weakness`。可选值：`weak_grounding`, `generic_hypothesis`, `overbroad_or_infeasible`, `missing_baseline_or_control`, `weak_decisive_metric`, `no_real_falsification`, `misread_task_or_invalid`, `unclear_writing`, `other`。

定义：

- `weak_grounding`: 没有真正基于给定论文；像通用提案。
- `generic_hypothesis`: 假设太泛，缺少机制、条件或可检验方向。
- `overbroad_or_infeasible`: 实验范围过大、资源不现实，或缺少可执行步骤。
- `missing_baseline_or_control`: 没有关键 baseline、control group、ablation 或对照条件，导致结果不可解释。
- `weak_decisive_metric`: metric 太普通，不能判断核心机制或失败模式。
- `no_real_falsification`: falsifying result 不能真正推翻假设，或只是重复“没有提升”。
- `misread_task_or_invalid`: 误解 open problem、答非所问、字段缺失或不可读。
- `unclear_writing`: 表达混乱导致难以判断。
- `other`: 其他，需在 `notes_zh` 简述。

## Compact examples / 简短例子

- 如果 Answer A 给出明确 baseline、ablation、failure slice 和 falsifier；Answer B 只说“combine methods and evaluate accuracy”，通常 A 胜，B 的弱点可能是 `generic_hypothesis` + `weak_decisive_metric`。
- 如果两者都可行，但一个更 novel、另一个更 feasible，且你无法稳定偏好，可选 `TIE`，`tie_reason=different_tradeoff`。
- 如果某答案没有按六字段作答且无法判断，考虑 `INVALID`。
